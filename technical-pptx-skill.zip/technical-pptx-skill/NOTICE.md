# Notice

This is an independent implementation created from publicly described presentation-generation practices and the user-provided reference presentation. It does not contain Anthropic's proprietary PPTX Skill text, scripts, or bundled assets.

The workflow is informed by publicly visible concepts such as:

- using a skill folder with `SKILL.md`, scripts, references, and assets;
- separating reference-based editing from from-scratch generation;
- rendering generated presentations for visual QA;
- using varied layouts instead of repeating title-and-bullet slides.

The bundled file `assets/firedrake_technical_exchange_reference.pptx` and its montage are user-provided reference assets and are excluded from the MIT license. Do not redistribute them without the owner's permission.
