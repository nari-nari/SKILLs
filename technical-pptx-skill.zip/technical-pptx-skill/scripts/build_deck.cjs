#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const pptxgen = require('pptxgenjs');
const SHAPE = (new pptxgen()).ShapeType;

const ROOT = path.resolve(__dirname, '..');
const TOKENS = JSON.parse(fs.readFileSync(path.join(ROOT, 'assets', 'design-tokens.json'), 'utf8'));
const C = TOKENS.colors;
const S = TOKENS.sizes;
const G = TOKENS.geometry;
const W = TOKENS.slide.widthInches;
const H = TOKENS.slide.heightInches;
const MX = TOKENS.slide.marginX;

function color(name, fallback = C.blue) {
  return C[name] || fallback;
}

function addText(slide, text, x, y, w, h, options = {}) {
  const defaults = {
    x, y, w, h,
    fontFace: TOKENS.fonts.latin,
    fontSize: S.body,
    color: C.body,
    margin: 0,
    breakLine: false,
    valign: 'mid',
    fit: 'shrink',
    paraSpaceAfterPt: 0,
    lineSpacingMultiple: 1.0,
  };
  slide.addText(text, { ...defaults, ...options });
}

function addHeader(slide, title, takeaway, page, footer) {
  addText(slide, title, MX, 0.42, W - 2 * MX, 0.42, {
    fontFace: TOKENS.fonts.japanese,
    fontSize: S.slideTitle,
    bold: true,
    color: C.navy,
    fit: 'shrink',
  });
  if (takeaway) {
    addText(slide, takeaway, MX, 0.94, W - 2 * MX, 0.34, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: S.takeaway,
      color: C.muted,
      valign: 'top',
    });
  }
  slide.addShape(SHAPE.line, {
    x: MX,
    y: 7.08,
    w: W - 2 * MX,
    h: 0,
    line: { color: C.line, width: 0.8 },
  });
  if (footer) {
    addText(slide, footer, MX, 7.14, 4.0, 0.16, { fontSize: S.footer, color: C.muted, valign: 'mid' });
  }
  addText(slide, String(page), W - MX - 0.35, 7.13, 0.35, 0.18, {
    fontSize: S.footer,
    color: C.muted,
    align: 'right',
  });
}

function addCard(slide, x, y, w, h, accentName, options = {}) {
  const accent = color(accentName);
  slide.addShape(SHAPE.roundRect, {
    x, y, w, h,
    rectRadius: G.cardRadius,
    fill: { color: options.fill || C.card },
    line: { color: options.line || C.line, width: options.lineWidth || 1 },
    radius: G.cardRadius,
  });
  if (options.accentBar !== false) {
    slide.addShape(SHAPE.roundRect, {
      x: x + 0.02, y: y + 0.04, w: 0.08, h: h - 0.08,
      fill: { color: accent },
      line: { color: accent, transparency: 100 },
      radius: 0.04,
    });
  }
}

function bulletRuns(items, accentName) {
  const accent = color(accentName);
  const runs = [];
  items.forEach((item, index) => {
    runs.push({
      text: `● `,
      options: { color: accent, bold: true, breakLine: false },
    });
    runs.push({
      text: String(item),
      options: { color: C.body, breakLine: index < items.length - 1 },
    });
  });
  return runs;
}

function renderTitle(slide, spec) {
  slide.background = { color: C.canvas };
  slide.addShape(SHAPE.rect, {
    x: 0, y: 0, w: W, h: 0.18,
    fill: { color: C.blue },
    line: { color: C.blue, transparency: 100 },
  });
  addText(slide, spec.title || '', 0.78, 1.28, 11.8, 1.2, {
    fontFace: TOKENS.fonts.japanese,
    fontSize: S.coverTitle,
    bold: true,
    color: C.navy,
    valign: 'bottom',
  });
  addText(slide, spec.subtitle || '', 0.82, 2.72, 11.5, 0.55, {
    fontFace: TOKENS.fonts.japanese,
    fontSize: S.coverSubtitle,
    color: C.muted,
    valign: 'top',
  });
  if (spec.focus) {
    addCard(slide, 0.82, 4.0, 11.7, 1.45, 'blue', { fill: C.card });
    addText(slide, spec.focus, 1.18, 4.22, 10.95, 1.0, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 19,
      bold: true,
      color: C.navy,
      valign: 'mid',
    });
  }
}

function renderTwoColumn(slide, spec, page, footer) {
  addHeader(slide, spec.title, spec.takeaway, page, footer);
  const y = 1.55;
  const gap = 0.32;
  const w = (W - 2 * MX - gap) / 2;
  [spec.left, spec.right].forEach((column, index) => {
    const x = MX + index * (w + gap);
    addCard(slide, x, y, w, 4.95, column.accent || (index === 0 ? 'orange' : 'blue'));
    addText(slide, column.heading || '', x + 0.35, y + 0.3, w - 0.62, 0.5, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 18,
      bold: true,
      color: color(column.accent || (index === 0 ? 'orange' : 'blue')),
    });
    addText(slide, bulletRuns(column.items || [], column.accent || (index === 0 ? 'orange' : 'blue')), x + 0.36, y + 1.0, w - 0.7, 3.5, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 16,
      breakLine: false,
      valign: 'top',
      paraSpaceAfterPt: 12,
      lineSpacingMultiple: 1.1,
    });
  });
}

function renderProcess(slide, spec, page, footer) {
  addHeader(slide, spec.title, spec.takeaway, page, footer);
  const steps = spec.steps || [];
  const gap = 0.18;
  const usable = W - 2 * MX;
  const stepW = (usable - gap * (steps.length - 1)) / Math.max(steps.length, 1);
  const y = 2.25;
  steps.forEach((step, index) => {
    const x = MX + index * (stepW + gap);
    const accent = color(step.accent || 'blue');
    slide.addShape(SHAPE.roundRect, {
      x, y, w: stepW, h: 2.3,
      fill: { color: C.card },
      line: { color: accent, width: 1.6 },
      radius: 0.08,
    });
    slide.addShape(SHAPE.ellipse, {
      x: x + stepW / 2 - 0.28, y: y + 0.28, w: 0.56, h: 0.56,
      fill: { color: accent },
      line: { color: accent },
    });
    addText(slide, String(index + 1), x + stepW / 2 - 0.2, y + 0.35, 0.4, 0.36, {
      fontSize: 16, bold: true, color: C.white, align: 'center',
    });
    addText(slide, step.label || '', x + 0.18, y + 1.0, stepW - 0.36, 0.56, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 16,
      bold: true,
      color: C.navy,
      align: 'center',
    });
    addText(slide, step.detail || '', x + 0.18, y + 1.65, stepW - 0.36, 0.35, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 12.5,
      color: C.muted,
      align: 'center',
    });
    if (index < steps.length - 1) {
      slide.addShape(SHAPE.chevron, {
        x: x + stepW + 0.02, y: y + 0.96, w: gap - 0.04, h: 0.42,
        fill: { color: C.line },
        line: { color: C.line },
      });
    }
  });
}

function renderCodeCompare(slide, spec, page, footer) {
  addHeader(slide, spec.title, spec.takeaway, page, footer);
  const gap = 0.28;
  const w = (W - 2 * MX - gap) / 2;
  [spec.left, spec.right].forEach((panel, index) => {
    const x = MX + index * (w + gap);
    const accent = color(panel.accent || (index === 0 ? 'orange' : 'blue'));
    addText(slide, panel.heading || '', x, 1.52, w, 0.4, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 16,
      bold: true,
      color: accent,
    });
    slide.addShape(SHAPE.roundRect, {
      x, y: 2.0, w, h: 4.48,
      fill: { color: C.darkCode },
      line: { color: accent, width: 1.4 },
      radius: 0.06,
    });
    addText(slide, panel.code || '', x + 0.25, 2.24, w - 0.5, 3.98, {
      fontFace: TOKENS.fonts.code,
      fontSize: S.code,
      color: C.white,
      valign: 'top',
      breakLine: false,
      margin: 0.03,
      fit: 'shrink',
    });
  });
}

function renderCards(slide, spec, page, footer) {
  addHeader(slide, spec.title, spec.takeaway, page, footer);
  const cards = spec.cards || [];
  const gap = 0.22;
  const w = (W - 2 * MX - gap * (cards.length - 1)) / Math.max(cards.length, 1);
  const y = 1.72;
  cards.forEach((card, index) => {
    const x = MX + index * (w + gap);
    addCard(slide, x, y, w, 4.72, card.accent || 'blue');
    addText(slide, card.heading || '', x + 0.34, y + 0.3, w - 0.58, 0.5, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 17,
      bold: true,
      color: color(card.accent || 'blue'),
    });
    addText(slide, bulletRuns(card.items || [], card.accent || 'blue'), x + 0.34, y + 1.0, w - 0.62, 3.25, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 14.5,
      valign: 'top',
      paraSpaceAfterPt: 10,
    });
  });
}

function renderResult(slide, spec, page, footer) {
  addHeader(slide, spec.title, spec.takeaway, page, footer);
  const accent = color(spec.accent || 'blue');
  slide.addShape(SHAPE.roundRect, {
    x: MX, y: 1.6, w: 7.85, h: 4.95,
    fill: { color: C.card }, line: { color: C.line, width: 1 }, radius: 0.06,
  });
  if (spec.image && fs.existsSync(path.resolve(spec.image))) {
    slide.addImage({ path: path.resolve(spec.image), x: MX + 0.2, y: 1.8, w: 7.45, h: 4.2, transparency: 0 });
  } else {
    addText(slide, spec.figurePlaceholder || 'Insert result figure here', MX + 0.5, 3.5, 6.85, 0.5, {
      fontSize: 18, color: C.muted, align: 'center',
    });
  }
  addCard(slide, 8.85, 1.6, 3.8, 2.25, spec.accent || 'blue');
  addText(slide, spec.metric || '', 9.2, 1.92, 3.1, 0.7, {
    fontSize: 28, bold: true, color: accent, align: 'center',
  });
  addText(slide, spec.metricLabel || '', 9.15, 2.72, 3.2, 0.5, {
    fontFace: TOKENS.fonts.japanese,
    fontSize: 14, color: C.muted, align: 'center',
  });
  addCard(slide, 8.85, 4.1, 3.8, 2.45, 'teal');
  addText(slide, spec.interpretation || '', 9.15, 4.38, 3.2, 1.82, {
    fontFace: TOKENS.fonts.japanese,
    fontSize: 15, color: C.navy, valign: 'mid',
  });
}

function renderSummary(slide, spec, page, footer) {
  addHeader(slide, spec.title, spec.takeaway, page, footer);
  addCard(slide, MX, 1.65, W - 2 * MX, 3.55, 'blue');
  addText(slide, bulletRuns(spec.points || [], 'blue'), MX + 0.42, 2.0, W - 2 * MX - 0.84, 2.8, {
    fontFace: TOKENS.fonts.japanese,
    fontSize: 18,
    valign: 'top',
    paraSpaceAfterPt: 13,
  });
  if (spec.next) {
    slide.addShape(SHAPE.roundRect, {
      x: MX, y: 5.55, w: W - 2 * MX, h: 0.82,
      fill: { color: C.blue }, line: { color: C.blue }, radius: 0.05,
    });
    addText(slide, spec.next, MX + 0.35, 5.72, W - 2 * MX - 0.7, 0.45, {
      fontFace: TOKENS.fonts.japanese,
      fontSize: 17, bold: true, color: C.white, align: 'center',
    });
  }
}

async function build(inputPath, outputPath) {
  const data = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
  const deck = new pptxgen();
  deck.layout = TOKENS.slide.layout;
  deck.author = data.meta?.author || 'Technical PPTX Skill';
  deck.company = data.meta?.company || '';
  deck.subject = data.meta?.subject || '';
  deck.title = data.slides?.[0]?.title || 'Technical presentation';
  deck.lang = 'ja-JP';
  deck.theme = {
    headFontFace: TOKENS.fonts.japanese,
    bodyFontFace: TOKENS.fonts.japanese,
    lang: 'ja-JP',
  };
  deck.defineSlideMaster({
    title: 'TECHNICAL',
    background: { color: C.canvas },
    objects: [],
  });

  const slides = data.slides || [];
  slides.forEach((spec, index) => {
    const slide = deck.addSlide('TECHNICAL');
    slide.background = { color: C.canvas };
    const page = index + 1;
    const footer = data.footer || '';
    switch (spec.type) {
      case 'title': renderTitle(slide, spec); break;
      case 'two-column': renderTwoColumn(slide, spec, page, footer); break;
      case 'process': renderProcess(slide, spec, page, footer); break;
      case 'code-compare': renderCodeCompare(slide, spec, page, footer); break;
      case 'cards': renderCards(slide, spec, page, footer); break;
      case 'result': renderResult(slide, spec, page, footer); break;
      case 'summary': renderSummary(slide, spec, page, footer); break;
      default:
        throw new Error(`Unsupported slide type '${spec.type}' at slide ${page}`);
    }
  });

  await deck.writeFile({ fileName: outputPath });
}

if (process.argv.length < 4) {
  console.error('Usage: node scripts/build_deck.cjs input.json output.pptx');
  process.exit(2);
}

build(path.resolve(process.argv[2]), path.resolve(process.argv[3]))
  .catch((error) => {
    console.error(error.stack || String(error));
    process.exit(1);
  });
