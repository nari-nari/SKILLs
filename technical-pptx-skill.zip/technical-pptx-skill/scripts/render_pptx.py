#!/usr/bin/env python3
"""Render PPTX to PNG slides and a montage using LibreOffice and Poppler."""

from __future__ import annotations

import argparse
import math
import shutil
import subprocess
import tempfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


def require(command: str) -> str:
    resolved = shutil.which(command)
    if not resolved:
        raise SystemExit(f"Required command not found: {command}")
    return resolved


def make_montage(images: list[Path], output: Path, columns: int = 3) -> None:
    if not images:
        raise ValueError("No rendered slide images found")
    opened = [Image.open(path).convert("RGB") for path in images]
    target_width = min(900, max(image.width for image in opened))
    thumbs = []
    for image in opened:
        ratio = target_width / image.width
        thumbs.append(image.resize((target_width, round(image.height * ratio))))

    label_h = 34
    gap = 18
    rows = math.ceil(len(thumbs) / columns)
    cell_h = max(image.height for image in thumbs) + label_h
    canvas = Image.new(
        "RGB",
        (columns * target_width + (columns + 1) * gap, rows * cell_h + (rows + 1) * gap),
        "white",
    )
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default()
    for index, image in enumerate(thumbs):
        row, col = divmod(index, columns)
        x = gap + col * (target_width + gap)
        y = gap + row * (cell_h + gap)
        canvas.paste(image, (x, y + label_h))
        draw.text((x, y + 8), f"Slide {index + 1}", fill="black", font=font)
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)


def render(pptx: Path, out_dir: Path, dpi: int, columns: int) -> None:
    soffice = require("soffice")
    pdftoppm = require("pdftoppm")
    out_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="technical-pptx-") as temp:
        temp_dir = Path(temp)
        subprocess.run(
            [soffice, "--headless", "--convert-to", "pdf", "--outdir", str(temp_dir), str(pptx)],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        pdf = temp_dir / f"{pptx.stem}.pdf"
        if not pdf.exists():
            candidates = list(temp_dir.glob("*.pdf"))
            if len(candidates) != 1:
                raise SystemExit("LibreOffice did not produce the expected PDF")
            pdf = candidates[0]
        prefix = out_dir / "slide"
        subprocess.run(
            [pdftoppm, "-png", "-r", str(dpi), str(pdf), str(prefix)],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

    images = sorted(out_dir.glob("slide-*.png"), key=lambda p: int(p.stem.split("-")[-1]))
    make_montage(images, out_dir / "montage.png", columns=columns)
    print(f"Rendered {len(images)} slides to {out_dir}")
    print(f"Montage: {out_dir / 'montage.png'}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--dpi", type=int, default=150)
    parser.add_argument("--columns", type=int, default=3)
    args = parser.parse_args()
    render(args.pptx.resolve(), args.out_dir.resolve(), args.dpi, args.columns)


if __name__ == "__main__":
    main()
