#!/usr/bin/env python3
"""Extract slide text and optional speaker notes from a PPTX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from pptx import Presentation


def extract(pptx_path: Path) -> dict:
    prs = Presentation(str(pptx_path))
    slides = []
    for index, slide in enumerate(prs.slides, start=1):
        texts: list[str] = []
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                value = shape.text.strip()
                if value:
                    texts.append(value)
        slides.append({"slide": index, "text": texts})
    return {
        "file": str(pptx_path),
        "slide_count": len(prs.slides),
        "slides": slides,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--json", dest="json_path", type=Path)
    args = parser.parse_args()

    result = extract(args.pptx)
    if args.json_path:
        args.json_path.parent.mkdir(parents=True, exist_ok=True)
        args.json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    else:
        for slide in result["slides"]:
            print(f"\n# Slide {slide['slide']}")
            for text in slide["text"]:
                print(text)


if __name__ == "__main__":
    main()
