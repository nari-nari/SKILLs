#!/usr/bin/env python3
"""Perform structural and heuristic layout QA on a PPTX."""

from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

EMU_PER_INCH = 914400


def box(shape):
    return (shape.left, shape.top, shape.left + shape.width, shape.top + shape.height)


def intersection_ratio(a, b) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    x = max(0, min(ax2, bx2) - max(ax1, bx1))
    y = max(0, min(ay2, by2) - max(ay1, by1))
    inter = x * y
    if inter <= 0:
        return 0.0
    area_a = max(1, (ax2 - ax1) * (ay2 - ay1))
    area_b = max(1, (bx2 - bx1) * (by2 - by1))
    return inter / min(area_a, area_b)


def contains(a, b, tolerance=1000) -> bool:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    return ax1 - tolerance <= bx1 and ay1 - tolerance <= by1 and ax2 + tolerance >= bx2 and ay2 + tolerance >= by2


def has_visible_text(shape) -> bool:
    return bool(getattr(shape, "has_text_frame", False) and shape.text.strip())


def min_font_size(shape) -> float | None:
    sizes = []
    if not getattr(shape, "has_text_frame", False):
        return None
    for paragraph in shape.text_frame.paragraphs:
        for run in paragraph.runs:
            if run.font.size:
                sizes.append(run.font.size.pt)
    return min(sizes) if sizes else None


def approximate_text_density(shape) -> float | None:
    if not has_visible_text(shape):
        return None
    size = min_font_size(shape) or 14.0
    width_in = shape.width / EMU_PER_INCH
    height_in = shape.height / EMU_PER_INCH
    # Conservative heuristic for mixed Latin/Japanese text.
    capacity = max(1.0, width_in * height_in * 72.0 / max(size, 1.0) * 14.0)
    return len(shape.text) / capacity


def validate(path: Path) -> dict:
    warnings = []
    errors = []

    try:
        with zipfile.ZipFile(path) as archive:
            bad = archive.testzip()
            if bad:
                errors.append({"type": "zip-corruption", "member": bad})
    except zipfile.BadZipFile as exc:
        return {"file": str(path), "errors": [{"type": "bad-zip", "message": str(exc)}], "warnings": []}

    try:
        prs = Presentation(str(path))
    except Exception as exc:  # noqa: BLE001
        return {"file": str(path), "errors": [{"type": "open-failure", "message": str(exc)}], "warnings": warnings}

    sw, sh = prs.slide_width, prs.slide_height
    for slide_index, slide in enumerate(prs.slides, start=1):
        text_shapes = []
        total_chars = 0
        for shape_index, shape in enumerate(slide.shapes, start=1):
            x1, y1, x2, y2 = box(shape)
            if x1 < 0 or y1 < 0 or x2 > sw or y2 > sh:
                warnings.append(
                    {
                        "type": "out-of-bounds",
                        "slide": slide_index,
                        "shape": shape_index,
                        "name": shape.name,
                        "box_inches": [round(v / EMU_PER_INCH, 3) for v in (x1, y1, x2, y2)],
                    }
                )
            if has_visible_text(shape):
                text_shapes.append((shape_index, shape))
                total_chars += len(shape.text)
                min_size = min_font_size(shape)
                if min_size is not None and min_size < 9:
                    warnings.append(
                        {
                            "type": "small-font",
                            "slide": slide_index,
                            "shape": shape_index,
                            "name": shape.name,
                            "min_font_pt": round(min_size, 1),
                        }
                    )
                density = approximate_text_density(shape)
                if density is not None and density > 1.0:
                    warnings.append(
                        {
                            "type": "possible-text-overflow",
                            "slide": slide_index,
                            "shape": shape_index,
                            "name": shape.name,
                            "density_score": round(density, 2),
                            "characters": len(shape.text),
                        }
                    )
        if total_chars > 900:
            warnings.append({"type": "dense-slide", "slide": slide_index, "characters": total_chars})

        for i, (index_a, shape_a) in enumerate(text_shapes):
            for index_b, shape_b in text_shapes[i + 1 :]:
                a, b = box(shape_a), box(shape_b)
                if contains(a, b) or contains(b, a):
                    continue
                ratio = intersection_ratio(a, b)
                if ratio > 0.18:
                    warnings.append(
                        {
                            "type": "possible-text-overlap",
                            "slide": slide_index,
                            "shapes": [index_a, index_b],
                            "names": [shape_a.name, shape_b.name],
                            "overlap_ratio": round(ratio, 2),
                        }
                    )

    return {
        "file": str(path),
        "slide_count": len(prs.slides),
        "slide_size_inches": [round(sw / EMU_PER_INCH, 3), round(sh / EMU_PER_INCH, 3)],
        "errors": errors,
        "warnings": warnings,
        "note": "Heuristic QA cannot replace visual inspection of rendered slides.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = validate(args.pptx)
    output = json.dumps(result, ensure_ascii=False, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output, encoding="utf-8")
    print(output)
    raise SystemExit(1 if result["errors"] else 0)


if __name__ == "__main__":
    main()
