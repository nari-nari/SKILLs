#!/usr/bin/env python3
"""Extract measurable style characteristics from a reference PPTX."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

EMU_PER_INCH = 914400


def rgb_string(color) -> str | None:
    try:
        if color.type is not None and color.rgb is not None:
            return str(color.rgb)
    except (AttributeError, ValueError):
        return None
    return None


def analyze(path: Path) -> dict:
    prs = Presentation(str(path))
    font_sizes: Counter[float] = Counter()
    font_names: Counter[str] = Counter()
    font_colors: Counter[str] = Counter()
    fills: Counter[str] = Counter()
    lines: Counter[str] = Counter()
    slide_inventory = []

    for slide_index, slide in enumerate(prs.slides, start=1):
        types: Counter[str] = Counter()
        text_chars = 0
        for shape in slide.shapes:
            types[str(shape.shape_type)] += 1
            if getattr(shape, "has_text_frame", False):
                text_chars += len(shape.text)
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        if run.font.size:
                            font_sizes[round(run.font.size.pt, 1)] += 1
                        if run.font.name:
                            font_names[run.font.name] += 1
                        color = rgb_string(run.font.color)
                        if color:
                            font_colors[color] += 1
            if shape.shape_type == MSO_SHAPE_TYPE.AUTO_SHAPE:
                try:
                    if shape.fill.type is not None and shape.fill.fore_color.rgb:
                        fills[str(shape.fill.fore_color.rgb)] += 1
                except (AttributeError, ValueError):
                    pass
                try:
                    if shape.line.color.type is not None and shape.line.color.rgb:
                        lines[str(shape.line.color.rgb)] += 1
                except (AttributeError, ValueError):
                    pass
        slide_inventory.append(
            {
                "slide": slide_index,
                "shape_count": len(slide.shapes),
                "shape_types": dict(types),
                "text_characters": text_chars,
            }
        )

    return {
        "file": str(path),
        "slide_count": len(prs.slides),
        "slide_size_inches": {
            "width": round(prs.slide_width / EMU_PER_INCH, 3),
            "height": round(prs.slide_height / EMU_PER_INCH, 3),
        },
        "font_sizes_pt": font_sizes.most_common(),
        "explicit_font_names": font_names.most_common(),
        "font_colors": font_colors.most_common(),
        "shape_fill_colors": fills.most_common(),
        "shape_line_colors": lines.most_common(),
        "slides": slide_inventory,
        "note": "Theme-inherited fonts and colors may not appear as explicit run properties. Always inspect rendered slides.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = analyze(args.pptx)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()
