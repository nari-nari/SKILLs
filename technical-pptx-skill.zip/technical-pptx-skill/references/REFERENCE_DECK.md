# Bundled reference deck

## Purpose

The bundled Firedrake technical-exchange deck demonstrates a restrained engineering presentation style and a narrative that introduces a new analysis framework without dismissing established Fortran/FDM assets.

## Extracted characteristics

- 16:9 layout, approximately 13.333 × 7.5 inches.
- Twelve slides.
- White background with navy title hierarchy.
- Muted gray one-line takeaways.
- Blue, orange, green, and teal used semantically.
- Rounded cards with light gray fill and borders.
- Page titles around 31 pt; cover title around 44 pt.
- Code shown in a monospace font.
- Varied layouts: comparison, process, code panels, evidence, role split, coexistence, summary.

## Narrative pattern

The deck moves from background and comparison axis to mechanism, code-level examples, evidence, model-change implications, limitations, and a realistic coexistence/PoC strategy.

## Appropriate reuse

Use this reference when:

- the audience is an internal engineering or research group;
- the subject is numerical analysis, CAE, optimization, scientific computing, or software migration;
- the presenter needs to compare a validated existing method with a new framework;
- visual restraint is preferable to marketing-style imagery.

Do not use it blindly for sales pitches, consumer storytelling, or image-led talks.
