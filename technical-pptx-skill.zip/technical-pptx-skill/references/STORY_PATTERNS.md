# Story patterns

## Engineering introduction

Best for introducing a new computational framework without rejecting existing assets.

1. Existing assets and current constraint.
2. What is and is not being proposed.
3. Correct comparison axis.
4. Processing or architecture overview.
5. Concrete implementation comparison.
6. Demonstration result.
7. Scalability or model-change implications.
8. Limitations and engineer responsibilities.
9. Coexistence and PoC plan.
10. Summary and next topic.

## Research result

1. Research question.
2. Gap in prior method.
3. Proposed formulation.
4. Numerical or experimental setup.
5. Primary result.
6. Mechanism interpretation.
7. Sensitivity or ablation.
8. Validation against an independent method.
9. Limitations.
10. Conclusion.

## Design review

1. Decision required.
2. Requirements and constraints.
3. Current concept.
4. Analysis method and assumptions.
5. Results against criteria.
6. Risks and unknowns.
7. Alternatives.
8. Recommendation.
9. Verification plan.

## PoC proposal

1. Operational pain.
2. Why now.
3. Narrow PoC scope.
4. Workflow and responsibilities.
5. Success metrics.
6. Required data and environment.
7. Risks and safeguards.
8. Timeline or gates.
9. Go/no-go decision.

## Objection handling

Technical audiences often ask:

- Is the comparison fair?
- Is the new method actually faster?
- What errors are eliminated and which remain?
- How will results be verified?
- Does this replace existing validated code?
- What is the smallest safe next step?

Answer these questions inside the deck before the final recommendation.
