# Public reference sources

This skill is an independent implementation. The following public sources informed its high-level structure and workflow:

- Anthropic public Skills repository: https://github.com/anthropics/skills
- Public PPTX Skill reference page: https://github.com/anthropics/skills/blob/main/skills/pptx/SKILL.md
- Public presentation-editing workflow reference: https://github.com/anthropics/skills/blob/main/skills/pptx/editing.md
- Agent Skills specification: https://agentskills.io/specification
- PptxGenJS project: https://github.com/gitbrent/PptxGenJS

Anthropic's document skills are source-available under their own license. No proprietary Anthropic scripts or instruction text are included in this package.
