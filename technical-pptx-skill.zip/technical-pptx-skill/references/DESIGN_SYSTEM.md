# Design system

## Visual character

Use a calm engineering aesthetic: white canvas, dark navy hierarchy, restrained semantic accents, thin borders, and generous whitespace. The deck should feel precise rather than decorative.

## Semantic color mapping

- Navy: titles and primary hierarchy.
- Dark gray: body copy.
- Muted gray: takeaway/subtitle and captions.
- Orange: existing method, manual implementation, constraints, or cautions.
- Blue: proposed framework, new method, or central technical mechanism.
- Green: solver, validated capability, positive next action, or accepted result.
- Teal: neutral intermediate process or explanatory layer.
- Rose: critical risk, unresolved issue, or stop condition.

Never swap semantic meanings casually between slides.

## Page architecture

For regular content slides:

1. Place title at approximately 0.65 in from the left and 0.45 in from the top.
2. Place a one-line takeaway below the title in muted gray.
3. Reserve the lower 5.7–5.9 in for the visual argument.
4. Use a thin footer rule and page number.
5. Keep core content inside approximately 0.65 in side margins.

## Layout families

Use at least three layout families in a deck of eight or more slides.

### Two-column comparison

Use for established vs proposed, manual vs framework, or option A vs option B. Give each column a semantic accent and equal visual weight only when the comparison is genuinely balanced.

### Process flow

Use for equations-to-code, data-to-decision, architecture, or iterative workflows. Keep step labels short and put explanatory detail below or inside each step.

### Code comparison

Use two code panels with a concise interpretation above or below. Avoid showing code that cannot be read in the presentation room.

### Evidence slide

Make the figure or numerical result the largest object. Add one sentence explaining what the evidence demonstrates and one sentence defining scope or limitation.

### Responsibility split

Use cards or paired columns for what the framework automates versus what the engineer must still decide.

### Summary and next step

Conclude with 2–4 distilled points and a visible next action. Avoid repeating the table of contents.

## Typography

Use a clear sans-serif. Titles are concise and can be noun phrases or claims. Takeaways should be complete sentences when possible. Keep body lines short enough to scan.

Japanese text may require a Japanese-capable font such as Yu Gothic. Do not bundle fonts with the skill.

## Code styling

Use a monospace font and a lightly tinted or dark high-contrast panel. Highlight only a few critical lines. Avoid syntax-color rainbows unless the colors have meaning and remain readable when projected.

## Figures

Use labels, arrows, and callouts sparingly. Crop unused whitespace. Ensure axis labels and legends remain readable after the figure is placed on the slide.
