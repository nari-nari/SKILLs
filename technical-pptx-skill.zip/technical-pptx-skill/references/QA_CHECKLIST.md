# QA checklist

## Structural checks

- PPTX can be opened by `python-pptx` and is a valid ZIP package.
- Slide dimensions are consistent.
- No shape extends outside slide bounds.
- No accidental duplicate title or footer objects.
- Page numbering is consistent if used.
- Text boxes do not contain placeholder text.

## Visual checks

Inspect the montage first, then inspect each slide at full resolution.

- The deck has visible hierarchy at thumbnail size.
- Each slide has a clear focal area.
- Titles and takeaways align across slides.
- Cards have consistent radius, border, and internal padding.
- Gaps between objects are deliberate.
- Code panels are readable.
- Figures are large enough and not pixelated.
- Captions and legends are legible.
- Color contrast is sufficient.
- Semantic color meaning is stable.
- The same layout is not repeated mechanically.

## Content checks

- Every slide has one main message.
- Claims match the source materials.
- Numerical values retain units and conditions.
- Result slides distinguish demonstration from validation.
- Limitations are not hidden.
- The conclusion follows from the evidence shown.
- The requested next action is explicit.

## Presentation-room checks

- Body text can be read from the back of a normal meeting room.
- The speaker can explain each slide without reading paragraphs aloud.
- Complex diagrams have a reveal order that can be narrated.
- The deck fits the allotted duration.
- Backup details are moved to appendix slides when appropriate.

## Revision rule

Complete at least one revision after the first rendered inspection. A successful script run is not equivalent to a successful presentation.
