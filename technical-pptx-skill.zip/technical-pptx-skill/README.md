# Technical PPTX Agent Skill

An independent Agent Skills-compatible package for creating polished, editable technical PowerPoint decks. It combines:

- reference-deck analysis;
- technical storytelling;
- semantic design tokens;
- PptxGenJS generation;
- structural QA;
- LibreOffice/Poppler visual rendering;
- a mandatory revision loop.

The package was designed around an engineering knowledge-sharing deck and works especially well for numerical analysis, CAE, research, software architecture, model comparisons, and PoC proposals.

## Contents

```text
technical-pptx-skill/
├── SKILL.md
├── README.md
├── LICENSE
├── NOTICE.md
├── package.json
├── assets/
│   ├── design-tokens.json
│   ├── firedrake_reference_analysis.json
│   ├── firedrake_technical_exchange_reference.pptx
│   └── firedrake_reference_montage.png
├── examples/
│   ├── example_brief.json
│   ├── example_output.pptx
│   ├── example_montage.png
│   └── example_qa.json
├── references/
│   ├── DESIGN_SYSTEM.md
│   ├── STORY_PATTERNS.md
│   ├── QA_CHECKLIST.md
│   ├── REFERENCE_DECK.md
│   └── SOURCES.md
└── scripts/
    ├── analyze_reference.py
    ├── build_deck.cjs
    ├── extract_text.py
    ├── qa_pptx.py
    └── render_pptx.py
```

## Installation

Place the whole `technical-pptx-skill` directory in the skills location supported by your Agent Skills-compatible client. Installation paths and discovery behavior vary by client.

Install runtime dependencies in the skill directory:

```bash
npm install
python -m pip install python-pptx pillow
```

The full visual workflow also requires:

- LibreOffice (`soffice`)
- Poppler (`pdftoppm`)

## Quick test

```bash
node scripts/build_deck.cjs examples/example_brief.json /tmp/technical-example.pptx
python scripts/qa_pptx.py /tmp/technical-example.pptx --report /tmp/technical-example.qa.json
python scripts/render_pptx.py /tmp/technical-example.pptx --out-dir /tmp/technical-example-rendered
```

## Adapting the style

Edit `assets/design-tokens.json`, or run:

```bash
python scripts/analyze_reference.py your_reference.pptx --output your_reference_analysis.json
```

Then update the design-system reference and generator constants deliberately. Automated extraction cannot determine whether a visual choice is semantically appropriate.

## Scope

The included generator is intentionally compact. It provides reusable technical layouts but is not a universal presentation engine. Complex charts, custom geometry, scientific notation, and company templates may require a custom PptxGenJS script or direct editing of the existing PPTX.
