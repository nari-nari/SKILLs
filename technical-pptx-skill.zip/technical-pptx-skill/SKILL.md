---
name: technical-pptx
description: Create, analyze, or revise editable .pptx presentations for technical reviews, research talks, engineering briefings, internal knowledge sharing, and proof-of-concept proposals. Use when a task involves PowerPoint slides, a reference deck, technical diagrams, code comparisons, numerical results, or a need to convert a technical narrative into a clear visual story. Prefer native PowerPoint objects, preserve technical accuracy, and complete a render-inspect-revise quality loop before delivery.
license: MIT; bundled user-provided reference deck is excluded from the MIT license. See NOTICE.md.
compatibility: Requires Node.js 20+, Python 3.10+, PptxGenJS, python-pptx, LibreOffice, and Poppler for the full generation and visual-QA workflow. Works with Agent Skills-compatible clients.
metadata:
  version: "1.0.0"
  category: presentations
  language: en-ja
---

# Technical PPTX

Create technically accurate, visually coherent, and fully editable PowerPoint presentations. Treat presentation creation as a design-and-validation workflow, not as a text-to-file conversion.

## Core outcome

Deliver:

1. An editable `.pptx` file.
2. A rendered montage or individual slide images for visual review.
3. A QA report containing structural warnings and unresolved limitations.

Do not claim completion until the deck has been rendered and reviewed at least once after generation.

## Choose the workflow

### A. Reference-first

Use this when a reference deck or company template exists.

1. Read the source content and extract the intended message.
2. Render the reference deck to a montage.
3. Analyze its slide size, typography, palette, spacing, recurring components, and layout families.
4. Map new content to suitable layout families; do not force every slide into one repeated layout.
5. Preserve design logic, not placeholder wording.

For the bundled engineering style, inspect:

- `assets/firedrake_technical_exchange_reference.pptx`
- `assets/firedrake_reference_montage.png`
- `assets/design-tokens.json`
- `references/REFERENCE_DECK.md`

### B. From scratch

Use this when no reference is available or the reference is unsuitable.

1. Establish audience, purpose, duration, evidence, and decision requested.
2. Select a narrative pattern from `references/STORY_PATTERNS.md`.
3. Define design tokens before writing slide code.
4. Use `scripts/build_deck.cjs` or create a custom PptxGenJS implementation.
5. Render, inspect, revise, and validate.

### C. Existing deck revision

Use this when editing an existing presentation.

1. Preserve native editability and existing theme behavior where practical.
2. Inventory every slide before changing structure.
3. Identify which problems are content, story, layout, or visual consistency problems.
4. Revise the smallest coherent set of slides.
5. Re-render the entire deck because local changes can affect global consistency.

## Story before layout

Write a one-sentence purpose for every slide. The title and subtitle should let a reader understand that purpose without reading all body text.

For engineering and research communication, prefer this sequence when applicable:

1. Context and current constraint.
2. The correct comparison axis or question.
3. Mechanism, architecture, or governing idea.
4. Concrete implementation example.
5. Evidence or numerical result.
6. Model-change or scale-up implications.
7. Limitations and remaining responsibilities.
8. Coexistence, PoC, decision, or next step.

Avoid feature-dump decks. Anticipate credible objections and answer them explicitly.

## Content rules

- One primary message per slide.
- Use precise claims supported by the provided source material.
- Distinguish measured results, calculated results, assumptions, and proposals.
- Do not invent numerical values, citations, experimental conditions, or software capabilities.
- Keep equations and code only when they advance the argument.
- Explain what a figure proves; do not merely place it.
- Preserve terminology used by the source unless the user asks for normalization.

## Visual rules

Read `references/DESIGN_SYSTEM.md` before building.

- Use a dominant neutral background and a small semantic accent palette.
- Assign colors by meaning and keep that mapping stable across slides.
- Use native PowerPoint text, shapes, charts, and tables whenever practical.
- Use cards, comparisons, timelines, process flows, annotated figures, and result callouts instead of repeated bullet pages.
- Maintain generous outer margins and clear internal spacing.
- Use code fonts only inside code or terminal blocks.
- Avoid decorative icons or photographs that do not clarify the technical message.
- Do not use color as the only carrier of meaning.

## Recommended typography

For 16:9 technical decks:

- Cover title: 40–46 pt
- Slide title: 28–34 pt
- Slide takeaway/subtitle: 14–18 pt
- Card heading: 15–18 pt
- Body: 13–17 pt
- Captions and footers: 9–12 pt
- Code: 9–13 pt monospace

Use a Japanese-capable sans-serif when Japanese text is present. Prefer theme fonts or broadly available fonts rather than bundling font files.

## Build workflow

1. Create a content brief and slide plan.
2. Select layout type for each slide.
3. Create or load design tokens.
4. Generate the presentation using PptxGenJS.
5. Run structural QA:

```bash
python scripts/qa_pptx.py output.pptx --report output.qa.json
```

6. Render slides and create a montage:

```bash
python scripts/render_pptx.py output.pptx --out-dir output_rendered
```

7. Inspect the montage and full-resolution slides for:
   - clipped or overflowing text;
   - accidental overlaps;
   - weak alignment;
   - poor contrast;
   - excessive density;
   - repetitive layouts;
   - figures too small to read;
   - titles that do not state the slide's point.
8. Revise the deck.
9. Re-run QA and rendering.
10. Deliver the PPTX, montage, and QA report.

## Template generator

The bundled generator consumes a JSON brief:

```bash
node scripts/build_deck.cjs examples/example_brief.json output.pptx
```

Supported slide types:

- `title`
- `two-column`
- `process`
- `code-compare`
- `cards`
- `result`
- `summary`

The generator is a starting point. Extend or replace it when the content needs a different visual structure.

## Reference analysis

To inspect a new reference deck:

```bash
python scripts/analyze_reference.py reference.pptx --output reference-analysis.json
python scripts/render_pptx.py reference.pptx --out-dir reference_rendered
```

Use the analysis as evidence, not as an automatic design decision. Review the rendered deck visually.

## Completion checklist

Before delivery, confirm all of the following:

- The deck opens successfully.
- Slide size and orientation are intentional.
- No object extends outside the slide bounds.
- No important text is below 9 pt.
- Titles state conclusions or meaningful questions.
- Body text is readable at normal presentation scale.
- Visual hierarchy is consistent.
- Color semantics are consistent.
- Code and equations are readable.
- Figures have labels or captions where needed.
- Claims remain grounded in the provided sources.
- At least one render-review-revision loop was completed.
- Any unresolved warnings are disclosed.

See `references/QA_CHECKLIST.md` for the detailed inspection rubric.
