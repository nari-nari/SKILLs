# START HERE

## 1. 対象プロジェクトへ導入

```bash
python install.py /path/to/target-project
cd /path/to/target-project
python tools/project_context/refresh_project_context.py
```

## 2. 対象プロジェクトで案内を開く

```text
docs/project-context/START-HERE.md
```

## 3. 既存プロジェクトの通常依頼

```text
/request-intake [feature] 同じ.ncファイルを再度開いたとき、前回の解析範囲を復元したい
```

## 4. 専門コマンドだけ知りたい

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
```

## 5. 大規模・横断変更

```text
/request-intake deep [refactor] packages配下の2パッケージを統合したい
```

## 6. コードも文書もない新規プロジェクト

Copilotではなく、社内AIへ次のテンプレートを貼ります。

```text
ai-exchange/templates/new-project-intake.md
```


## 仕様確定後に技術を選ぶ

```text
/pre-plan-intake <feature path> GUIや主要パッケージを要求に基づいて選定したい
```

`/speckit.plan`の前にAccepted/Prohibitedを承認し、`uv add`はplan承認後に行います。

## 社内AIとの現在のやり取り

どの相談方式でも、現在使うファイルは次だけです。

```text
ai-exchange/current/README.md
ai-exchange/current/prompt.md
ai-exchange/current/response.md
```

回答を貼った後は`/import-current-internal-ai-response`を実行します。
