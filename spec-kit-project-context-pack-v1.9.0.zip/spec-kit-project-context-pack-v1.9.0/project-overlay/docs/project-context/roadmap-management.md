# AI-assisted Roadmap Management

This workflow lets AI discover and structure future work without allowing unreviewed ideas to enter the official roadmap.

## Two layers

1. **Proposal workspace**: `.context-work/roadmap/proposals/RM-xxxx.toml`
   - AI may create and revise candidates.
   - Candidates are local and ignored by Git by default.
   - A candidate is not a requirement, commitment, or approved work item.
2. **Official roadmap**: `docs/project-context/roadmap.md`
   - Only human-approved proposals may be promoted.
   - Deterministic tooling applies a reviewed row and records the source proposal.

## Candidate sources

A proposal may come from:

- scope intentionally deferred from a current feature;
- an implementation or validation gap discovered by code/test review;
- a repeated known issue or blocker;
- a dependency needed by an approved later feature;
- internal-AI research with an explicit source record;
- a concrete maintenance, compatibility, security, or licensing risk.

Do not create official work merely because a feature is common in similar tools or seems generally useful.

## Candidate lifecycle

```text
Draft → Proposed / Needs investigation → Ready for review
      → Approved → Promoted
      → Deferred / Rejected
```

`Approved` requires a human approver, an approved route, verification expectations, and a roadmap hash matching the version reviewed. `Promoted` means the deterministic apply tool added the item to the official roadmap.

## Create proposals

From repository evidence:

```text
/propose-roadmap-update
```

When work is too large for the current feature:

```text
/defer-feature-to-roadmap <request/spec/description>
```

The AI should create at most the number configured in `.project-context/roadmap-policy.toml` and must include evidence or source references.

A proposal can also be created directly:

```bash
python tools/project_context/create_roadmap_proposal.py \
  --title "Automatic before/after alignment" \
  --proposal-type deferred-feature \
  --reason "Too large for the first comparison feature" \
  --user-value "Improves repeatability of differential analysis" \
  --source-ref specs/002-before-after/spec.md \
  --verification "Synthetic shifted-profile regression"
```

## Review

```text
/review-roadmap-proposals
```

Review value, evidence, overlap, dependencies, complexity, timing, and whether the item belongs in Spec Kit, a manual workstream, or investigation. AI may recommend a disposition but must not fill human approval fields.

To approve, edit the proposal:

```toml
status = "Approved"
approved_by = "<human name or role>"
approved_at = "2026-08-07T04:00:00+09:00"
management_type = "Spec Kit"
route = "speckit-specify"
verification_required = ["Acceptance scenario and regression test"]
```

## Preview and apply

Preview the exact roadmap diff:

```bash
python tools/project_context/apply_roadmap_update.py \
  .context-work/roadmap/proposals/RM-0001.toml
```

Apply after reviewing the diff:

```bash
python tools/project_context/apply_roadmap_update.py \
  .context-work/roadmap/proposals/RM-0001.toml --apply
```

The tool checks approval, current roadmap hash, duplicates, policy values, and evidence. It creates a backup, updates the proposal to `Promoted`, and records the promotion under `.project-context/generated/`.

## Prepare the next development step

```text
/generate-roadmap-item-change-input .context-work/roadmap/proposals/RM-0001.toml
```

This creates a formal input under `.context-work/roadmap/next-actions/` for `/speckit.specify`, research/plan, or a standard Agent workstream according to the approved route. It does not execute implementation.

## Recommended review triggers

Run proposal discovery after a first-feature approval, feature or milestone completion, `/speckit.converge`, a material blocker, architecture change, pre-release review, or an internal-AI direction review. Do not run it continuously after every small task.
