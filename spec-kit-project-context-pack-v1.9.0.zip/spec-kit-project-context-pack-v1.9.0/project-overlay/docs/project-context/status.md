# Project Status

Last updated: YYYY-MM-DD
Overall state: Planned
Current phase: <current phase>
Active workstream/component: <name or path>
Related Spec Kit feature: <path or none>

## Current goal

<The single outcome currently being pursued.>

## Repository context

- Root project description: `README.md`
- Whole-project map: `docs/project-context/project-map.md`
- Component provenance registry: `.project-context/components.toml`
- Generated inventory: `.project-context/generated/project-inventory.json`

## Spec Kit feature summary

<!-- AUTO:FEATURE_STATUS:START -->
| Feature | Artifacts | Tasks | Derived state |
|---|---|---:|---|
| — | — | — | No feature directories found |

> Derived state reflects Spec Kit artifact/task presence only. It does not describe non-Spec-Kit work or establish acceptance.
<!-- AUTO:FEATURE_STATUS:END -->

## Non-Spec-Kit workstreams

| Workstream/component | Origin | Current state | Evidence | Related spec |
|---|---|---|---|---|
| <component> | manual/imported/generated/external | Planned | <code/tests/docs> | none or path |

## Completed

- <Verified fact only>

## In progress

- <Current work, including work outside Spec Kit>

## Blocked

- <Blocker and required resolution>

## Verification status

| Evidence | Status | Last run | Notes |
|---|---|---|---|
| Unit tests | Not run | — | — |
| Integration tests | Not run | — | — |
| Build/compile | Not run | — | — |
| Numerical regression | Not run | — | — |
| Production-code validation | Not performed | — | Do not claim production applicability |

## Known limitations

- <Limitation>

## Next actions

1. <Next action>
2. <Next action>

## Restart context

Read in this order:

1. `.project-context/generated/copilot-snapshot.md`
2. The active request's Focused context, when a request exists
3. Related component code and its nearest tests
4. The owning requirement/plan documents only when applicable
5. Root `README.md`, full project map, or full roadmap only when the compact snapshot is insufficient

Default to at most 8 relevant files. Record a concrete reason before broader reading.
