# README Maintenance

The root `README.md` belongs to the target product or tool. The context pack never replaces it during installation, but it should evolve after material project changes.

## Responsibility split

| Artifact | Content |
|---|---|
| `README.md` | Stable product purpose, main capabilities, installation, basic usage, supported environment, major structure, maturity, major limitations, links |
| `status.md` | Current implementation work, blockers, verification evidence, next actions |
| `roadmap.md` | Future workstreams and sequencing |
| `project-map.md` | Repository-wide component and provenance map |

README is reviewed after a major feature, release, installation/usage change, public-interface change, structural change, supported-environment change, or major limitation change. Individual task completion normally does not trigger a README update.

## Safe workflow

```text
material project change
  -> refresh project context
  -> assess README drift
  -> generate Draft section proposal
  -> human edits and approves
  -> dry-run diff
  -> explicit apply
  -> backup + re-assessment
```

### Assess

```bash
python tools/project_context/refresh_project_context.py
```

Or in VS Code Chat:

```text
/assess-readme-update
```

The deterministic assessment is stored under `.project-context/generated/`. Semantic review is performed by Copilot using repository evidence.

### Review and approve

Draft proposals are local files:

```text
.context-work/readme/updates/README-UPDATE-xxxx.toml
```

Before approval, edit the proposed wording and confirm:

- only material README content is included
- no planned or unverified work is presented as complete
- protected sections are absent
- `approved_by` is set
- `status = "Approved"`

### Dry-run and apply

```bash
python tools/project_context/apply_readme_update.py \
  .context-work/readme/updates/README-UPDATE-0001.toml
```

After reviewing the diff:

```bash
python tools/project_context/apply_readme_update.py \
  .context-work/readme/updates/README-UPDATE-0001.toml --apply
```

The apply tool updates only exact allowlisted Markdown headings, rejects protected headings, rejects stale proposals when README has changed, and writes a backup under `.context-work/readme/backups/`.

## Policy

Customize `.project-context/readme-policy.toml` for the target repository. Exact heading names matter. Do not add protected headings to the managed list.
