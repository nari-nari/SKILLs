# Project Map

Last reviewed: YYYY-MM-DD

This document covers the whole repository. Spec Kit features are one context source among source code, tests, configuration, documentation, manual additions, generated assets, and imported components.

## Human-maintained overview

- Main product or tool: [describe]
- Primary entry points: [paths]
- Major runtime components: [describe]
- Important external systems or file formats: [describe]

## Repository inventory

<!-- AUTO:PROJECT_INVENTORY:START -->
Run `python tools/project_context/refresh_project_context.py`.
<!-- AUTO:PROJECT_INVENTORY:END -->

## Component notes

Use `.project-context/components.toml` when origin or ownership cannot be inferred from the repository.

## Context gaps

- [Files or components whose purpose is not yet understood]
- [Copied or generated content whose provenance needs confirmation]
