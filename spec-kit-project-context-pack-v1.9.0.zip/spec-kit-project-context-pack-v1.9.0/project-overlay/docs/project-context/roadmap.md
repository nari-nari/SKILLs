# Project Roadmap

Last updated: YYYY-MM-DD

This roadmap includes Spec Kit features and work managed outside Spec Kit. AI-generated ideas remain under `.context-work/roadmap/proposals/` until a human approves and promotes them.

## Milestones

| Milestone | Outcome | Target/Order | Status | Exit criteria |
|---|---|---|---|---|
| M1 | <Outcome> | 1 | Planned | <Criteria> |

## Workstream map

<!-- AUTO:APPROVED_ROADMAP:START -->
| ID | Workstream/component | Management type | Purpose | Depends on | State | Primary location | Verification required | Source proposal |
|---|---|---|---|---|---|---|---|---|
<!-- AUTO:APPROVED_ROADMAP:END -->

> Add AI-discovered work through the proposal and promotion workflow described in [`roadmap-management.md`](roadmap-management.md). A proposal is not committed work until promoted.

## Sequencing rules

- Do not force work into Spec Kit only to make it visible in this roadmap.
- Link a workstream to a Spec Kit feature when the feature artifacts are genuinely its requirements and plan.
- Record manually added or imported components by their actual code/test/document locations.
- Do not start dependent work until required interfaces or evidence are stable.
- Completed tasks or existing files do not automatically establish acceptance.
- Do not promote speculative ideas without project-specific evidence, value, verification expectations, and human approval.

## Change log

<!-- AUTO:ROADMAP_CHANGE_LOG:START -->
| Date | Change | Reason | Approved by |
|---|---|---|---|
<!-- AUTO:ROADMAP_CHANGE_LOG:END -->
