# Context Governance
> Spec Kit is one context source. Repository code, tests, configuration, root documentation, manual additions, and imported components must also be considered.

Last reviewed: 2026-08-06

## 1. Purpose

This document defines how project facts, Spec Kit artifacts, project-wide status, and internal AI advice are stored and reconciled.

## 2. Information classes

### Authoritative

- `.specify/memory/constitution.md`: stable project principles
- `specs/<feature>/spec.md`: intended user-visible behavior and requirements
- `specs/<feature>/research.md`: relevant technical investigation and alternatives
- `specs/<feature>/plan.md`: accepted technical approach
- `specs/<feature>/tasks.md`: actionable work and completion state
- source code, tests, build output, and approved verification records: implementation evidence

### Derived current state

- `docs/project-context/status.md`
- generated feature/task summary under `.project-context/generated/`

Derived documents summarize authoritative artifacts. They must not silently override them.

### Planning

- `docs/project-context/roadmap.md`: feature sequencing, dependencies, and milestones
- `docs/project-context/known-issues.md`: current known limitations and risks

### Unapproved advice

- `ai-exchange/current/prompt.md`
- `ai-exchange/current/response.md`
- `ai-exchange/current/result.md`
- `.context-work/ai-exchange/archive/`

The visible `current/` workspace is local and Git ignored. Completed or superseded sessions are moved to the hidden archive.

### Request working state

- `.context-work/requests/REQ-xxxx/request.md`
- generated downstream inputs such as `speckit-input.md` and `change-input.md`; active internal-AI prompt/response files live under `ai-exchange/current/`

The request brief is a local, reviewable intermediate artifact. It reduces repeated manual prompt entry, but it does not override a specification, plan, task file, constitution, code, or verification evidence.

### Approved exchange records

- `docs/project-context/ai-exchange/records/`

An approved record documents the consultation, proposal dispositions, human approver, affected artifacts, and verification required. It is not itself a requirement unless the corresponding authoritative artifact is updated.

## 3. Change routing

| Change discovered | First authoritative artifact | Possible downstream artifacts |
|---|---|---|
| User-visible behavior or acceptance change | `spec.md` | `plan.md`, `tasks.md`, tests, code |
| Package, algorithm, architecture, module/folder structure | `research.md` or `plan.md` | `tasks.md`, code, tests |
| Work order or implementation decomposition | `tasks.md` | code, tests |
| Implementation defect with unchanged intent | code/tests, possibly a corrective task | status |
| Stable cross-feature principle | constitution | affected specs/plans/tasks |
| Current blocker or evidence change | project status / known issues | roadmap if sequencing changes |

For short user requests, first route through the request brief. The request brief records the proposed route; after approval, the relevant authoritative artifact is updated through the normal rules above.

## 4. Partial updates

- Do not regenerate unaffected artifacts.
- Preserve accepted decisions and completed tasks.
- Add corrective tasks when completed work must be revised.
- Mark obsolete work as Superseded or Deprecated instead of erasing history.
- Run `/speckit.analyze` after material changes to spec, plan, or tasks.
- Run relevant tests and a convergence review after implementation.

## 5. Status vocabulary

Use these states precisely:

- Planned: no implementation evidence yet
- In progress: implementation tasks have started
- Tasks complete: all task checkboxes are complete, but acceptance may remain
- Implemented: code exists for the intended scope
- Test passed: specified automated test was executed and passed
- Validated: required validation evidence meets defined criteria
- Accepted: a human stakeholder approved the result
- Production verified: verified with approved production-level code/data/environment
- Blocked: progress cannot continue without a dependency or decision

Never collapse these states into a single percentage.

## 6. Internal AI boundary

- An AI response is a proposal, not a decision.
- A package or folder-structure suggestion normally belongs in research/plan, not spec.
- A suggestion that changes user-visible behavior must be approved and reflected in spec first.
- Use an allowlist for outbound context. Do not provide the whole repository.
- Deterministic redaction and validation must precede human review.
- No script in this pack transmits data.

## 6.1 Request approval boundary

- The AI may create and revise a request brief before approval.
- The AI must not generate a downstream formal prompt unless interpretation, scope, and readiness are approved.
- Approval of a request authorizes prompt generation, not automatic application of the resulting proposal.
- An internal-AI answer starts a new proposal-review cycle and requires fresh approval before Spec Kit changes.


## 6.2 Pre-plan technical-selection boundary

- After `spec.md` is accepted and before `/speckit.plan`, material framework, package, architecture, storage, algorithm, or distribution choices pass through `.context-work/pre-plan/TP-xxxx/decision.md`.
- Standard-library and self-built options are candidates, not defaults. Dependency count alone is not sufficient evidence.
- Accepted, Accepted with modification, Prohibited, Rejected, Research, validation, and reconsideration conditions must be explicit.
- AI may propose or compare technologies but cannot infer human approval.
- An approved pre-plan decision authorizes generation of a `/speckit.plan` prompt, not dependency installation or implementation.
- Production dependencies are added only after the resulting plan is reviewed and accepted. Explicitly approved disposable PoCs are the only pre-plan exception.
- A changed `spec.md` invalidates the recorded spec hash and requires technical-selection review.

## 6.3 Visible internal-AI workspace boundary

- Human copy/paste work occurs only under `ai-exchange/current/`.
- `.context-work` remains the location for request, pre-plan, roadmap, and archived exchange state.
- Starting a consultation creates `prompt.md`, an empty `response.md`, `result.md`, `session.toml`, and a linked README.
- Import routing is determined by session type and source path; users do not choose or create hidden response files.
- A processed session remains visible until the next consultation starts, when it is archived automatically.
- Current exchange files are excluded from Git and from project inventory/context snapshots.

## 7. Decision recording threshold

Use `docs/project-context/key-decisions.md` only when a decision is cross-feature, costly to reverse, has credible alternatives, or is likely to be questioned later. Feature-local choices belong in the feature's `research.md` or `plan.md`.

## 8. Root README maintenance

- The installer must not replace the target repository's root `README.md`.
- The root README remains an authoritative human-facing description of the product or tool and should be updated after material milestones.
- Daily progress and transient blockers belong in `status.md`, not README.
- README changes follow assessment, Draft proposal, human edit, explicit approval, dry-run diff, and limited application.
- Deterministic application is limited to exact headings allowlisted by `.project-context/readme-policy.toml`.
- Protected sections cannot be modified by the apply tool.
- A proposal is invalid if README changed after the proposal hash was recorded.

## 9. Roadmap proposal boundary

- `docs/project-context/roadmap.md` contains approved planning commitments and sequencing information.
- `.context-work/roadmap/proposals/` contains unapproved AI or human candidates.
- AI may create and revise candidates, but cannot infer approval or directly promote them.
- A candidate requires project-specific evidence or an explicit deferred requirement; generic feature popularity is insufficient.
- Promotion requires a human approver, a reviewed route, verification expectations, a current roadmap hash, and a deterministic diff.
- Approval authorizes roadmap promotion only. It does not authorize implementation.
- Promoted items must still pass the normal request, Spec Kit, or standard-Agent planning and implementation gates.



## Context retrieval budget

- Generate `.project-context/generated/copilot-snapshot.md` with the deterministic refresh command.
- Read the snapshot before opening the root README, full roadmap, full project map, or multiple feature directories.
- A request brief should list Must read, Read only if needed, and Excluded paths.
- The default working set is at most 8 relevant files; broader reading requires a concrete reason.
- Generated inventories are search indexes, not text to paste wholesale into an AI conversation.
- Prefer a new bounded chat with a request or generated input over carrying a long conversation history.
