# Key Cross-Feature Decisions

This file is intentionally small. Record only decisions that affect multiple features, are costly to reverse, have credible alternatives, or are likely to be questioned later.
Feature-local decisions belong in the feature's `research.md` or `plan.md`.

| ID | Date | Status | Decision | Context and rationale | Alternatives | Consequences | Superseded by |
|---|---|---|---|---|---|---|---|
| KD-001 | YYYY-MM-DD | Proposed | <decision> | <why> | <alternatives> | <trade-offs> | — |

Allowed status values: Proposed, Accepted, Rejected, Deprecated, Superseded.
