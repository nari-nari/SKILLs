# New Project Bootstrap with Internal AI and Spec Kit

既存コードや文書がほとんどない新規プロジェクトでは、最初のFeatureだけ社内AIとの要求整理から開始します。

## 最短手順

```text
/start-new-project-ai-intake
```

または、プロジェクトルートの次を直接開きます。

```text
ai-exchange/templates/new-project-intake.md
```

相談を開始すると、ユーザーが使うファイルは次へ生成されます。

```text
ai-exchange/current/
├── README.md
├── prompt.md
├── response.md
├── result.md
└── session.toml
```

## 推奨フロー

```text
人間が3項目だけ入力
  ↓
ai-exchange/current/prompt.mdを社内AIへ貼る
  ↓
社内AIが最大3件の推奨案付き質問
  ↓
人間が社内AI上で修正・選択
  ↓
最終回答をcurrent/response.mdへ貼る
  ↓
/import-current-internal-ai-response
  ↓
current/result.mdに/speckit.specify入力を生成
  ↓
人間が確認して/speckit.specifyを実行
```

## 手入力する基本項目

1. 作りたいもの
2. 分かっている制約
3. 最初に実現したいこと

パッケージ、フォルダ構成、クラス設計などは最初の仕様へ混ぜず、`/speckit.plan`への引き継ぎ事項として分けます。

## Spec Kitへ渡した後

1. `/speckit.specify`で`spec.md`を生成する。
2. 生成内容を人間が確認する。
3. 必要なら`/speckit.clarify`を実行する。
4. `python tools/project_context/refresh_project_context.py`を実行する。
5. 技術選定が必要なら`/pre-plan-intake`へ進む。
6. 以後の変更は`/request-intake`を入口にする。

## 注意事項

- 社内AIの推奨案は承認前の提案です。
- 最初のFeatureへ構想全体を詰め込まないでください。
- 技術選択を利用者要求として`spec.md`へ混入させないでください。
- 実測データや実環境が利用できない場合は、成功条件と未検証事項を分けてください。
- `.context-work`配下へ回答ファイルを作る必要はありません。
