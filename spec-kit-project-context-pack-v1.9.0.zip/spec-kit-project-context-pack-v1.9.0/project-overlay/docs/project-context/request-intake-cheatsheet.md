# `/request-intake` Cheat Sheet

`/request-intake`は既存プロジェクトの共通入口です。常に詳細受付を作るのではなく、最初に低コストで専門コマンドへ振り分けます。

## 最短の選び方

| 状況 | 入力 |
|---|---|
| 専門コマンドだけ知りたい | `/request-intake quick ...` |
| 通常の機能追加・不具合・相談 | `/request-intake ...` |
| パッケージ統合・移行・横断変更 | `/request-intake deep ...` |

## モード

### Quick

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
```

スナップショットだけを読み、質問せず、`request.md`も作らず、専門コマンドを1つ返します。

### Standard

```text
/request-intake [feature] 同じ.ncを再度開いたとき前回の解析範囲を復元したい
```

既定モードです。単純作業は専門コマンドへ送り、仕様・複数領域・承認が必要な変更だけ`request.md`を作ります。

### Deep

```text
/request-intake deep [refactor] packages配下の2パッケージを統合したい
```

横断調査が必要な変更です。必ず`request.md`を作り、依存関係と段階計画を整理します。

## 任意ヒント

```text
[feature] [bug] [research] [refactor] [docs]
[roadmap] [validation] [import] [context] [unknown]
```

例：

```text
/request-intake [bug] CSVの出力範囲が画面表示と一致しない
/request-intake [research] Windows配布方式を社内AIに比較してもらいたい
/request-intake [roadmap] 自動位置合わせを今回のPoCから延期したい
/request-intake [import] 別プロジェクトのnetCDF読込処理を登録したい
```

## `request.md`を作らない代表例

```text
/request-intake quick [docs] READMEに新機能を反映したい
/request-intake quick [context] プロジェクト文脈を更新したい
/request-intake quick [roadmap] 実装後の将来候補を探したい
```

## `request.md`を作る代表例

```text
/request-intake [feature] 試験前後比較を追加したい
/request-intake [research] GUIと設定保存方式を社内AIに比較してもらいたい
/request-intake deep [refactor] 2パッケージを統合して公開APIを整理したい
```

## `/project-context-help`との違い

- 目的が分かる：専門コマンドまたは`/request-intake`
- 入口も入力方法も分からない：まず`START-HERE.md`
- 対話形式の案内が必要：最後に`/project-context-help`

`/project-context-help`を毎回前段に置く必要はありません。


## 仕様後の技術選定

```text
/request-intake quick [research] spec完成後のGUIパッケージをplan前に選定したい
```

推奨先：

```text
/pre-plan-intake <feature path> <短い技術選定意図>
```

## 社内AI相談へ進んだ後

汎用相談でもpre-planでも、現在のファイルは同じ場所です。

```text
ai-exchange/current/README.md
ai-exchange/current/prompt.md
ai-exchange/current/response.md
```

最終回答を`response.md`へ貼った後は、共通して次を実行します。

```text
/import-current-internal-ai-response
```
