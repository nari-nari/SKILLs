# Internal AI Exchange Policy

日常操作の入口は、プロジェクトルートの[`ai-exchange/README.md`](../../../ai-exchange/README.md)です。現在のプロンプトと回答は常に`ai-exchange/current/`へ置きます。この文書は保存・承認・開示境界の詳細規則です。

## Human-facing locations

- `ai-exchange/templates/`: すぐ開ける相談テンプレート
- `ai-exchange/current/prompt.md`: 現在社内AIへ送る内容
- `ai-exchange/current/response.md`: 作成済みの回答貼り付け先
- `ai-exchange/current/result.md`: Copilotによる取り込み結果
- `ai-exchange/current/README.md`: 現在の状態と次の操作

## Internal locations

- `.context-work/ai-exchange/archive/`: 完了・中断した交換履歴。Git ignored
- `.context-work/requests/`: 汎用依頼と承認の正本
- `.context-work/pre-plan/`: 技術選定判断と承認の正本
- `records/`: リポジトリへ残すことが承認された要約記録

ユーザーに`.context-work`配下の回答ファイルを新規作成させないでください。

## New-project first Feature

`ai-exchange/templates/new-project-intake.md`または`/start-new-project-ai-intake`を使用します。人間が記入する基本項目は「作りたいもの」「分かっている制約」「最初に実現したいこと」です。社内AIの最終回答をcurrentの`response.md`へ貼り、`/import-current-internal-ai-response`で`/speckit.specify`入力を作ります。

## General consultation

承認済みrequest.mdから`/export-approved-request-to-internal-ai`を実行します。currentへプロンプトと空の回答ファイルが生成されます。回答はrequestへ未承認提案として戻されます。

## Pre-plan technology selection

`/prepare-internal-ai-technical-selection <decision.md>`を実行します。currentへ技術比較プロンプトが生成されます。回答はAccepted、Prohibited、Rejected、Research候補としてdecision.mdへ未承認状態で戻されます。

## Outbound process

1. 相談目的を一つに絞る。
2. 最小限の許可済み文書を選ぶ。
3. currentの`prompt.md`を生成する。
4. 必要なら`build_ai_context.py`と`validate_ai_context.py`で補助資料を検査する。
5. 人間が開示内容を確認する。
6. 承認された社内インターフェースへ手動で送る。

## Inbound process

1. 社内AIの最終回答をcurrentの`response.md`へ貼る。
2. `/import-current-internal-ai-response`を実行する。
3. session typeに応じて回答を分類する。
4. currentの`result.md`とsource正本の未承認案を確認する。
5. 人間が採否を承認する。
6. 承認済み変更だけを正本へ適用し、必要な解析・テストを行う。

## Prohibited shortcuts

- リポジトリ全体を貼らない。
- LLMだけを機密情報フィルターにしない。
- 社内AI回答を承認済み仕様として扱わない。
- 魅力的な技術提案に合わせて要求を改変しない。
- currentのプロンプトや回答をGitへコミットしない。
