# Internal AI Consultation Brief

Consultation ID: `<YYYYMMDD-topic>`
Date: `YYYY-MM-DD`
Prepared by: `<name/role>`
Disclosure reviewed by: `<name/role or pending>`
Related feature(s): `specs/<feature>/`

## Decision or question

<One specific decision or question.>

## Desired answer format

- <comparison table / prioritized recommendation / risk review / PoC plan>

## Confirmed facts

- <Fact with source>

## Assumptions

- <Assumption that may be challenged>

## Current approach

<Current behavior or technical approach.>

## Constraints

- <Platform, license, offline, confidentiality, performance, validation constraints>

## Alternatives already considered

| Alternative | Result so far | Evidence or reason |
|---|---|---|
| <A> | <status> | <reason> |

## Verification evidence

| Evidence | Status | Limitation |
|---|---|---|
| <test> | <passed/not run> | <limitation> |

## Questions

1. <Question>
2. <Question>

## Explicit exclusions

- No production source code
- No raw proprietary data
- No customer, product, employee, or system identifiers
- No credentials or unrestricted paths
