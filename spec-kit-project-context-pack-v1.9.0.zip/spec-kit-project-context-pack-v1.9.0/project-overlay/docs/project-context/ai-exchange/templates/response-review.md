# Internal AI Response Review

Review ID: `<YYYYMMDD-topic-review>`
Consultation ID: `<source consultation ID>`
Date: `YYYY-MM-DD`
Reviewer: `<name/role>`
Approval status: Draft

## Response summary

<Neutral summary.>

## Proposal dispositions

| ID | Proposal | Decision | Reason | Risk | Destination | Required verification |
|---|---|---|---|---|---|---|
| P01 | <proposal> | Investigate | <reason> | <risk> | `research.md` | <PoC/test> |

Allowed decisions: Accept, Accept with modification, Investigate, Defer, Reject, Already implemented, Not applicable.

## Approved requirement changes

- <Only user-visible changes explicitly approved>

## Approved technical changes

- <Only accepted package, architecture, module, data, or folder changes>

## Approved task changes

- <Concrete work to add>

## Rejected or deferred proposals

- <Proposal and reason>

## Affected artifacts

- [ ] `spec.md`
- [ ] `research.md`
- [ ] `plan.md`
- [ ] `tasks.md`
- [ ] constitution
- [ ] project status
- [ ] roadmap
- [ ] key decision

## Required workflow

1. <Artifact update>
2. `/speckit.analyze`
3. <Implementation scope>
4. <Tests>
5. `/speckit.converge` or equivalent review
6. Project-status update

## Human approval

Approved by: `<name/role or pending>`
Approved date: `<date or pending>`
Approved scope: `<exact accepted proposal IDs>`
