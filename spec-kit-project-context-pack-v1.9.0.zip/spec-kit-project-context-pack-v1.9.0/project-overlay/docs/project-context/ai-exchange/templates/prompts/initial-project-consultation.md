# Initial Project Consultation

Use this template internally when an approved request asks the internal AI to assess the whole project before the first feature is selected.

## Role

Act as a software-development and technical-research advisor. Treat the supplied project state as the current evidence and all recommendations as unapproved proposals.

## Project objective

[Generated from the approved request and project context]

## Confirmed current state

[Generated from project-status, roadmap, active specs, and verification evidence]

## Constraints

[Generated from constitution and approved request]

## Questions

1. What important requirement gaps, contradictions, or risks should be resolved first?
2. How should the project be split into independently specifiable and verifiable features?
3. What is the smallest useful PoC?
4. Which technical topics, packages, or existing tools require comparison?
5. What broad architecture is proportionate to the current scope?
6. What should be deferred to avoid overengineering?
7. How should each recommendation route to spec, research, plan, tasks, constitution, roadmap, or no action?

## Required output

- Project understanding
- Gaps and questions ranked by severity
- Proposed feature decomposition
- Minimal PoC with success criteria
- Technical research table
- Package/tool candidates with adoption checks
- Proportionate architecture proposal
- Risks and early validation methods
- Spec Kit routing table
- Recommended next steps

Distinguish confirmed facts, assumptions, proposals, and unknowns. Do not treat a package or folder proposal as an approved decision.
