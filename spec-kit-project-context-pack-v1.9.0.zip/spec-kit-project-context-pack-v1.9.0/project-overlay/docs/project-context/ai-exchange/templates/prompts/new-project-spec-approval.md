# New Project Spec Approval — Short Reply

仕様確定案を確認した後、`/speckit.specify`用の正式入力を生成させるための返信です。

```text
この内容で最初のFeatureの仕様を確定します。
`/speckit.specify`用の正式プロンプトを生成してください。
```

一部を条件付きで承認する場合は、次を使用します。

```text
以下の修正を反映することを条件に承認します。

- [最終修正事項]

修正後の確定内容を示したうえで、`/speckit.specify`用の正式プロンプトを生成してください。
```
