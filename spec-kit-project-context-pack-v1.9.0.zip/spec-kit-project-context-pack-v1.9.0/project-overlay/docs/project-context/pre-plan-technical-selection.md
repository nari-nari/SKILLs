# Pre-plan Technical Selection

`/speckit.specify`で要求を確定した後、`/speckit.plan`の前に技術選定を明示的に承認する工程です。

## 最短手順

```text
/pre-plan-intake specs/001-single-file-analysis GUIは対話的な範囲編集とD&Dを満たすものを選びたい
```

判断の正本は次へ生成されます。

```text
.context-work/pre-plan/TP-0001/decision.md
```

社内AI比較を準備します。

```text
/prepare-internal-ai-technical-selection .context-work/pre-plan/TP-0001/decision.md
```

現在のやり取りは、隠しフォルダではなく次へ生成されます。

```text
ai-exchange/current/prompt.md
ai-exchange/current/response.md
ai-exchange/current/README.md
```

社内AIとの対話後、最終回答を`response.md`へ貼り、共通コマンドを実行します。

```text
/import-current-internal-ai-response
```

Copilotは`session.toml`からpre-plan相談であることを認識し、回答をAccepted、Accepted with modification、Prohibited、Rejected、Research候補としてdecision.mdへ未承認状態で反映します。

人間がdecision.mdを確認・承認した後にplan入力を生成します。

```text
/prepare-speckit-plan-input specs/001-single-file-analysis .context-work/pre-plan/TP-0001/decision.md
```

planを人間が確認・承認した後、依存追加コマンドを生成します。

```text
/prepare-approved-dependency-install specs/001-single-file-analysis/plan.md .context-work/pre-plan/TP-0001/decision.md
```

## 原則

- standard libraryは候補の一つであり既定解ではない。
- AcceptedとProhibitedを両方明示する。
- planが承認されるまでproduction dependencyを追加しない。
- PoCで使ったパッケージを自動的に本採用しない。
- specが変更されたら既存pre-plan判断を再検証する。
- 社内AI回答の貼り付け先は常に`ai-exchange/current/response.md`とする。
