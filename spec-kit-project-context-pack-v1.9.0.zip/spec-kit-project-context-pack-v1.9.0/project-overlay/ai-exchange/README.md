# Internal AI exchange

社内AIとの現在のやり取りは、すべて[`current/`](current/)で行います。

## 現在の相談

1. [`current/README.md`](current/README.md)を開く。
2. [`current/prompt.md`](current/prompt.md)を社内AIへコピーする。
3. 社内AIとの対話を終えたら、最終回答を[`current/response.md`](current/response.md)へ貼る。
4. Copilot Chatで`/import-current-internal-ai-response`を実行する。
5. 取り込み結果を[`current/result.md`](current/result.md)で確認する。

回答ファイルは相談開始時に作成済みです。ユーザーが`.context-work`配下へ新規ファイルを作る必要はありません。

## 相談の開始方法

### 新規プロジェクトの最初の機能

[`templates/new-project-intake.md`](templates/new-project-intake.md)を開くか、次を実行します。

```text
/start-new-project-ai-intake
```

### 既存プロジェクトについて広く相談

```text
/request-intake [research] Windows配布方式を社内AIに比較してもらいたい
```

### spec完成後の技術選定

```text
/pre-plan-intake specs/001-feature GUIフレームワークをplan前に選定したい
```

## テンプレート

- [`templates/new-project-intake.md`](templates/new-project-intake.md)
- [`templates/general-consultation.md`](templates/general-consultation.md)
- [`templates/pre-plan-technology-selection.md`](templates/pre-plan-technology-selection.md)

## 保存場所の役割

- `ai-exchange/current/`: ユーザーが現在操作する場所
- `.context-work/ai-exchange/archive/`: 完了・中断した相談の履歴
- `.context-work/requests/`、`.context-work/pre-plan/`: 依頼・承認・判断の正本
- `docs/project-context/ai-exchange/`: 詳細な規則と説明

`current/`はGit管理対象外です。社内AI回答や作業中プロンプトを誤ってコミットしないでください。
