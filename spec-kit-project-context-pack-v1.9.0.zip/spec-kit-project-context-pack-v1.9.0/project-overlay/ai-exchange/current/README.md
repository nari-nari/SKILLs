# Current internal AI exchange

現在進行中の社内AI相談はありません。

## Start here

- 新規プロジェクトの初回仕様整理: `ai-exchange/templates/new-project-intake.md`
- 既存プロジェクトの相談: `/request-intake [research] ...`
- spec完成後の技術選定: `/pre-plan-intake ...`

相談を開始すると、このフォルダに`prompt.md`と空の`response.md`が自動作成されます。
