# Internal AI prompt

