---
name: 'Spec Kit artifact governance'
description: 'Rules applied only while working on Spec Kit artifacts.'
applyTo: 'specs/**/*.md,.specify/**/*.md'
---

# Spec Kit artifact governance

- Read the target feature artifacts only; do not load every feature.
- Put user-visible behavior in `spec.md`, technical choices in `research.md`/`plan.md`, and work decomposition in `tasks.md`.
- After specification and before material package/framework/architecture planning, require an approved pre-plan decision; do not default to standard-library choices or install production dependencies early.
- Preserve unrelated requirements, decisions, task IDs, and completed-task history.
- Do not convert unapproved AI advice into an authoritative artifact.
- After material cross-artifact changes, run the relevant consistency analysis and tests.
- Do not infer acceptance or production readiness from task completion.
