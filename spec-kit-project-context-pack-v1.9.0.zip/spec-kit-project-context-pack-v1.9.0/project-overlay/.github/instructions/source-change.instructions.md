---
name: 'Focused source changes'
description: 'Keep code changes and context retrieval narrowly scoped.'
applyTo: 'src/**/*,app/**/*,lib/**/*,packages/**/*,tests/**/*,test/**/*'
---

# Focused source changes

- Identify the affected component and its nearest tests before reading unrelated files.
- Prefer symbol/path search and the generated inventory over broad text search.
- Do not perform unrelated refactoring.
- Preserve external behavior unless the approved requirement changes it.
- Run the smallest relevant tests first, then broader regression checks when justified.
- Report unverified assumptions and unavailable production data explicitly.
