# Project context pack

- For context-sensitive work, read `.project-context/generated/copilot-snapshot.md` first. Refresh it only when missing, stale, or after material structural/status changes.
- Open only files relevant to the current request or component. Do not scan the full repository, all specs, or all tests by default.
- Use deterministic scripts for inventory, validation, diffs, and approved application before asking AI to reproduce those operations.
- Treat Spec Kit as one context source; include manual, imported, generated, and non-Spec-Kit components when relevant.
- Keep confirmed facts, assumptions, AI proposals, approvals, implementation, and verification states distinct.
- Never promote AI advice, request briefs, README proposals, or roadmap proposals without the required human approval.
- Stop at the requested stage and keep outputs concise.

Detailed rules are path-scoped under `.github/instructions/` and documented in `docs/project-context/`.
