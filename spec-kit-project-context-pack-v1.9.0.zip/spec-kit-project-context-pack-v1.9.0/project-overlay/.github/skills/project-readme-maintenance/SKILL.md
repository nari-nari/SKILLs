---
name: project-readme-maintenance
description: Keep the repository root README aligned with material project changes using assessment, human approval, allowlisted section updates, stale-proposal detection, and backups. Use after releases, major features, installation or usage changes, public-interface changes, structural changes, or important limitation changes.
argument-hint: '[milestone or approved README proposal]'
---

# Project README maintenance

The root `README.md` is a human-facing product artifact. The installer protects it, but material development changes should be reflected through a reviewed workflow.

## Sources

Read:

- [README policy](../../../.project-context/readme-policy.toml)
- root `README.md`
- [project status](../../../docs/project-context/status.md)
- [roadmap](../../../docs/project-context/roadmap.md)
- [project map](../../../docs/project-context/project-map.md)
- code, tests, configuration, and Git diff relevant to the milestone

## Workflow

1. Run `python tools/project_context/refresh_project_context.py`.
2. Assess whether README needs a material update.
3. Create a Draft TOML proposal under `.context-work/readme/updates/` using the provided template.
4. Limit changes to policy-managed headings. Never include protected headings.
5. Keep planned, implemented, tested, validated, accepted, and production-verified states distinct.
6. Ask the user to review and edit the Draft proposal.
7. Require `status = "Approved"`, a named `approved_by`, and an unchanged README hash.
8. Run the apply tool without `--apply` and show the diff.
9. Apply only after explicit approval. The tool creates a local backup.
10. Re-run README assessment and context consistency checks.

Do not put daily progress, transient blockers, or full task history into README. Link to project-context documents for detail.
