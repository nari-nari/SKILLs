---
name: pre-plan-technical-selection
description: Select and approve material technologies after specification and before planning, without defaulting to the standard library or installing production dependencies early.
argument-hint: '[feature path or TP decision path]'
---

# Pre-plan technical selection

Read [pre-plan workflow](../../../docs/project-context/pre-plan-technical-selection.md), the target `spec.md`, and the pre-plan decision template.

1. Create or continue `.context-work/pre-plan/TP-xxxx/decision.md`.
2. Compare external package, standard-library, and self-built candidates against requirements, distribution, license, offline, testing, and maintenance constraints.
3. Recommend first; ask at most three high-impact questions.
4. Record Accepted, Accepted with modification, Prohibited, Rejected, Research, validation, and reconsideration conditions.
5. Do not infer approval, run `/speckit.plan`, modify dependencies, or implement code.
6. Validate approval and current spec hash before generating plan input.
7. Add production dependencies only after the resulting plan is reviewed. A disposable PoC requires explicit approval and does not imply production adoption.
