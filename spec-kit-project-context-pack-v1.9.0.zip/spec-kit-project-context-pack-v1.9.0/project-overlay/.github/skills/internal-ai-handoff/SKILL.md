---
name: internal-ai-handoff
description: Prepare, validate, review, and record controlled exchanges with an internal AI through the visible ai-exchange/current workspace.
argument-hint: '[topic or current response]'
---

# Internal AI handoff

Read [visible exchange guide](../../../ai-exchange/README.md), [AI exchange policy](../../../docs/project-context/ai-exchange/README.md), and [context governance](../../../docs/project-context/context-governance.md).

## Human-facing workspace

- Use `ai-exchange/current/` for the active prompt, response, result, and instructions.
- Create `response.md` when the consultation starts; never ask the user to create a file under `.context-work`.
- Always show clickable paths to `README.md`, `prompt.md`, and `response.md`.

## Outbound consultation

1. Define one decision or question.
2. Select minimum allowlisted sources.
3. Use the relevant template from `ai-exchange/templates/`.
4. Where needed, use `build_ai_context.py` and `validate_ai_context.py` for supporting context.
5. Use `create_ai_exchange_session.py` to prepare `ai-exchange/current/`.
6. Require human disclosure review before manual transmission.
7. Never send content automatically.

## Inbound response

1. Read `ai-exchange/current/session.toml` and `response.md`.
2. Treat the response as unapproved advice.
3. Route by session type: new-project, general request, pre-plan, roadmap, or other.
4. Store the processed summary in `ai-exchange/current/result.md`.
5. Apply only explicitly accepted proposals.
6. Mark the session processed; archive it automatically when the next exchange begins.

Do not rely solely on model-based redaction.
