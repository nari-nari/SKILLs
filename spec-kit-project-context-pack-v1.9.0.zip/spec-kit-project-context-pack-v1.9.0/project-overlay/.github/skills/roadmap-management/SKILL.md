---
name: roadmap-management
description: Discover, review, approve, promote, and prepare future project work while keeping AI-generated candidates separate from the official roadmap.
argument-hint: '[proposal path, source feature, or review trigger]'
---

# Roadmap management

Read [roadmap management](../../../docs/project-context/roadmap-management.md), [roadmap policy](../../../.project-context/roadmap-policy.toml), the official [roadmap](../../../docs/project-context/roadmap.md), project status, project map, known issues, verification evidence, and relevant Spec Kit or non-Spec-Kit artifacts.

## Discovery

- Create candidates only when supported by an approved deferred scope, implementation/verification evidence, repeated known issue, dependency, or reviewed internal-AI research.
- Separate current-scope corrections from future roadmap work.
- Limit a discovery pass to the configured maximum.
- State evidence, value, dependencies, complexity, confidence, verification, and why the item is not current work.
- Never promote directly during discovery.

## Review

- Detect duplicates and overlapping proposals.
- Distinguish `Needs investigation`, `Deferred`, and `Rejected` from approved future work.
- Recommend a route: new Spec Kit feature, research/plan, manual workstream, investigation, or documentation only.
- Do not fill `approved_by` or infer human approval.

## Promotion

- Validate an Approved proposal with `validate_roadmap_proposal.py --require-approved`.
- Preview the deterministic diff before applying.
- Apply only after explicit human approval and only through `apply_roadmap_update.py --apply`.
- Do not edit the official roadmap freely when the deterministic route is available.

## Continuation

For a promoted item, generate the next formal input according to its approved route. Do not start implementation automatically.
