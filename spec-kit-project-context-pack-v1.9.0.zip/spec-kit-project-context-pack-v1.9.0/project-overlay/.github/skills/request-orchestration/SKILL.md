---
name: request-orchestration
description: Route a short request cheaply, create a reviewed request brief only when needed, then generate an approved internal-AI, Spec Kit, or standard-agent input.
argument-hint: '[quick|standard|deep] [hint] short request or request.md path'
---

# Request orchestration

Read [request orchestration](../../../docs/project-context/request-orchestration.md), [intake cheat sheet](../../../docs/project-context/request-intake-cheatsheet.md), and [request brief template](../../../.project-context/templates/request-brief.md).

## Triage first

1. Parse mode and hint with `tools/project_context/parse_request_intake.py`.
2. Read the compact snapshot first.
3. Use a specialist command without creating a request when the operation is deterministic and narrow.
4. Do not require `/project-context-help` before intake.

## Modes

- Quick: snapshot-only route recommendation, no questions, no request file.
- Standard: direct route for simple operations; otherwise create a reviewed request with at most eight relevant files.
- Deep: always create a request and perform bounded cross-component investigation.

## Detailed intake

Record explicit intent, confirmed facts, proposed interpretation, assumptions, scope, open decisions, routing, intake mode, hint, and triage reason. Ask at most three high-impact questions. Do not modify authoritative artifacts before approval.

## Approval

Require `status: Approved`, a decided route, and all three approval checkboxes. Validate with `tools/project_context/validate_request.py`.

## Export

Generate only the approved downstream input. Internal-AI output remains unapproved advice and must return through review before application.
