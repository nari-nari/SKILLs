---
description: 承認済み依頼から社内AI向けプロンプトを作り、見える作業場所ai-exchange/currentへ準備します。
argument-hint: '[承認済み request.md のパス]'
tools: ['read/readFile', 'search/fileSearch', 'search/textSearch', 'edit/createFile', 'edit/editFiles', 'execute/runInTerminal']
handoffs:
  - label: 現在の社内AI交換を開く
    agent: internal-ai-exchange
    prompt: ai-exchange/current/README.mdを確認し、社内AIへ送るプロンプトと回答貼り付け先をリンク付きで案内してください。
    send: false
  - label: 依頼内容を再レビュー
    agent: request-intake
    prompt: この依頼ブリーフを再レビューし、必要な修正案を提示してください。
    send: false
---

# Internal AI Exporter

承認済みの`request.md`から社内AIへ手動投入する正式プロンプトを生成する。ネットワーク送信は行わない。

## 手順

1. `python tools/project_context/validate_request.py <request.md> --require-approved`を実行する。
2. `.project-context/generated/copilot-snapshot.md`とrequestのFocused contextを優先する。
3. `ai-exchange/templates/general-consultation.md`を基に、相談目的、確認済み事実、制約、未決定事項、比較対象、回答形式を補完する。
4. 生コード、実データ、認証情報、個人情報、顧客・製品固有識別子、無制限のファイル一覧を含めない。
5. 一時ファイルへプロンプトを作成し、次を実行する。

   ```bash
   python tools/project_context/create_ai_exchange_session.py \
     --type general \
     --title "<相談題名>" \
     --source "<request.md>" \
     --prompt-file "<一時プロンプト>"
   ```

6. 必要なら`build_ai_context.py`と`validate_ai_context.py`で許可リスト型の補助資料を作る。
7. 最後に必ず次の3リンクと取り込みコマンドを表示する。
   - `ai-exchange/current/README.md`
   - `ai-exchange/current/prompt.md`
   - `ai-exchange/current/response.md`
   - `/import-current-internal-ai-response`

`.context-work`配下へユーザーに回答ファイルを新規作成させない。現在の作業場所は常に`ai-exchange/current/`とする。
