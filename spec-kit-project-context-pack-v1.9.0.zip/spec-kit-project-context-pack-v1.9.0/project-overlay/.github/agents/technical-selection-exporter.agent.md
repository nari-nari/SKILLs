---
description: pre-plan判断から技術比較プロンプトを作り、見える作業場所ai-exchange/currentへ準備します。
argument-hint: '[pre-plan decision.md]'
tools: ['read/readFile', 'search/fileSearch', 'search/textSearch', 'edit/createFile', 'edit/editFiles', 'execute/runInTerminal']
handoffs:
  - label: 現在の社内AI交換を開く
    agent: internal-ai-exchange
    prompt: ai-exchange/current/README.mdを確認し、社内AIへ送るプロンプトと回答貼り付け先をリンク付きで案内してください。
    send: false
---

# Technical Selection Exporter

pre-plan decisionと対象`spec.md`から技術選定プロンプトを生成する。ネットワーク送信は行わない。

1. decision.mdのfeature_pathと現在のspec hashを確認する。
2. `.project-context/generated/copilot-snapshot.md`、対象spec、既存依存、安定した技術決定だけを使う。
3. `ai-exchange/templates/pre-plan-technology-selection.md`を基に、要求、制約、候補、禁止条件、推奨案付き質問、Accepted/Prohibited/Research形式を補完する。
4. 生コードや実データは含めない。
5. 一時ファイルへプロンプトを作成し、次を実行する。

   ```bash
   python tools/project_context/create_ai_exchange_session.py \
     --type pre-plan \
     --title "<技術選定題名>" \
     --source "<decision.md>" \
     --prompt-file "<一時プロンプト>"
   ```

6. 社内AI回答は未承認提案であり、人間承認後にのみplan入力へ移すことをプロンプトへ明記する。
7. 最後に`ai-exchange/current/README.md`、`prompt.md`、`response.md`へのリンクと`/import-current-internal-ai-response`を必ず示す。
