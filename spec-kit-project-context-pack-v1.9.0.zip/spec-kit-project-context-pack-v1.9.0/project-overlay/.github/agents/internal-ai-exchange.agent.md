---
description: ai-exchange/currentを唯一の人間向け作業場所として、社内AI回答を種類別に取り込みます。
argument-hint: '[任意: 社内AIの最終回答本文]'
tools: ['read/readFile', 'search/fileSearch', 'search/textSearch', 'edit/createFile', 'edit/editFiles', 'execute/runInTerminal']
handoffs:
  - label: 新規FeatureのSpec Kit入力を確認
    agent: speckit-router
    prompt: ai-exchange/current/result.mdに生成された/speckit.specify入力をレビューし、実行前の修正点を提示してください。
    send: false
  - label: 技術選定判断を確認
    agent: pre-plan-curator
    prompt: ai-exchange/current/result.mdとsource decision.mdをレビューし、未承認の技術判断候補を提示してください。
    send: false
  - label: 汎用相談結果を確認
    agent: request-intake
    prompt: ai-exchange/current/result.mdとsource request.mdをレビューし、採否と次工程を提示してください。
    send: false
---

# Internal AI Exchange

ユーザーが直接操作する場所は`ai-exchange/current/`だけとする。

## 取り込み手順

1. `ai-exchange/current/session.toml`を読み、`id`、`type`、`source_path`を確認する。
2. ユーザーがチャット引数として回答本文を渡した場合、その本文を`ai-exchange/current/response.md`へ保存する。
3. `python tools/project_context/validate_current_ai_exchange.py --require-response`を実行する。
4. 回答を未承認の助言として扱い、typeに応じて処理する。

### new-project

- 回答から承認済み仕様理解、未決定事項、後続Feature、planへ渡す事項を分ける。
- `/speckit.specify`へそのまま渡せる入力を`ai-exchange/current/result.md`へ生成する。
- Spec Kit成果物を自動生成・変更しない。

### general

- `source_path`のrequest.mdを読み、回答をAccept、Accept with modification、Investigate、Defer、Rejectへ分類する。
- request.mdの提案・未決定事項・推奨ルートへ未承認案として反映する。
- `ai-exchange/current/result.md`へ反映内容と次の承認事項を書く。
- 人間承認前にspec、plan、tasks、コードを変更しない。

### pre-plan

- `source_path`のdecision.mdを読み、回答をAccepted、Accepted with modification、Prohibited、Rejected、Research候補へ整理する。
- decision.mdへ未承認案として反映するが、statusやapproved_byを設定しない。
- `ai-exchange/current/result.md`へ差分と承認事項を書く。

### roadmap / other

- 根拠、価値、依存関係、確信度を整理し、正式文書へ直接反映せずresult.mdへ候補を書く。

5. 処理後、次を実行する。

   ```bash
   python tools/project_context/mark_ai_exchange_session.py --status processed
   ```

6. 最後に必ず次をリンク付きで表示する。
   - `ai-exchange/current/result.md`
   - source_path（存在する場合）
   - `ai-exchange/current/README.md`
7. 次の相談開始時、processed済みcurrentは自動的に`.context-work/ai-exchange/archive/<AI-ID>/`へ退避される。

ユーザーへ`.context-work`配下の回答ファイル作成を求めない。
