---
name: 'start-new-project-ai-intake'
description: '新規プロジェクトの最初のFeatureを社内AIと具体化するため、見えるcurrent作業場所を準備します。'
argument-hint: '[任意: 作りたいもの・制約・最初に実現したいこと]'
agent: 'internal-ai-exchange'
---

1. `ai-exchange/templates/new-project-intake.md`を基にする。
2. 引数に具体的な構想がある場合、テンプレートの「作りたいもの」「分かっている制約」「最初に実現したいこと」へ反映する。推測で要求を追加しない。
3. 一時プロンプトを作り、次を実行する。

```bash
python tools/project_context/create_ai_exchange_session.py \
  --type new-project \
  --title "新規プロジェクトの最初のFeature具体化" \
  --prompt-file "<一時プロンプト>"
```

4. 必ず次のリンクを表示する。
   - `ai-exchange/current/README.md`
   - `ai-exchange/current/prompt.md`
   - `ai-exchange/current/response.md`
5. 社内AIの最終回答をresponse.mdへ貼り付けた後、`/import-current-internal-ai-response`を実行するよう案内する。
