---
name: 'pre-plan-intake'
description: 'Clarify and approve technology choices after specification and before /speckit.plan.'
argument-hint: '[feature path or decision.md] [short technical intent]'
agent: 'pre-plan-curator'
---

Create or continue a pre-plan technical decision.

- Read the approved specification before considering packages or frameworks.
- Compare standard-library, self-built, and external-package candidates against the actual requirements.
- Present a recommendation first and ask at most three high-impact questions.
- Record Accepted, Accepted with modification, Prohibited, Rejected, and unresolved Research items.
- Do not run `/speckit.plan`, edit plan/research, install dependencies, or implement code before explicit approval.
- Treat `uv add` as a post-plan-approval action except for an explicitly approved disposable PoC.
