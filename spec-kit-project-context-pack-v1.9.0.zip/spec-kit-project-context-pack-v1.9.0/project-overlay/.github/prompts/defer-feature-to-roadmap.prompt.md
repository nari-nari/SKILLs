---
name: 'defer-feature-to-roadmap'
description: '現在の実装範囲には複雑すぎる機能を、消失させず根拠付きロードマップ候補として保存します。'
argument-hint: '[request/spec/task path and deferred scope]'
agent: 'roadmap-curator'
---

指定された機能または要求について、現在のPoC・featureから外す妥当性を評価してください。

1. 現在範囲に残す最小価値を示す。
2. 延期する範囲、延期理由、利用者価値、依存関係、再開条件、検証方法を整理する。
3. `deferred-feature`候補を作成する。
4. 現行spec/request/tasksに必要な対象外・延期の変更案を別途提示する。
5. 候補作成だけで現行成果物を変更しない。
6. 正式ロードマップへは追加しない。
