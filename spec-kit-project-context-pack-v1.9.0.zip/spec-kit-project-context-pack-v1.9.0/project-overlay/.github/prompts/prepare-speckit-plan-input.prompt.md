---
name: 'prepare-speckit-plan-input'
description: 'Create a ready-to-paste /speckit.plan input from an approved specification and approved pre-plan technical decision.'
argument-hint: '[feature path and approved .context-work/pre-plan/TP-xxxx/decision.md]'
agent: 'speckit-router'
---

First run:

```bash
python tools/project_context/validate_pre_plan_decision.py <decision.md> --require-approved
```

Stop on failure. Then read only the target `spec.md`, approved pre-plan decision, constitution, compact snapshot, current dependency definition, and relevant feature research.

Create a ready-to-paste `/speckit.plan` input containing:

- current language/version, platform, test/build environment, distribution, offline, license, security, performance, and maintenance constraints
- Accepted and Accepted with modification technologies
- explicit Prohibited and Rejected technologies, including framework-mixing restrictions
- unresolved options that must go to `research.md`
- approved architecture boundaries, data model constraints, modules, folder rules, and validation methods
- dependency manager and the rule that production dependencies are added only after plan approval
- instruction not to substitute a standard-library/self-built option merely to avoid dependencies
- instruction to reopen pre-plan review if the selected technology cannot satisfy the specification
- explicit instructions not to change `spec.md`, install dependencies, or implement code during planning

Require the planning agent to inspect the actual repository before documenting structure. Save the generated input next to the decision or in the approved request directory and stop before running `/speckit.plan`.
