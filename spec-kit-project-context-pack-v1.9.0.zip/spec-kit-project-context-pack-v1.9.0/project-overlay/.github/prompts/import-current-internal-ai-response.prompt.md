---
name: 'import-current-internal-ai-response'
description: 'ai-exchange/current/response.mdまたはチャットへ貼られた社内AI回答を、現在の相談種別に応じて取り込みます。'
argument-hint: '[任意: 社内AIの最終回答本文]'
agent: 'internal-ai-exchange'
---

`ai-exchange/current/`を現在の社内AI交換の唯一の人間向け作業場所として使用してください。

- 引数に回答本文がある場合は、`ai-exchange/current/response.md`へ保存してから処理する。
- 引数がない場合は、既存の`ai-exchange/current/response.md`を読む。
- `session.toml`のtypeとsource_pathに応じて、新規仕様、汎用依頼、pre-plan技術選定、ロードマップ相談を自動判定する。
- 回答を未承認の助言として取り込み、人間承認前に正式仕様、plan、tasks、コードへ反映しない。
- 処理結果を`ai-exchange/current/result.md`へ保存する。
- 最後に`result.md`、source_path、current READMEへのリンクを必ず表示する。
