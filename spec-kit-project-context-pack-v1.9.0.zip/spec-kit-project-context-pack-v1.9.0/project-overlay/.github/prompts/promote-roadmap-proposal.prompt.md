---
name: 'promote-roadmap-proposal'
description: '人間承認済み候補を検証し、正式ロードマップへの差分をプレビューします。'
argument-hint: '[Approved RM-xxxx.toml path]'
agent: 'roadmap-curator'
---

指定候補について、`validate_roadmap_proposal.py --require-approved`を実行し、その後`apply_roadmap_update.py`を`--apply`なしで実行して差分を提示してください。

- 検証または差分生成だけを行ってください。
- 正式ロードマップはまだ変更しないでください。
- 問題があれば、候補のどの項目を人間が修正すべきか示してください。
- 適用するには、ユーザーから別途明示的な指示が必要です。
