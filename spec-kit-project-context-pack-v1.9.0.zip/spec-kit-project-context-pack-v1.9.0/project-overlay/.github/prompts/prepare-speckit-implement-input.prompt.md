---
name: 'prepare-speckit-implement-input'
description: 'Create a bounded /speckit.implement input for selected approved tasks and validation gates.'
argument-hint: '[feature path and task IDs]'
agent: 'ask'
---

Read the selected feature artifacts and produce a ready-to-paste `/speckit.implement` input.

The input must specify:

- exact phase, user story, and task IDs in scope
- explicit out-of-scope tasks
- requirements and accepted plan decisions to preserve
- tests, build/compile, static analysis, numerical regression, packaging, and offline checks to run
- project-specific restrictions, including unavailable production code/data
- stop conditions for specification ambiguity, dependency failure, unexpected regression, interface change, or need for confidential information
- completion report fields

Require the agent to stop after the bounded scope and not perform unrelated refactoring or adopt unapproved internal AI proposals.
