---
name: 'apply-approved-spec-change'
description: 'Apply only approved user-visible requirement changes to an existing spec.md.'
argument-hint: '[approved review record and feature path]'
agent: 'agent'
---

Read the approved review record and the target feature's `spec.md`.

Apply only proposals explicitly marked Accepted or Accepted with modification that change user-visible behavior, mandatory constraints, scope, success criteria, or acceptance scenarios.

Rules:

- Preserve unrelated user stories, requirement IDs, and accepted scenarios.
- Do not add package names, frameworks, internal folder layouts, class designs, or algorithms unless they are externally mandated constraints.
- Do not edit `plan.md`, `tasks.md`, or code in this step.
- Do not silently resolve contradictions. Report them.
- Report added, changed, removed, and unchanged requirements.
- Recommend `/speckit.clarify` when the changed behavior remains materially ambiguous.
