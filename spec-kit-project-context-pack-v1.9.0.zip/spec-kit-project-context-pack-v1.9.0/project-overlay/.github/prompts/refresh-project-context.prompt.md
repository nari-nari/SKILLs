---
name: 'refresh-project-context'
description: 'Spec Kit内外を含むプロジェクト全体の棚卸しと文脈更新案を作成します。'
argument-hint: '[任意: 注目するディレクトリまたは変更点]'
agent: 'agent'
---

`python tools/project_context/refresh_project_context.py`を実行し、生成された`.project-context/generated/copilot-snapshot.md`とGit差分を最初に確認してください。詳細確認が必要な項目だけ、README、project-map、status、components registry、関連コード・テストへ掘り下げてください。インベントリ全件を会話へ展開しないでください。

Spec Kit feature、手動実装、標準Agent/Planで追加した機能、流用コンポーネント、生成物を区別し、次を提示してください。

1. 現在認識できる主要コンポーネント
2. 各コンポーネントの入口、責務、テスト、関連spec
3. 由来または用途が不明な重要ファイル
4. `.project-context/components.toml`への追加・修正候補
5. `project-map.md`の人間管理領域への更新候補
6. `status.md`へ反映すべき状態変化

自動生成領域以外は、ユーザー承認前に変更しないでください。ファイルがSpec Kit管理外であることだけを理由に無視しないでください。
