---
name: 'review-internal-ai-response'
description: 'ai-exchange/currentの回答を評価し、採用・調査・延期・却下案を提示します。'
argument-hint: '[任意: 回答本文]'
agent: 'ask'
---

`ai-exchange/current/session.toml`、`prompt.md`、`response.md`、source_pathの正本を必要最小限だけ読んでください。引数に回答本文がある場合は、その本文を回答として扱います。

社内AI回答を未承認助言として、Accept、Accept with modification、Investigate、Defer、Reject、Already implemented、Not applicableへ分類してください。ファイルは変更せず、人間承認事項と推奨する次工程を示してください。

正式な取り込みは`/import-current-internal-ai-response`で行います。
