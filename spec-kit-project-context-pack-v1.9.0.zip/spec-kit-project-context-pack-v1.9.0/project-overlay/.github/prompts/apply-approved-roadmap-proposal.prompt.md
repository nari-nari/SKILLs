---
name: 'apply-approved-roadmap-proposal'
description: '明示的に承認されたロードマップ候補を、決定論的ツールで正式ロードマップへ適用します。'
argument-hint: '[Approved RM-xxxx.toml path]'
agent: 'roadmap-curator'
---

ユーザーがこの適用を明示的に依頼していることを確認し、指定候補に対して次を実行してください。

1. `validate_roadmap_proposal.py <proposal> --require-approved`
2. `apply_roadmap_update.py <proposal>`で差分を再確認
3. 問題がなければ`apply_roadmap_update.py <proposal> --apply`

自由編集で`roadmap.md`を書き換えないでください。適用後、workstream ID、バックアップ、promotion record、次工程候補を報告してください。実装は開始しないでください。
