---
name: 'update-project-status'
description: 'Update the concise project-wide status after a material implementation, plan, blocker, or verification change.'
argument-hint: '[feature, milestone, or verification result]'
agent: 'agent'
---

Read [status governance](../../docs/project-context/context-governance.md), the affected Spec Kit artifacts, current code/test evidence, and Git diff if available.

First run:

```bash
python tools/project_context/collect_project_status.py --update-markdown
```

Then update only the human-maintained sections of `docs/project-context/status.md`:

- last updated date
- current phase and active workstream/component
- current goal
- completed facts
- work in progress
- blockers
- verification status
- known limitations
- next actions

Rules:

- Keep the auto-generated block unchanged except through the script.
- Distinguish implemented, test-passed, validated, accepted, and production-verified.
- Do not call a feature complete merely because all task boxes are checked.
- Preserve explicit limitations, including unavailable production code or data.
- Keep the file concise; move historical details to Git history or an approved record.
