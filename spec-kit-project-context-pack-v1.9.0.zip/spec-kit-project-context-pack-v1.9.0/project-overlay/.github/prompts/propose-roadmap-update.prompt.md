---
name: 'propose-roadmap-update'
description: 'コード、テスト、既知問題、仕様の対象外、承認済みAI記録から、根拠付きロードマップ候補を生成します。'
argument-hint: '[feature-completed / milestone-completed / blocker / review scope]'
agent: 'roadmap-curator'
---

指定されたレビュー契機について、まずコンパクトスナップショットと既存候補を確認し、その契機に関係するコード・テスト・既知問題だけを調査してください。将来作業として独立させる根拠がある項目だけを候補化し、全リポジトリ走査は行わないでください。

- 現在の不具合修正や未完了タスクを、安易に将来候補へ逃がさないでください。
- 既存roadmapと候補を重複させないでください。
- policyの最大件数を超えないでください。
- 各候補は`create_roadmap_proposal.py`で`.context-work/roadmap/proposals/`へ保存してください。
- 正式`roadmap.md`は変更しないでください。
- 最後に、作成候補、見送った案、追加調査が必要な案を報告してください。
