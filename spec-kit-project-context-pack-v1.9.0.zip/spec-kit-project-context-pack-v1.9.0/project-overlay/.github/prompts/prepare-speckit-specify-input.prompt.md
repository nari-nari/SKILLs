---
name: 'prepare-speckit-specify-input'
description: 'Convert approved user-visible proposals into a ready-to-paste /speckit.specify input without editing files.'
argument-hint: '[approved review record]'
agent: 'ask'
---

Read the approved review record, constitution, project status, roadmap, and related existing specs.

Create a ready-to-paste `/speckit.specify` input for a genuinely new feature. Include:

- feature purpose and problem
- target users
- approved user-visible capabilities
- representative Given/When/Then scenarios
- in-scope and out-of-scope behavior
- mandatory operational constraints
- measurable success criteria
- assumptions and known validation limitations

Exclude packages, frameworks, algorithms, internal classes, folder structures, and implementation tasks. Do not invent requirements. If the proposal belongs in an existing feature instead of a new feature, say so and produce a bounded existing-spec change request rather than a new specify input.
