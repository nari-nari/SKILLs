---
name: 'prepare-internal-ai-technical-selection'
description: 'pre-plan判断から技術選定プロンプトを作り、ai-exchange/currentへ準備します。'
argument-hint: '[pre-plan decision.md]'
agent: 'technical-selection-exporter'
---

対象decision.mdとspecを検証し、`ai-exchange/templates/pre-plan-technology-selection.md`を基に社内AI向け技術比較プロンプトを作ってください。

`create_ai_exchange_session.py --type pre-plan --source <decision.md>`を使用し、次を必ず生成・案内してください。

- `ai-exchange/current/README.md`
- `ai-exchange/current/prompt.md`
- `ai-exchange/current/response.md`
- 回答後に実行する`/import-current-internal-ai-response`

`.context-work`配下へユーザーが回答ファイルを作る運用は使用しないでください。
