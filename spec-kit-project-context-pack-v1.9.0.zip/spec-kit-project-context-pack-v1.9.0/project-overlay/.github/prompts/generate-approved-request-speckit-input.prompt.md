---
name: 'generate-approved-request-speckit-input'
description: '承認済み依頼から、適切なSpec Kit工程の正式入力を生成します。'
argument-hint: '[承認済み request.md のパス]'
agent: 'speckit-router'
---

指定された承認済み`request.md`を検証し、適切なSpec Kit工程または部分編集方法を選び、依頼フォルダに`speckit-input.md`を生成してください。

生成だけを行い、Spec Kitコマンド、ファイル編集、コード実装は実行しないでください。
