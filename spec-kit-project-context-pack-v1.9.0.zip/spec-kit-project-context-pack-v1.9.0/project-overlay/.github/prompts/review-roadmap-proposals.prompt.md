---
name: 'review-roadmap-proposals'
description: '未承認ロードマップ候補を、価値、根拠、重複、依存、複雑度、検証可能性でレビューします。'
argument-hint: '[proposal path, directory, or all]'
agent: 'roadmap-curator'
---

対象候補をレビューし、各候補について次を提示してください。

- 推奨判定: Ready for review / Needs investigation / Deferred / Rejected
- 根拠の十分性
- 既存roadmap・他候補との重複
- 利用者価値と今やる必要性
- 依存関係と開始条件
- 推奨priority、complexity、confidence
- 推奨management_typeとroute
- 承認前に必要な検証または人間判断

AIは`Approved`、`approved_by`、`approved_at`を設定しないでください。正式ロードマップを変更しないでください。
