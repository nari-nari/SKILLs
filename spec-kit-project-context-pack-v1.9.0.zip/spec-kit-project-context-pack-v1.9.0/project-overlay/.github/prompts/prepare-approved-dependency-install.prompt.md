---
name: 'prepare-approved-dependency-install'
description: 'Create reviewed uv dependency commands only after plan approval.'
argument-hint: '[approved feature plan and pre-plan decision]'
agent: 'ask'
---

Validate the approved pre-plan decision, then read the accepted `plan.md`, current `pyproject.toml`, and `uv.lock` if present.

Produce, but do not execute:

- exact `uv add` commands grouped into runtime, development, and optional dependencies
- version constraints only when justified by the accepted plan or compatibility evidence
- packages that must not be added
- lock/sync/import/test verification commands
- cleanup instructions for any earlier disposable PoC

Stop if the plan contradicts the accepted or prohibited technologies, if the pre-plan spec hash is stale, or if plan approval is unclear. Do not add a package merely because it was used in a PoC.
