---
name: 'generate-roadmap-item-change-input'
description: 'ApprovedまたはPromotedロードマップ項目から、承認済みrouteに対応する正式な次工程入力を生成します。'
argument-hint: '[RM-xxxx.toml path]'
agent: 'roadmap-curator'
---

指定候補を検証し、routeに対応する正式入力を`.context-work/roadmap/next-actions/<proposal-id>-input.md`へ生成してください。

- `speckit-specify`: 利用者価値と範囲に基づく`/speckit.specify`入力
- `speckit-plan-research`: 技術候補を比較するresearch/plan入力
- `manual-workstream`: 標準Agent向けの実装準備入力
- `investigation`: 読み取り専用調査入力
- `documentation-only`: 文書更新入力

現在のroadmap、status、関連成果物を参照し、対象範囲、対象外、依存、検証、停止条件を含めてください。入力生成だけを行い、実装やSpec Kitコマンドを実行しないでください。
