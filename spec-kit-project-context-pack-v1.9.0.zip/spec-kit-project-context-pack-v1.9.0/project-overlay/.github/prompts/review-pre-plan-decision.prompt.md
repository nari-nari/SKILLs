---
name: 'review-pre-plan-decision'
description: 'Review or revise a pre-plan technical decision, including an internal-AI response.'
argument-hint: '[decision.md and optional internal-AI response path or user corrections]'
agent: 'pre-plan-curator'
---

Review the current pre-plan decision. Treat internal-AI output as unapproved advice. Update the candidate comparison, recommendation, Accepted, Accepted with modification, Prohibited, Rejected, unresolved Research, validation, and dependency timing. Highlight exactly what the human must approve. Do not infer approval or modify Spec Kit artifacts, dependencies, or code.
