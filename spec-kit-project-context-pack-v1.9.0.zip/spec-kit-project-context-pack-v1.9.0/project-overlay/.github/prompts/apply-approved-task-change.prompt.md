---
name: 'apply-approved-task-change'
description: 'Update tasks.md for approved changes while preserving completion history.'
argument-hint: '[approved review record and feature path]'
agent: 'agent'
---

Read the approved review record and the target feature's current `spec.md`, `plan.md`, and `tasks.md`.

Update only the task decomposition affected by approved changes.

- Preserve `[X]` completed tasks and existing task IDs whenever possible.
- If completed work must be revised, add a new corrective task instead of rewriting history.
- Mark obsolete tasks as Superseded or Deprecated with a reason instead of deleting them.
- Each new task should identify its requirement/plan basis, target file or directory, dependencies, validation method, and completion condition.
- Include dependency setup, migration, test, compatibility, documentation, offline installation, and project-status updates when relevant.
- Do not implement code in this step.

Return a concise change summary and recommend `/speckit.analyze` before implementation.
