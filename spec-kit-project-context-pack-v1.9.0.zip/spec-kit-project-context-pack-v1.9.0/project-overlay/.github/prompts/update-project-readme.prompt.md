---
name: 'update-project-readme'
description: '人間が承認した節単位のREADME更新提案を検証し、差分確認後に限定適用します。'
argument-hint: '<.context-work/readme/updates/README-UPDATE-xxxx.toml>'
agent: 'agent'
---

対象提案を読み、次を確認してください。

- `status = "Approved"`である
- `approved_by`が空でない
- `.project-context/readme-policy.toml`の許可節だけを変更する
- 保護節を変更しない
- READMEの現在SHA-256が提案の`readme_sha256`と一致する
- 実装・検証状況の記述がコード、テスト、`status.md`と一致する

まずドライランを実行してください。

```bash
python tools/project_context/apply_readme_update.py <提案パス>
```

差分をユーザーへ提示し、明示的な適用承認が現在の会話または提案ファイルに存在する場合だけ次を実行してください。

```bash
python tools/project_context/apply_readme_update.py <提案パス> --apply
```

適用後は次を実行してください。

```bash
python tools/project_context/assess_readme_update.py
python tools/project_context/check_context_consistency.py
```

README全体を書き換えたり、提案外の表現改善を同時に行ったりしないでください。保護節の変更が必要なら、別の人間レビュー事項として報告してください。
