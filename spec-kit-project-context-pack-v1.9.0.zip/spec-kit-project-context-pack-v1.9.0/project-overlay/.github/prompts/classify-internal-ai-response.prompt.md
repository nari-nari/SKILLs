---
name: 'classify-internal-ai-response'
description: '互換用: ai-exchange/currentの社内AI回答を分類します。ファイルは編集しません。'
argument-hint: '[任意: 回答本文]'
agent: 'ask'
---

`ai-exchange/current/session.toml`と`response.md`を読み、引数に回答がある場合はその回答を優先してください。回答は未承認の助言です。ファイルを編集しないでください。

提案をspec、research、plan、tasks、constitution、status、defer、reject、advice-onlyへ分類し、事実と仮定、人間承認事項、最小更新順序を返してください。

現在の正式な取り込みには`/import-current-internal-ai-response`を使用することも案内してください。
