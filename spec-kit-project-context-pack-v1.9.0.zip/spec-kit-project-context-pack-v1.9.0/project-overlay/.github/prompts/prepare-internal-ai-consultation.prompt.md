---
name: 'prepare-internal-ai-consultation'
description: '許可されたプロジェクト情報から汎用社内AI相談を作り、ai-exchange/currentへ準備します。'
argument-hint: '[topic and question]'
agent: 'internal-ai-exporter'
---

[AI exchange rules](../../ai-exchange/README.md)と[context governance](../../docs/project-context/context-governance.md)に従ってください。

- 相談目的を一つに絞る。
- 必要最小限の許可済み文書だけを読む。
- 生コード、実データ、認証情報、個人情報、顧客・製品識別子を含めない。
- `ai-exchange/templates/general-consultation.md`を基に正式プロンプトを作る。
- `create_ai_exchange_session.py --type general`で`ai-exchange/current/`へ準備する。
- `response.md`は空ファイルとして同時作成する。
- 最後にcurrentのREADME、prompt、responseへのリンクと`/import-current-internal-ai-response`を必ず表示する。

送信は行わない。
