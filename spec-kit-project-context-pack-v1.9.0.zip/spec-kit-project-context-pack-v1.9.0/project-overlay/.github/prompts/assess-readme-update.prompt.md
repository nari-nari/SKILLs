---
name: 'assess-readme-update'
description: '現在のコード・文書・検証状況とルートREADMEの不一致を評価し、承認前の更新提案を作成します。'
argument-hint: '[任意: 完了したfeature、release、構成変更など]'
agent: 'agent'
---

`.project-context/generated/copilot-snapshot.md`を最初に確認してください。スナップショットまたはインベントリが欠落・陳腐化している場合だけ`python tools/project_context/refresh_project_context.py`を実行します。続けて、ルート`README.md`、`.project-context/readme-policy.toml`、生成済みREADME評価、直近のGit差分、および変更根拠となる関連コード・テスト・実行／配布設定だけを確認してください。

READMEへ反映すべき変化と、READMEへ書かず状況文書だけに残す変化を区別してください。特に次を評価します。

1. 主要機能、成熟度、インストール、使用方法、対応環境、公開インターフェース、主要構成、重要な制限が実態と一致するか
2. 実装済み、テスト済み、検証済み、受入済み、実環境確認済みを混同していないか
3. Spec Kit外の機能、手動追加、流用コンポーネントも主要機能として必要なら反映されているか
4. READMEに日々のタスクや一時的ブロッカーを書きすぎていないか
5. `readme-policy.toml`の保護節に変更が必要か。必要な場合も自動変更せず、人間向けの注意として報告すること

更新が必要な場合は、`.project-context/templates/readme-update.toml`を基に、`.context-work/readme/updates/README-UPDATE-xxxx.toml`へ**Draft**提案を作成してください。

提案ルール:

- 現在のREADMEのSHA-256を`readme_sha256`へ記録する
- `managed_sections`に含まれる見出しだけを提案する
- 保護節は提案へ含めない
- 各節の本文は、READMEとしてそのまま使える簡潔な文にする
- 未実装・未検証の事項を完了扱いしない
- 詳細な進捗は`docs/project-context/status.md`へリンクし、READMEへ重複させすぎない
- `status = "Draft"`のままにし、READMEは変更しない

最後に次を報告してください。

- README更新の要否
- 更新を推奨する節
- 更新しない理由がある節
- 保護節に関する人間確認事項
- 作成したDraft提案のパス
