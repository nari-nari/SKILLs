---
name: 'import-internal-ai-response-to-request'
description: '互換用: 現在の社内AI回答取り込みへ案内します。'
argument-hint: '[任意: 社内AIの最終回答本文]'
agent: 'internal-ai-exchange'
---

このコマンドは互換用です。`/import-current-internal-ai-response`と同じ処理を行ってください。

- 引数に回答本文がある場合は`ai-exchange/current/response.md`へ保存する。
- 引数がなければ同ファイルを読む。
- `session.toml`のtypeとsource_pathから取り込み先を自動判定する。
- 結果は`ai-exchange/current/result.md`へ保存する。
