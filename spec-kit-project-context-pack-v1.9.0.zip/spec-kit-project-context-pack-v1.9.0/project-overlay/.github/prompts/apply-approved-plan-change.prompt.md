---
name: 'apply-approved-plan-change'
description: 'Apply approved technology, package, architecture, or folder-structure changes to plan.md and research.md.'
argument-hint: '[approved review record and feature path]'
agent: 'agent'
---

Read the approved review record or approved pre-plan decision, target `spec.md`, existing `research.md` if present, `plan.md`, constitution, and current code structure. Validate the pre-plan decision when package, framework, or architecture selection is involved.

Apply only accepted technical proposals.

- Put undecided comparisons, alternatives, risks, and PoC needs in `research.md`.
- Put accepted language, dependencies, architecture, module boundaries, folder structure, data model, testing strategy, platform, and constraints in `plan.md`.
- Confirm the proposed structure against the actual repository before documenting it.
- Preserve unrelated accepted decisions.
- Do not edit `spec.md`, `tasks.md`, code, `pyproject.toml`, or lock files. Dependency installation occurs only after plan approval.
- For new dependencies, record license, platform support, offline availability, maintenance risk, and validation method when known.
- Mark unknown facts as unknown; do not invent package compatibility or approval status.

Report the exact downstream task changes that will be required.

- Preserve explicit Prohibited and Rejected technologies so a later agent does not silently substitute them.
