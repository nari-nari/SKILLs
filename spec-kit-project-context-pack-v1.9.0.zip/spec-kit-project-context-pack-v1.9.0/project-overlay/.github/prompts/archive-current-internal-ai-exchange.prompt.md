---
name: 'archive-current-internal-ai-exchange'
description: '処理済みの現在の社内AI交換を履歴へ退避し、currentを空にします。'
agent: 'internal-ai-exchange'
---

`python tools/project_context/archive_ai_exchange_session.py`を実行してください。

未処理の相談なら停止し、`ai-exchange/current/README.md`、`response.md`、`result.md`へのリンクを示してください。強制退避はユーザーが明示した場合だけ`--force --status superseded`で行ってください。
