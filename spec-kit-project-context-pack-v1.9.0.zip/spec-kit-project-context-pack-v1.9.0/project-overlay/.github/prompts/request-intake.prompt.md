---
name: 'request-intake'
description: '既存プロジェクトの短い依頼を軽量分類し、単純作業は専用コマンドへ、必要な変更だけ承認可能な依頼ブリーフへ送ります。'
argument-hint: '[quick|standard|deep] [feature|bug|research|refactor|docs|roadmap|validation|import|context|unknown] 短い依頼'
agent: 'request-intake'
---

このスラッシュコマンドの後ろの文章をユーザーの意図として扱ってください。省略時のモードは`standard`です。

最初に`parse_request_intake.py`でモード・ヒント・決定論的な専用ルートを判定してください。

- `quick`: スナップショットだけで専門コマンドを1つ返す。質問・`request.md`作成・実装は禁止。
- `standard`: 単純作業は専用コマンドへ直接案内し、挙動変更・複数領域・曖昧さ・承認・技術選択がある場合だけ`request.md`を作る。
- `deep`: 大規模・横断変更として必ず`request.md`を作り、依存関係と段階計画を調査する。

例：

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
/request-intake [feature] 同じ.ncを開いたとき前回の解析範囲を復元したい
/request-intake deep [refactor] packages配下の2パッケージを統合したい
```

リポジトリから判明する情報をユーザーに再入力させず、詳細受付時だけ推奨案付きの重要質問を最大3件提示してください。
