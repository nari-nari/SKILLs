---
name: 'export-approved-request-to-internal-ai'
description: '承認済みrequest.mdから社内AI向けプロンプトを作り、ai-exchange/currentへ準備します。'
argument-hint: '[承認済み request.md のパス]'
agent: 'internal-ai-exporter'
---

承認済みrequest.mdを検証し、社内AIへ送る最小限の正式プロンプトを作成してください。

出力先は依頼フォルダではなく、現在作業用の`ai-exchange/current/prompt.md`です。同時に空の`response.md`と手順READMEを作成し、最後にリンクと`/import-current-internal-ai-response`を表示してください。
