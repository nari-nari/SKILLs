---
name: 'generate-approved-request-change-input'
description: '承認済み依頼から、Spec Kit内外を含む適切な正式変更入力を生成します。'
argument-hint: '[承認済み request.md のパス]'
agent: 'project-change-router'
---

指定された承認済み`request.md`を検証し、プロジェクト全体の文脈から適切な変更工程を選び、依頼フォルダに`change-input.md`を生成してください。

Spec Kit featureに関係する場合だけSpec Kit工程を選び、手動実装、標準Agent/Planで追加した機能、流用ファイルについては標準Agent向けの正式入力を生成してください。

生成だけを行い、ファイル編集、Spec Kitコマンド、コード実装は実行しないでください。
