---
technical_decision_id: {{TECHNICAL_DECISION_ID}}
status: Draft
feature_path: {{FEATURE_PATH}}
spec_sha256: {{SPEC_SHA256}}
decision_scope: Feature
decision_type: {{DECISION_TYPE}}
created: {{CREATED_DATE}}
updated: {{CREATED_DATE}}
approved_by:
approved_at:
---

# Pre-plan Technical Decision: {{TECHNICAL_DECISION_ID}}

> This local working file is excluded from Git by default. It records reviewed technical constraints before `/speckit.plan`; it does not replace `research.md` or `plan.md`.

## 1. Technical intent

{{TECHNICAL_INTENT}}

## 2. Requirements and constraints derived from the specification

### Confirmed requirements

- To be extracted from the current `spec.md`.

### Platform, distribution, licensing, offline, security, and maintenance constraints

- To be confirmed.

### Constraints that materially affect technology selection

- To be identified.

## 3. Existing project context

- Existing runtime and dependency manager: To be confirmed.
- Existing dependencies and interfaces to preserve: To be confirmed.
- Project-wide technical decisions: To be checked.

## 4. Candidate comparison

| Candidate | Requirement fit | Main advantage | Main disadvantage | License/offline/distribution | Evidence | Disposition |
|---|---|---|---|---|---|---|
| Candidate A | Unknown | Unknown | Unknown | Unknown | Unknown | Investigate |
| Standard library or self-built option | Unknown | No added runtime dependency | May not satisfy interaction, testing, or maintainability needs | To be checked | Unknown | Investigate |

Do not make the standard library the default merely because it adds no dependency. Compare all candidates against the approved requirements.

## 5. Recommended decision

- Recommendation: To be proposed.
- Why it best satisfies the requirements: To be proposed.
- Main trade-off accepted: To be proposed.
- Reconsideration condition: To be proposed.

## 6. Decision disposition

### Accepted

- TBD

### Accepted with modification

- None

### Prohibited

- None specified

### Rejected

- None

## 7. Unresolved research

| ID | Question | Recommended provisional answer | How to verify | Destination |
|---|---|---|---|---|
| R-01 | To be identified | To be proposed | Minimal PoC, official documentation, or repository inspection | `research.md` |

## 8. Validation and PoC

- Minimal validation needed before or during planning: To be proposed.
- Acceptance evidence: To be proposed.
- Known limits: To be identified.
- A disposable PoC may install a dependency before plan approval only with explicit human approval and must not silently become the production decision.

## 9. Dependency-management timing

- Before plan approval: Do not add production dependencies to `pyproject.toml` or lock files.
- After plan approval: Generate reviewed `uv add` commands from the accepted `plan.md`, then run import, lock, and relevant test checks.
- Exception: Explicitly approved, isolated PoC only; record its command, result, and cleanup decision here.

## 10. `/speckit.plan` handoff

The generated plan input must include:

- accepted technologies and versions or version constraints
- prohibited technologies and combinations
- accepted-with-modification conditions
- unresolved items that belong in `research.md`
- dependency manager and the stage at which dependencies are added
- architecture boundaries and validation methods
- explicit instruction not to substitute a standard-library option without reopening this decision

## 11. Human review notes

Add corrections, rejected assumptions, organizational constraints, and package preferences here.

## 12. Approval checklist

- [ ] Requirement and constraints approved
- [ ] Accepted and prohibited technologies approved
- [ ] Ready for /speckit.plan

After checking all items, set frontmatter `status: Approved`, `approved_by`, and `approved_at`.
