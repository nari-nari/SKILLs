# Feature Change Request

Change ID: `<feature>-CR-<NNN>`
Date: `YYYY-MM-DD`
Source: User feedback / implementation discovery / test result / internal AI proposal / other
Status: Proposed

## Observed problem

<What was observed, with evidence.>

## Current intended behavior

<Current spec requirement or scenario.>

## Proposed behavior

<New user-visible behavior, if any.>

## Technical proposal

<Package, architecture, algorithm, folder, or migration proposal, if any.>

## Classification

- [ ] spec change
- [ ] research needed
- [ ] plan change
- [ ] task-only change
- [ ] implementation defect only
- [ ] status/roadmap change

## Impacted artifacts

- <paths>

## Acceptance and verification

<How the change will be accepted and validated.>

## Approval

Decision: Pending
Approved by: Pending
