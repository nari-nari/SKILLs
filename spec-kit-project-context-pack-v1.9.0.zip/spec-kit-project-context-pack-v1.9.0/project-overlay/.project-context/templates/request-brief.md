---
request_id: {{REQUEST_ID}}
status: Draft
route: Undecided
created: {{CREATED_DATE}}
updated: {{CREATED_DATE}}
intake_mode: {{INTAKE_MODE}}
request_hint: {{REQUEST_HINT}}
triage_reason: {{TRIAGE_REASON}}
active_workstream: Unknown
related_spec_features: Unknown
related_components: Unknown
---

# Request Brief: {{REQUEST_ID}}

> This local working file is excluded from Git by default. It is the reviewable intermediate artifact, not an authoritative specification.

## 1. User intent

{{USER_INTENT}}

## 2. Context discovered by AI

### Confirmed facts

- To be investigated from project files.

### Relevant artifacts

- To be identified.

### Current implementation and verification state

- To be identified without inference.

## 3. Proposed interpretation

- To be proposed by AI and reviewed by the user.

## 4. Scope

### In scope

- To be proposed.

### Out of scope

- To be proposed.

## 5. Assumptions

| ID | Assumption | Evidence | Impact if wrong | Status |
|---|---|---|---|---|
| A-01 | To be proposed | Unknown | Unknown | Open |

## 6. Open decisions

| ID | Decision needed | AI recommendation | Alternatives | User decision |
|---|---|---|---|---|
| D-01 | To be identified | To be proposed | To be proposed | Pending |

## 7. Routing recommendation

- Recommended route: Undecided
- First authoritative artifact to change: Undecided
- Downstream artifacts: Undecided
- Internal AI consultation needed: Undecided
- Reason: To be analyzed.

## 8. Proposed validation

- Pre-change validation: To be proposed.
- Post-change validation: To be proposed.
- Known validation limits: To be identified.

## 9. Human review notes

Add corrections, rejected assumptions, preferences, and constraints here. The AI should incorporate them in the next review cycle.

## 10. Approval checklist

- [ ] Interpretation approved
- [ ] Scope approved
- [ ] Ready for downstream generation

After checking all items, change frontmatter `status` to `Approved`.

## Focused context

### Must read

- `.project-context/generated/copilot-snapshot.md`
- <Only the files required to decide or execute this request>

### Read only if needed

- <Secondary references>

### Excluded from this request

- <Unrelated directories, generated data, or large files>

### Context budget note

- Prefer at most 8 relevant files unless a concrete reason is recorded here.

