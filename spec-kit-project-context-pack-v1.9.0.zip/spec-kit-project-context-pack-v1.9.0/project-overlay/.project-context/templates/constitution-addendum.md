# Constitution Addendum: Specification Evolution and AI Governance

Merge the applicable principles into the existing `.specify/memory/constitution.md` using `/speckit.constitution` or a reviewed manual edit. Do not replace an existing constitution wholesale.

## Specification evolution

- Spec Kit artifacts are editable, version-controlled project documents.
- Update intended behavior in `spec.md`, accepted technical strategy in `plan.md`, and actionable work in `tasks.md`.
- Reconcile affected downstream artifacts after material change and run `/speckit.analyze` before implementation.
- Preserve completed work history and document corrective work as new tasks.

## Evidence and completion

- Distinguish implemented, tested, validated, accepted, and production-verified states.
- Do not claim real-code, real-data, or production applicability without corresponding evidence.
- Record unavailable validation explicitly.

## Internal AI governance

- Treat AI responses as unapproved advice until explicit human review.
- Do not allow AI advice to directly modify requirements or code without approval.
- Share only allowlisted, sanitized context through approved channels.
- Use deterministic checks and human disclosure review before sending information.
- Record accepted proposals, affected artifacts, and validation obligations.
