from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from project_context_lib import load_config, relative_posix, resolve_inside, write_json

try:
    import tomllib
except ModuleNotFoundError as exc:  # pragma: no cover
    raise RuntimeError("Python 3.11 or newer is required") from exc


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cap(text: str, limit: int) -> str:
    text = text.strip()
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 24)].rstrip() + "\n… [truncated by budget]"


def section(text: str, heading: str) -> str:
    pattern = re.compile(
        rf"^##\s+{re.escape(heading)}\s*$\n(.*?)(?=^##\s+|\Z)",
        re.MULTILINE | re.DOTALL,
    )
    match = pattern.search(text)
    return match.group(1).strip() if match else ""


def first_description(text: str) -> str:
    lines = text.splitlines()
    kept: list[str] = []
    in_fence = False
    for line in lines:
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence or line.startswith("#") or not line.strip():
            if kept:
                break
            continue
        kept.append(line.strip())
        if len(" ".join(kept)) >= 800:
            break
    return " ".join(kept)


def table_rows(text: str, heading: str, max_rows: int) -> list[str]:
    body = section(text, heading)
    rows = []
    for line in body.splitlines():
        stripped = line.strip()
        if not stripped.startswith("|") or re.match(r"^\|?\s*[-:]+", stripped.replace("|", "", 1)):
            continue
        if "<" in stripped or stripped.count("—") >= 3:
            continue
        rows.append(stripped)
    return rows[:max_rows]


def load_components(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    with path.open("rb") as stream:
        return [dict(item) for item in tomllib.load(stream).get("components", [])]


def main() -> int:
    config = load_config()
    cc = config.data.get("copilot_context", {})
    section_limit = int(cc.get("section_max_chars", 2200))
    total_limit = int(cc.get("snapshot_max_chars", 14000))

    paths = {
        "readme": resolve_inside(config.root, config.project.get("readme_file", "README.md")),
        "status": resolve_inside(config.root, config.project.get("status_file", "docs/project-context/status.md")),
        "roadmap": resolve_inside(config.root, config.project.get("roadmap_file", "docs/project-context/roadmap.md")),
        "map": resolve_inside(config.root, config.project.get("project_map_file", "docs/project-context/project-map.md")),
        "inventory": resolve_inside(config.root, config.project.get("generated_inventory_json", ".project-context/generated/project-inventory.json")),
        "components": resolve_inside(config.root, config.project.get("component_registry", ".project-context/components.toml")),
        "issues": config.root / "docs/project-context/known-issues.md",
    }
    texts = {key: path.read_text(encoding="utf-8", errors="replace") if path.is_file() else "" for key, path in paths.items()}

    inventory: dict[str, Any] = {}
    if texts["inventory"]:
        try:
            inventory = json.loads(texts["inventory"])
        except json.JSONDecodeError:
            inventory = {}
    files = inventory.get("files", []) if isinstance(inventory, dict) else []
    categories = Counter(str(item.get("category", "other")) for item in files if isinstance(item, dict))
    origins = Counter(str(item.get("origin", "unknown")) for item in files if isinstance(item, dict))

    status_parts = []
    for line in texts["status"].splitlines()[:12]:
        if any(line.startswith(prefix) for prefix in ("Last updated:", "Overall state:", "Current phase:", "Active workstream/component:", "Related Spec Kit feature:")):
            status_parts.append(line)
    for name in ("Current goal", "In progress", "Blocked", "Verification status", "Known limitations", "Next actions"):
        body = section(texts["status"], name)
        if body:
            status_parts.append(f"### {name}\n{cap(body, section_limit)}")

    roadmap_rows = table_rows(texts["roadmap"], "Milestones", 8) + table_rows(texts["roadmap"], "Workstream map", 16)
    issue_rows = table_rows(texts["issues"], "", 10) if texts["issues"] else []
    if not issue_rows and texts["issues"]:
        issue_rows = [line.strip() for line in texts["issues"].splitlines() if line.strip().startswith("|")][:12]

    components = load_components(paths["components"])
    component_lines = []
    for item in components[:20]:
        component_lines.append(
            f"- `{item.get('id', 'unknown')}`: origin={item.get('origin', 'unspecified')}, "
            f"lifecycle={item.get('lifecycle', 'unspecified')}, paths={', '.join(map(str, item.get('paths', [])))}"
        )

    source_hashes = {relative_posix(config.root, path): sha256(path) for path in paths.values() if path.is_file()}
    lines = [
        "# Copilot Project Snapshot",
        "",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        "Purpose: compact first-pass context. Open source files below only when the current request requires them.",
        "",
        "## Product",
        "",
        f"- Repository: `{config.project.get('name', 'CHANGE_ME')}`",
        f"- README: `{relative_posix(config.root, paths['readme'])}`" if paths["readme"].is_file() else "- README: missing",
        f"- Summary: {cap(first_description(texts['readme']), 1000) or 'Not documented.'}",
        "",
        "## Current state",
        "",
        cap("\n\n".join(status_parts), section_limit * 3) or "Status has not been completed.",
        "",
        "## Approved roadmap excerpt",
        "",
        "\n".join(roadmap_rows) if roadmap_rows else "No approved roadmap rows are recorded.",
        "",
        "## Inventory summary",
        "",
        f"- Files inventoried: {len(files)}",
        f"- Categories: {dict(sorted(categories.items()))}",
        f"- Origins: {dict(sorted(origins.items()))}",
        "",
        "## Registered components",
        "",
        "\n".join(component_lines) if component_lines else "No explicit components registered.",
        "",
        "## Known issue excerpt",
        "",
        "\n".join(issue_rows) if issue_rows else "No concrete known-issue rows recorded.",
        "",
        "## Focus rules",
        "",
        "- Use the generated inventory to locate candidates; do not paste the full inventory into chat.",
        "- Open the target component, its nearest tests, and the owning requirement/plan only when relevant.",
        "- Default limit: 8 relevant files. Record a concrete reason before exceeding it.",
        "- Large data, generated output, logs, caches, and unrelated feature directories are excluded by default.",
        "",
        "## Source hashes",
        "",
    ]
    lines.extend(f"- `{path}`: `{digest}`" for path, digest in sorted(source_hashes.items()))
    snapshot = "\n".join(lines).rstrip() + "\n"
    snapshot = cap(snapshot, total_limit) + "\n"
    out = resolve_inside(config.root, cc.get("snapshot_file", ".project-context/generated/copilot-snapshot.md"))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(snapshot, encoding="utf-8")

    always_on = config.root / ".github/copilot-instructions.md"
    always_on_words = len(always_on.read_text(encoding="utf-8", errors="replace").split()) if always_on.is_file() else 0
    always_on_limit = int(cc.get("always_on_max_words", 220))
    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "snapshot": relative_posix(config.root, out),
        "snapshot_chars": len(snapshot),
        "snapshot_words": len(snapshot.split()),
        "always_on_instruction_words": always_on_words,
        "always_on_instruction_limit": always_on_limit,
        "always_on_within_budget": always_on_words <= always_on_limit,
        "source_hashes": source_hashes,
        "default_max_relevant_files": int(cc.get("default_max_relevant_files", 8)),
    }
    report_json = resolve_inside(config.root, cc.get("budget_report_json", ".project-context/generated/copilot-context-budget.json"))
    write_json(report_json, report)
    report_md = resolve_inside(config.root, cc.get("budget_report_markdown", ".project-context/generated/copilot-context-budget.md"))
    report_md.write_text(
        "# Copilot Context Budget\n\n"
        f"Generated: {report['generated_at']}\n\n"
        f"- Snapshot: `{report['snapshot']}`\n"
        f"- Characters: {report['snapshot_chars']}\n"
        f"- Approximate words: {report['snapshot_words']}\n"
        f"- Always-on instruction words: {report['always_on_instruction_words']} / {report['always_on_instruction_limit']}\n"
        f"- Always-on within budget: {report['always_on_within_budget']}\n"
        f"- Default relevant-file limit: {report['default_max_relevant_files']}\n\n"
        "This is a context-size guardrail, not a billing estimate. Actual AI-credit/token use depends on model, chat history, tools, and retrieved content.\n",
        encoding="utf-8",
    )
    print(f"Wrote {relative_posix(config.root, out)} ({len(snapshot)} chars)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
