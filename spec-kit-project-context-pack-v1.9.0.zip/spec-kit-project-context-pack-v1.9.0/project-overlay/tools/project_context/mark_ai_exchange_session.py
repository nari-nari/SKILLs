from __future__ import annotations

import argparse

from ai_exchange_lib import exchange_paths, read_session, update_current_readme, utc_now, write_session
from project_context_lib import load_config

ALLOWED = {"waiting-response", "response-received", "processing", "processed", "completed"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Update the status of the visible current internal-AI exchange")
    parser.add_argument("--status", required=True, choices=sorted(ALLOWED))
    args = parser.parse_args()
    config = load_config()
    current, _, _ = exchange_paths(config)
    session_path = current / "session.toml"
    session = read_session(session_path)
    if not session.get("id"):
        raise RuntimeError("No active exchange exists in ai-exchange/current")
    session["status"] = args.status
    session["updated_at"] = utc_now()
    if args.status in {"processed", "completed"}:
        session["processed_at"] = utc_now()
    write_session(session_path, session)
    update_current_readme(config)
    print(f"Updated {session.get('id')} to {args.status}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
