from __future__ import annotations

import argparse
import difflib
import shutil
import tomllib
from datetime import datetime, timezone
from pathlib import Path

from project_context_lib import load_config, relative_posix, resolve_inside
from readme_maintenance_lib import (
    load_readme_policy,
    replace_or_append_section,
    sha256_file,
    validate_change_sections,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate and apply an approved, section-scoped README proposal")
    parser.add_argument("proposal", help="Approved TOML proposal inside the repository")
    parser.add_argument("--apply", action="store_true", help="Write README; default is validation and diff only")
    args = parser.parse_args()
    config = load_config()
    policy = load_readme_policy(config)
    proposal_path = resolve_inside(config.root, args.proposal)
    with proposal_path.open("rb") as stream:
        proposal = tomllib.load(stream)
    status = str(proposal.get("status", "Draft"))
    if status != "Approved":
        raise ValueError(f"README proposal status must be Approved, got: {status}")
    if not str(proposal.get("approved_by", "")).strip():
        raise ValueError("README proposal approved_by must name the human approver")
    readme_rel = str(proposal.get("readme_file") or policy.readme.get("readme_file") or config.project.get("readme_file", "README.md"))
    configured = str(policy.readme.get("readme_file") or config.project.get("readme_file", "README.md"))
    if readme_rel != configured:
        raise ValueError(f"Proposal targets {readme_rel}, but policy targets {configured}")
    readme = resolve_inside(config.root, readme_rel)
    if not readme.is_file():
        raise FileNotFoundError(f"README does not exist: {readme_rel}")
    expected_hash = str(proposal.get("readme_sha256", ""))
    actual_hash = sha256_file(readme)
    if expected_hash != actual_hash:
        raise ValueError("README changed after the proposal was created; regenerate or re-review the proposal")
    changes = [dict(item) for item in proposal.get("changes", [])]
    if not changes:
        raise ValueError("README proposal has no changes")
    validate_change_sections(changes, policy)
    original = readme.read_text(encoding="utf-8")
    updated = original
    actions: list[str] = []
    for change in changes:
        section = str(change["section"])
        updated, action = replace_or_append_section(
            updated,
            section,
            str(change["content"]),
            replace_only=str(change.get("action", "upsert")) == "replace",
        )
        actions.append(f"{action}: {section}")
    if updated == original:
        print("Proposal is valid but produces no README changes.")
        return 0
    diff = "".join(difflib.unified_diff(
        original.splitlines(keepends=True),
        updated.splitlines(keepends=True),
        fromfile=f"a/{readme_rel}",
        tofile=f"b/{readme_rel}",
    ))
    print(diff)
    print("Validated changes:")
    for action in actions:
        print(f"- {action}")
    if not args.apply:
        print("Dry run only. Re-run with --apply after reviewing this diff.")
        return 0
    backup_root = resolve_inside(config.root, policy.readme.get("backup_root", ".context-work/readme/backups"))
    backup_root.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = backup_root / f"{readme.name}.{timestamp}.bak"
    shutil.copy2(readme, backup)
    readme.write_text(updated, encoding="utf-8")
    print(f"Applied README update. Backup: {relative_posix(config.root, backup)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
