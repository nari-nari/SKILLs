from __future__ import annotations

import argparse
from pathlib import Path

from ai_exchange_lib import (
    ACTIVE_STATUSES,
    COMPLETED_STATUSES,
    SESSION_TYPES,
    archive_current,
    current_readme,
    exchange_paths,
    next_session_id,
    read_session,
    utc_now,
    write_session,
)
from project_context_lib import load_config, resolve_inside


def main() -> int:
    parser = argparse.ArgumentParser(description="Create the visible current internal-AI exchange workspace")
    parser.add_argument("--type", required=True, choices=sorted(SESSION_TYPES))
    parser.add_argument("--title", required=True)
    parser.add_argument("--source", default="", help="Related request.md, decision.md, spec, or other source")
    prompt_group = parser.add_mutually_exclusive_group(required=True)
    prompt_group.add_argument("--prompt-file")
    prompt_group.add_argument("--prompt-text")
    parser.add_argument("--force", action="store_true", help="Archive an unfinished current exchange as superseded")
    args = parser.parse_args()

    config = load_config()
    current, _, archive_root = exchange_paths(config)
    existing = read_session(current / "session.toml")
    existing_id = str(existing.get("id", ""))
    existing_status = str(existing.get("status", "empty"))
    if existing_id:
        if existing_status in COMPLETED_STATUSES:
            archive_current(config, status="archived", force=True)
        elif args.force:
            archive_current(config, status="superseded", force=True)
        elif existing_status in ACTIVE_STATUSES:
            raise RuntimeError(
                f"Current exchange {existing_id} is still active. Open ai-exchange/current/README.md, "
                "finish/import it, or rerun with --force to archive it as superseded."
            )

    prompt = args.prompt_text
    if args.prompt_file:
        prompt_path = resolve_inside(config.root, args.prompt_file)
        if not prompt_path.is_file():
            raise FileNotFoundError(prompt_path)
        prompt = prompt_path.read_text(encoding="utf-8")
    assert prompt is not None

    session_id = next_session_id(archive_root, existing, str(config.ai_exchange.get("id_prefix", "AI")))
    now = utc_now()
    session = {
        "id": session_id,
        "type": args.type,
        "status": "waiting-response",
        "title": args.title,
        "source_path": args.source,
        "created_at": now,
        "updated_at": now,
        "processed_at": "",
        "archived_at": "",
        "archive_path": "",
    }
    current.mkdir(parents=True, exist_ok=True)
    write_session(current / "session.toml", session)
    (current / "prompt.md").write_text(prompt.rstrip() + "\n", encoding="utf-8")
    (current / "response.md").write_text("# Internal AI response\n\n<!-- Paste the final internal-AI response below this line. -->\n\n", encoding="utf-8")
    (current / "result.md").write_text("# Import result\n\nNot processed yet.\n", encoding="utf-8")
    (current / "README.md").write_text(current_readme(session), encoding="utf-8")

    print(f"Created current internal-AI exchange: {session_id}")
    print("- Guide: ai-exchange/current/README.md")
    print("- Prompt: ai-exchange/current/prompt.md")
    print("- Response destination: ai-exchange/current/response.md")
    print("After pasting the response, run /import-current-internal-ai-response")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
