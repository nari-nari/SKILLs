from __future__ import annotations

import argparse

from project_context_lib import load_config, relative_posix, resolve_inside
from roadmap_management_lib import load_proposal, load_roadmap_policy, validate_proposal


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a roadmap proposal against project policy")
    parser.add_argument("proposal")
    parser.add_argument("--require-approved", action="store_true")
    args = parser.parse_args()
    config = load_config()
    policy = load_roadmap_policy(config)
    proposal_path = resolve_inside(config.root, args.proposal)
    roadmap_path = resolve_inside(
        config.root,
        policy.roadmap.get("roadmap_file", config.project.get("roadmap_file", "docs/project-context/roadmap.md")),
    )
    data = load_proposal(proposal_path)
    findings = validate_proposal(
        data,
        policy,
        require_approved=args.require_approved,
        current_roadmap=roadmap_path if args.require_approved else None,
    )
    if findings:
        print("ROADMAP PROPOSAL INVALID")
        for finding in findings:
            print(f"- {finding}")
        return 1
    print(f"ROADMAP PROPOSAL VALID: {relative_posix(config.root, proposal_path)}")
    if not args.require_approved:
        print("Validation does not imply approval or promotion.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
