from __future__ import annotations

import argparse
import re
from pathlib import Path

from project_context_lib import load_config, parse_flat_frontmatter, resolve_inside

REQUIRED_SECTIONS = [
    "## 1. User intent",
    "## 2. Context discovered by AI",
    "## 3. Proposed interpretation",
    "## 4. Scope",
    "## 6. Open decisions",
    "## 7. Routing recommendation",
    "## 10. Approval checklist",
]

APPROVAL_ITEMS = [
    "Interpretation approved",
    "Scope approved",
    "Ready for downstream generation",
]


def is_checked(text: str, label: str) -> bool:
    return bool(re.search(rf"^- \[[xX]\]\s+{re.escape(label)}\s*$", text, re.MULTILINE))


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a local request brief")
    parser.add_argument("request_file")
    parser.add_argument("--require-approved", action="store_true")
    args = parser.parse_args()

    config = load_config()
    request_path = resolve_inside(config.root, args.request_file)
    if not request_path.is_file():
        raise FileNotFoundError(f"Request file does not exist: {args.request_file}")

    text = request_path.read_text(encoding="utf-8")
    metadata = parse_flat_frontmatter(text)
    findings: list[str] = []

    for key in ("request_id", "status", "route", "created", "updated"):
        if not metadata.get(key):
            findings.append(f"missing frontmatter field: {key}")

    for section in REQUIRED_SECTIONS:
        if section not in text:
            findings.append(f"missing section: {section}")

    route = metadata.get("route", "").strip().lower()
    if args.require_approved and route in {"", "undecided", "unknown"}:
        findings.append("route is not decided")

    if args.require_approved:
        if metadata.get("status", "").strip().lower() != "approved":
            findings.append("status is not Approved")
        for item in APPROVAL_ITEMS:
            if not is_checked(text, item):
                findings.append(f"approval item is not checked: {item}")

    if findings:
        print("REQUEST VALIDATION FAILED")
        for finding in findings:
            print(f"- {finding}")
        return 1

    print("REQUEST VALID")
    print(f"Request: {metadata.get('request_id')}")
    print(f"Status: {metadata.get('status')}; Route: {metadata.get('route')}")
    if not args.require_approved:
        print("Approval was not required for this validation run.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
