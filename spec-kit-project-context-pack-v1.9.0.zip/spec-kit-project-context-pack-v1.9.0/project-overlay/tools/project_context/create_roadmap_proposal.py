from __future__ import annotations

import argparse
from datetime import datetime, timezone

from project_context_lib import load_config, relative_posix, resolve_inside
from roadmap_management_lib import (
    load_roadmap_policy,
    next_numbered_id,
    render_proposal,
    sha256_file,
    validate_proposal,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Create an evidence-backed roadmap proposal without changing the official roadmap")
    parser.add_argument("--title", required=True)
    parser.add_argument("--proposal-type", default="deferred-feature")
    parser.add_argument("--reason", required=True)
    parser.add_argument("--user-value", required=True)
    parser.add_argument("--scope-summary", default="")
    parser.add_argument("--risk-if-ignored", default="")
    parser.add_argument("--created-by", default="human/copilot")
    parser.add_argument("--source-ref", action="append", default=[])
    parser.add_argument("--evidence", action="append", default=[])
    parser.add_argument("--out-of-scope", action="append", default=[])
    parser.add_argument("--dependency", action="append", default=[])
    parser.add_argument("--verification", action="append", default=[])
    parser.add_argument("--confidence", default="Low")
    parser.add_argument("--complexity", default="Unknown")
    parser.add_argument("--priority", default="Backlog")
    parser.add_argument("--target-milestone", default="")
    parser.add_argument("--management-type", default="Undecided")
    parser.add_argument("--route", default="Undecided")
    parser.add_argument("--primary-location", default="")
    args = parser.parse_args()

    config = load_config()
    policy = load_roadmap_policy(config)
    settings = policy.roadmap
    proposal_root = resolve_inside(config.root, settings.get("proposal_root", ".context-work/roadmap/proposals"))
    proposal_root.mkdir(parents=True, exist_ok=True)
    proposal_id = next_numbered_id(proposal_root, str(settings.get("id_prefix", "RM")))
    roadmap_path = resolve_inside(config.root, settings.get("roadmap_file", config.project.get("roadmap_file", "docs/project-context/roadmap.md")))
    if not roadmap_path.is_file():
        raise FileNotFoundError(f"roadmap does not exist: {relative_posix(config.root, roadmap_path)}")
    data = {
        "id": proposal_id,
        "title": args.title,
        "status": "Draft",
        "proposal_type": args.proposal_type,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "created_by": args.created_by,
        "roadmap_sha256": sha256_file(roadmap_path),
        "reason": args.reason,
        "user_value": args.user_value,
        "scope_summary": args.scope_summary,
        "risk_if_ignored": args.risk_if_ignored,
        "source_refs": args.source_ref,
        "evidence": args.evidence,
        "out_of_scope": args.out_of_scope,
        "dependencies": args.dependency,
        "verification_required": args.verification,
        "confidence": args.confidence,
        "estimated_complexity": args.complexity,
        "priority": args.priority,
        "target_milestone": args.target_milestone,
        "management_type": args.management_type,
        "route": args.route,
        "primary_location": args.primary_location,
        "approved_by": "",
        "approved_at": "",
        "review_notes": "",
    }
    findings = validate_proposal(data, policy)
    if findings:
        print("ROADMAP PROPOSAL NOT CREATED")
        for finding in findings:
            print(f"- {finding}")
        return 1
    output = proposal_root / f"{proposal_id}.toml"
    output.write_text(render_proposal(data), encoding="utf-8")
    print(f"Created {relative_posix(config.root, output)}")
    print("This is an unapproved candidate and does not change the official roadmap.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
