from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path

from project_context_lib import load_config, parse_flat_frontmatter, resolve_inside

REQUIRED_SECTIONS = [
    "## 1. Technical intent",
    "## 2. Requirements and constraints derived from the specification",
    "## 4. Candidate comparison",
    "## 5. Recommended decision",
    "## 6. Decision disposition",
    "## 8. Validation and PoC",
    "## 9. Dependency-management timing",
    "## 10. `/speckit.plan` handoff",
    "## 12. Approval checklist",
]
APPROVAL_ITEMS = [
    "Requirement and constraints approved",
    "Accepted and prohibited technologies approved",
    "Ready for /speckit.plan",
]
PLACEHOLDERS = {"tbd", "to be decided", "unknown", "none", "none specified", "未定", "なし"}


def is_checked(text: str, label: str) -> bool:
    return bool(re.search(rf"^- \[[xX]\]\s+{re.escape(label)}\s*$", text, re.MULTILINE))


def subsection_items(text: str, title: str) -> list[str]:
    match = re.search(rf"^### {re.escape(title)}\s*$\n(.*?)(?=^### |^## |\Z)", text, re.MULTILINE | re.DOTALL)
    if not match:
        return []
    items = []
    for line in match.group(1).splitlines():
        stripped = line.strip()
        if stripped.startswith("- "):
            value = stripped[2:].strip()
            if value:
                items.append(value)
    return items


def meaningful(items: list[str]) -> list[str]:
    return [item for item in items if item.lower().strip(" .") not in PLACEHOLDERS]


def normalized(items: list[str]) -> set[str]:
    return {re.sub(r"\s+", " ", item.lower()).strip(" .") for item in meaningful(items)}


def resolve_spec(root: Path, feature_path: str) -> Path:
    path = resolve_inside(root, feature_path)
    if path.is_dir():
        path = path / "spec.md"
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a pre-plan technical decision")
    parser.add_argument("decision_file")
    parser.add_argument("--require-approved", action="store_true")
    args = parser.parse_args()

    config = load_config()
    path = resolve_inside(config.root, args.decision_file)
    if not path.is_file():
        raise FileNotFoundError(f"Decision file does not exist: {args.decision_file}")
    text = path.read_text(encoding="utf-8")
    metadata = parse_flat_frontmatter(text)
    findings: list[str] = []

    for key in ("technical_decision_id", "status", "feature_path", "spec_sha256", "decision_type", "created", "updated"):
        if not metadata.get(key):
            findings.append(f"missing frontmatter field: {key}")
    for section in REQUIRED_SECTIONS:
        if section not in text:
            findings.append(f"missing section: {section}")

    accepted = subsection_items(text, "Accepted") + subsection_items(text, "Accepted with modification")
    prohibited = subsection_items(text, "Prohibited")
    rejected = subsection_items(text, "Rejected")
    if args.require_approved and not meaningful(accepted):
        findings.append("no explicit accepted technology or approach")
    overlaps = normalized(accepted) & (normalized(prohibited) | normalized(rejected))
    if overlaps:
        findings.append("accepted technology is also prohibited or rejected: " + ", ".join(sorted(overlaps)))

    feature_path = metadata.get("feature_path", "")
    if feature_path:
        spec = resolve_spec(config.root, feature_path)
        if not spec.is_file():
            findings.append(f"current spec.md does not exist under: {feature_path}")
        else:
            current_hash = hashlib.sha256(spec.read_bytes()).hexdigest()
            if metadata.get("spec_sha256") != current_hash:
                findings.append("spec.md changed after the pre-plan decision was created")

    if args.require_approved:
        if metadata.get("status", "").lower() != "approved":
            findings.append("status is not Approved")
        if not metadata.get("approved_by"):
            findings.append("approved_by is empty")
        if not metadata.get("approved_at"):
            findings.append("approved_at is empty")
        for item in APPROVAL_ITEMS:
            if not is_checked(text, item):
                findings.append(f"approval item is not checked: {item}")

    if findings:
        print("PRE-PLAN VALIDATION FAILED")
        for finding in findings:
            print(f"- {finding}")
        return 1

    print("PRE-PLAN DECISION VALID")
    print(f"Decision: {metadata.get('technical_decision_id')}")
    print(f"Status: {metadata.get('status')}; Feature: {metadata.get('feature_path')}")
    if not args.require_approved:
        print("Approval was not required for this validation run.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
