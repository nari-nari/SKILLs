from __future__ import annotations

import hashlib
import re
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from project_context_lib import PackConfig, resolve_inside

HEADING = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*$", re.MULTILINE)


@dataclass(frozen=True)
class ReadmePolicy:
    path: Path
    data: dict[str, Any]

    @property
    def readme(self) -> dict[str, Any]:
        return self.data.get("readme", {})


def load_readme_policy(config: PackConfig) -> ReadmePolicy:
    path = resolve_inside(config.root, ".project-context/readme-policy.toml")
    with path.open("rb") as stream:
        return ReadmePolicy(path, tomllib.load(stream))


def normalize_heading(value: str) -> str:
    value = re.sub(r"[`*_]", "", value)
    value = re.sub(r"\s+", " ", value).strip().casefold()
    return value


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def headings(text: str) -> list[tuple[int, str, int, int]]:
    result: list[tuple[int, str, int, int]] = []
    for match in HEADING.finditer(text):
        result.append((len(match.group(1)), match.group(2).strip(), match.start(), match.end()))
    return result


def replace_or_append_section(text: str, section: str, content: str, *, replace_only: bool) -> tuple[str, str]:
    target = normalize_heading(section)
    found = headings(text)
    for index, (level, title, start, heading_end) in enumerate(found):
        if normalize_heading(title) != target:
            continue
        section_end = len(text)
        for next_level, _next_title, next_start, _next_end in found[index + 1 :]:
            if next_level <= level:
                section_end = next_start
                break
        body = content.strip()
        prefix = text[:heading_end].rstrip()
        suffix = text[section_end:].lstrip("\n")
        updated = f"{prefix}\n\n{body}\n"
        if suffix:
            updated += f"\n{suffix}"
        return updated, "replaced"
    if replace_only:
        raise ValueError(f"README section not found for replace action: {section}")
    body = content.strip()
    separator = "\n\n" if text.strip() else ""
    return f"{text.rstrip()}{separator}## {section}\n\n{body}\n", "appended"


def validate_change_sections(changes: list[dict[str, Any]], policy: ReadmePolicy) -> None:
    managed = {normalize_heading(str(x)) for x in policy.readme.get("managed_sections", [])}
    protected = {normalize_heading(str(x)) for x in policy.readme.get("protected_sections", [])}
    seen: set[str] = set()
    for change in changes:
        section = str(change.get("section", "")).strip()
        normalized = normalize_heading(section)
        if not section:
            raise ValueError("README change section must not be empty")
        if normalized in protected:
            raise ValueError(f"README section is protected: {section}")
        if normalized not in managed:
            raise ValueError(f"README section is not allowlisted: {section}")
        if normalized in seen:
            raise ValueError(f"README proposal contains duplicate section: {section}")
        seen.add(normalized)
        action = str(change.get("action", "upsert"))
        if action not in {"upsert", "replace"}:
            raise ValueError(f"Unsupported README action for {section}: {action}")
        if not str(change.get("content", "")).strip():
            raise ValueError(f"README content must not be empty for section: {section}")
