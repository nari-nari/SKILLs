from __future__ import annotations

import argparse

from ai_exchange_lib import archive_current
from project_context_lib import load_config


def main() -> int:
    parser = argparse.ArgumentParser(description="Archive the visible current internal-AI exchange")
    parser.add_argument("--force", action="store_true", help="Allow archiving an unfinished exchange")
    parser.add_argument("--status", default="archived", choices=["archived", "superseded"])
    args = parser.parse_args()
    destination = archive_current(load_config(), status=args.status, force=args.force)
    if destination is None:
        print("No active exchange to archive")
    else:
        print(f"Archived to {destination}")
        print("ai-exchange/current is ready for the next consultation")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
