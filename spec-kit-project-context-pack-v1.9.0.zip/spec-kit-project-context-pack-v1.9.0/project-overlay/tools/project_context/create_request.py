from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from project_context_lib import load_config, next_request_id, resolve_inside

ALLOWED_MODES = {"quick", "standard", "deep"}
ALLOWED_HINTS = {"feature", "bug", "research", "refactor", "docs", "roadmap", "validation", "import", "context", "unknown"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a local request brief from a short intent")
    parser.add_argument("--intent", required=True, help="Short user intent")
    parser.add_argument("--request-id", help="Optional explicit request ID")
    parser.add_argument("--mode", default="standard", choices=sorted(ALLOWED_MODES))
    parser.add_argument("--hint", default="unknown", choices=sorted(ALLOWED_HINTS))
    parser.add_argument("--triage-reason", default="Detailed intake is required.")
    args = parser.parse_args()

    config = load_config()
    requests = config.requests
    request_root = resolve_inside(config.root, requests.get("work_root", ".context-work/requests"))
    request_root.mkdir(parents=True, exist_ok=True)
    prefix = str(requests.get("id_prefix", "REQ"))
    request_id = args.request_id or next_request_id(request_root, prefix)
    request_dir = request_root / request_id
    if request_dir.exists():
        raise FileExistsError(f"Request already exists: {request_dir.relative_to(config.root)}")

    template_path = resolve_inside(
        config.root,
        requests.get("template_file", ".project-context/templates/request-brief.md"),
    )
    template = template_path.read_text(encoding="utf-8")
    rendered = (
        template.replace("{{REQUEST_ID}}", request_id)
        .replace("{{CREATED_DATE}}", date.today().isoformat())
        .replace("{{USER_INTENT}}", args.intent)
        .replace("{{INTAKE_MODE}}", args.mode)
        .replace("{{REQUEST_HINT}}", args.hint)
        .replace("{{TRIAGE_REASON}}", args.triage_reason.replace("\n", " ").strip())
    )

    request_dir.mkdir(parents=True)
    request_path = request_dir / "request.md"
    request_path.write_text(rendered, encoding="utf-8")
    print(f"Created {request_path.relative_to(config.root)}")
    print(f"Intake: mode={args.mode}; hint={args.hint}")
    print("Status: Draft. Review and approve before downstream prompt generation.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
