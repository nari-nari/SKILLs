from __future__ import annotations

import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError as exc:  # pragma: no cover
    raise RuntimeError("Python 3.11 or newer is required") from exc

from project_context_lib import PackConfig, resolve_inside

SESSION_TYPES = {"new-project", "general", "pre-plan", "roadmap", "other"}
ACTIVE_STATUSES = {"waiting-response", "response-received", "processing"}
COMPLETED_STATUSES = {"processed", "completed", "archived", "superseded"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def exchange_paths(config: PackConfig) -> tuple[Path, Path, Path]:
    current = resolve_inside(config.root, config.ai_exchange.get("current_dir", "ai-exchange/current"))
    templates = resolve_inside(config.root, config.ai_exchange.get("template_dir", "ai-exchange/templates"))
    archive = resolve_inside(config.root, config.ai_exchange.get("archive_dir", ".context-work/ai-exchange/archive"))
    return current, templates, archive


def read_session(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    with path.open("rb") as stream:
        return tomllib.load(stream)


def toml_string(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return f'"{escaped}"'


def write_session(path: Path, data: dict[str, Any]) -> None:
    ordered = [
        "id", "type", "status", "title", "source_path", "created_at",
        "updated_at", "processed_at", "archived_at", "archive_path",
    ]
    lines: list[str] = []
    for key in ordered:
        value = data.get(key, "")
        lines.append(f"{key} = {toml_string(str(value))}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def next_session_id(archive_root: Path, current_session: dict[str, Any], prefix: str = "AI") -> str:
    highest = 0
    pattern = re.compile(rf"^{re.escape(prefix)}-(\d+)$")
    if archive_root.is_dir():
        for item in archive_root.iterdir():
            match = pattern.fullmatch(item.name)
            if match:
                highest = max(highest, int(match.group(1)))
    current_id = str(current_session.get("id", ""))
    match = pattern.fullmatch(current_id)
    if match:
        highest = max(highest, int(match.group(1)))
    return f"{prefix}-{highest + 1:04d}"


def current_readme(session: dict[str, Any]) -> str:
    session_id = str(session.get("id", ""))
    if not session_id:
        return """# Current internal AI exchange\n\n現在進行中の社内AI相談はありません。\n\n## Start here\n\n- 新規プロジェクトの初回仕様整理: `ai-exchange/templates/new-project-intake.md`\n- 既存プロジェクトの相談: `/request-intake [research] ...`\n- spec完成後の技術選定: `/pre-plan-intake ...`\n\n相談を開始すると、このフォルダに`prompt.md`と空の`response.md`が自動作成されます。\n"""
    status = str(session.get("status", "unknown"))
    source = str(session.get("source_path", "")) or "なし"
    return f"""# Current internal AI exchange\n\n- Session: `{session_id}`\n- Type: `{session.get('type', '')}`\n- Status: `{status}`\n- Title: {session.get('title', '')}\n- Source: `{source}`\n\n## Next steps\n\n1. [社内AIへ送るプロンプト](prompt.md)を開いてコピーする。\n2. 社内AIとの対話を完了する。\n3. 最終回答を[回答の貼り付け先](response.md)へ貼り付けて保存する。\n4. `/import-current-internal-ai-response`を実行する。\n5. 処理結果は[result.md](result.md)で確認する。\n\n回答本文をCopilot Chatへ直接貼る場合は、次の形式も利用できます。\n\n```text\n/import-current-internal-ai-response\n\n[社内AIの最終回答]\n```\n\n## Files\n\n- [prompt.md](prompt.md): 社内AIへ送る内容\n- [response.md](response.md): 社内AI回答の貼り付け先（作成済み）\n- [result.md](result.md): Copilotによる取り込み結果\n- [session.toml](session.toml): 自動ルーティング情報。通常は編集不要\n\n`.context-work`は履歴・承認・機械処理用です。日常操作ではこのフォルダだけを使用してください。\n"""


def ensure_empty_workspace(current: Path) -> None:
    current.mkdir(parents=True, exist_ok=True)
    session = {"id": "", "type": "none", "status": "empty", "title": "", "source_path": "", "created_at": "", "updated_at": utc_now(), "processed_at": "", "archived_at": "", "archive_path": ""}
    write_session(current / "session.toml", session)
    (current / "README.md").write_text(current_readme({}), encoding="utf-8")
    for name, heading in (("prompt.md", "# Internal AI prompt"), ("response.md", "# Internal AI response"), ("result.md", "# Import result")):
        path = current / name
        if not path.exists():
            path.write_text(f"{heading}\n\n", encoding="utf-8")


def archive_current(config: PackConfig, *, status: str = "archived", force: bool = False) -> Path | None:
    current, _, archive_root = exchange_paths(config)
    session_path = current / "session.toml"
    session = read_session(session_path)
    session_id = str(session.get("id", ""))
    if not session_id:
        return None
    current_status = str(session.get("status", ""))
    if current_status in ACTIVE_STATUSES and not force:
        raise RuntimeError(f"Current exchange {session_id} is still active ({current_status}). Process it or use --force.")
    destination = archive_root / session_id
    if destination.exists():
        raise FileExistsError(f"Archive already exists: {destination.relative_to(config.root)}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(current, destination)
    archived = read_session(destination / "session.toml")
    archived.update({
        "status": status,
        "updated_at": utc_now(),
        "archived_at": utc_now(),
        "archive_path": destination.relative_to(config.root).as_posix(),
    })
    write_session(destination / "session.toml", archived)
    shutil.rmtree(current)
    ensure_empty_workspace(current)
    return destination


def update_current_readme(config: PackConfig) -> None:
    current, _, _ = exchange_paths(config)
    session = read_session(current / "session.toml")
    (current / "README.md").write_text(current_readme(session if session.get("id") else {}), encoding="utf-8")
