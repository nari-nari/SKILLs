from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def run(script: str, *args: str) -> None:
    here = Path(__file__).resolve().parent
    subprocess.run([sys.executable, str(here / script), *args], check=True)


def main() -> int:
    run("collect_project_inventory.py", "--update-markdown")
    run("collect_project_status.py", "--update-markdown")
    run("build_copilot_snapshot.py")
    run("assess_readme_update.py")
    run("check_context_consistency.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
