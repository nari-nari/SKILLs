from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import subprocess
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import date
from pathlib import Path
from typing import Any

from project_context_lib import load_config, relative_posix, resolve_inside, write_json

START = "<!-- AUTO:PROJECT_INVENTORY:START -->"
END = "<!-- AUTO:PROJECT_INVENTORY:END -->"


@dataclass
class InventoryItem:
    path: str
    category: str
    origin: str
    component: str | None
    related_specs: list[str]
    size: int
    sha256: str | None


def matches(path: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(path, pattern) for pattern in patterns)


def git_files(root: Path, include_untracked: bool) -> list[str]:
    args = ["git", "-C", str(root), "ls-files"]
    if include_untracked:
        args.extend(["--cached", "--others", "--exclude-standard"])
    result = subprocess.run(args, check=True, capture_output=True, text=True)
    return sorted({line.strip() for line in result.stdout.splitlines() if line.strip()})


def walked_files(root: Path) -> list[str]:
    return sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file())


def classify(path: str, config: dict[str, Any]) -> str:
    if path.startswith("specs/") or path.startswith(".specify/"):
        return "spec-kit"
    if path.startswith(".github/") or path.startswith(".project-context/") or path.startswith("docs/project-context/") or path.startswith("tools/project_context/"):
        return "project-management"
    groups = [
        ("tests", config.get("test_globs", [])),
        ("source", config.get("source_globs", [])),
        ("documentation", config.get("documentation_globs", [])),
        ("configuration", config.get("configuration_globs", [])),
        ("data", config.get("data_globs", [])),
    ]
    for name, patterns in groups:
        if matches(path, [str(x) for x in patterns]):
            return name
    if path.startswith("tools/") or path.startswith("scripts/"):
        return "tooling"
    return "other"


def load_components(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    import tomllib
    with path.open("rb") as stream:
        data = tomllib.load(stream)
    return [dict(item) for item in data.get("components", [])]


def component_for(path: str, components: list[dict[str, Any]]) -> dict[str, Any] | None:
    for component in components:
        if matches(path, [str(x) for x in component.get("paths", [])]):
            return component
    return None


def load_managed_paths(root: Path) -> set[str]:
    manifest = root / ".project-context" / "install-manifest.json"
    if not manifest.is_file():
        return set()
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return set()
    return {str(item.get("path")) for item in data.get("files", []) if item.get("path")}


def default_origin(path: str, managed_paths: set[str]) -> str:
    if path.startswith("specs/") or path.startswith(".specify/"):
        return "speckit"
    if path in managed_paths or path.startswith(".project-context/generated/"):
        return "context-pack"
    return "project"


def replace_block(text: str, block: str) -> str:
    if START not in text or END not in text:
        raise ValueError("project-map.md does not contain the required AUTO markers")
    before, rest = text.split(START, 1)
    _, after = rest.split(END, 1)
    return f"{before}{START}\n{block}\n{END}{after}"


def render(items: list[InventoryItem], components: list[dict[str, Any]], mode: str) -> str:
    categories = Counter(item.category for item in items)
    origins = Counter(item.origin for item in items)
    unmapped = [item for item in items if item.component is None and item.category not in {"project-management", "spec-kit"}]
    lines = [
        f"Generated: {date.today().isoformat()}  ",
        f"Inventory mode: `{mode}`  ",
        f"Files inventoried: **{len(items)}**",
        "",
        "### Files by category",
        "",
        "| Category | Files |",
        "|---|---:|",
    ]
    for key, count in sorted(categories.items()):
        lines.append(f"| {key} | {count} |")
    lines += ["", "### Files by origin", "", "| Origin | Files |", "|---|---:|"]
    for key, count in sorted(origins.items()):
        lines.append(f"| {key} | {count} |")
    lines += ["", "### Registered components", ""]
    if components:
        lines += ["| Component | Origin | Lifecycle | Related specs |", "|---|---|---|---|"]
        for comp in components:
            specs = ", ".join(f"`{x}`" for x in comp.get("related_specs", [])) or "—"
            lines.append(f"| `{comp.get('id','unknown')}` | {comp.get('origin','unspecified')} | {comp.get('lifecycle','unspecified')} | {specs} |")
    else:
        lines.append("No components are registered in `.project-context/components.toml`.")
    lines += [
        "",
        "### Files not assigned to a registered component",
        "",
        f"{len(unmapped)} file(s). This is not automatically an error; register only components whose provenance or lifecycle matters.",
        "",
        "> Inventory presence does not establish that a file is understood, tested, supported, or production-ready.",
    ]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Inventory the whole project, not only Spec Kit artifacts")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--update-markdown", action="store_true")
    args = parser.parse_args()

    config = load_config()
    inv = config.data.get("inventory", {})
    mode = str(inv.get("mode", "git"))
    try:
        paths = git_files(config.root, bool(inv.get("include_untracked", True))) if mode == "git" else walked_files(config.root)
    except (subprocess.CalledProcessError, FileNotFoundError):
        mode = "walk-fallback"
        paths = walked_files(config.root)
    excludes = [str(x) for x in inv.get("exclude_globs", [])]
    paths = [p for p in paths if not matches(p, excludes)]
    registry_path = resolve_inside(config.root, config.project.get("component_registry", ".project-context/components.toml"))
    components = load_components(registry_path)
    managed_paths = load_managed_paths(config.root)
    max_hash = int(inv.get("max_hash_bytes", 1000000))
    items: list[InventoryItem] = []
    for rel in paths:
        full = resolve_inside(config.root, rel)
        if not full.is_file():
            continue
        comp = component_for(rel, components)
        size = full.stat().st_size
        digest = hashlib.sha256(full.read_bytes()).hexdigest() if size <= max_hash else None
        items.append(InventoryItem(
            path=rel,
            category=classify(rel, inv),
            origin=str(comp.get("origin")) if comp else default_origin(rel, managed_paths),
            component=str(comp.get("id")) if comp else None,
            related_specs=[str(x) for x in comp.get("related_specs", [])] if comp else [],
            size=size,
            sha256=digest,
        ))
    payload = {
        "generated_on": date.today().isoformat(),
        "inventory_mode": mode,
        "project": config.project.get("name", "CHANGE_ME"),
        "components": components,
        "files": [asdict(item) for item in items],
    }
    out = resolve_inside(config.root, config.project.get("generated_inventory_json", ".project-context/generated/project-inventory.json"))
    write_json(out, payload)
    if args.update_markdown:
        project_map = resolve_inside(config.root, config.project.get("project_map_file", "docs/project-context/project-map.md"))
        current = project_map.read_text(encoding="utf-8")
        project_map.write_text(replace_block(current, render(items, components, mode)), encoding="utf-8")
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"Inventoried {len(items)} file(s); wrote {relative_posix(config.root, out)}")
        if args.update_markdown:
            print("Updated project-map.md auto-generated block")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
