from __future__ import annotations

import argparse
import difflib
import json
import shutil
from datetime import datetime, timezone

from project_context_lib import load_config, relative_posix, resolve_inside, write_json
from roadmap_management_lib import (
    escape_markdown_cell,
    insert_before_marker,
    load_proposal,
    load_roadmap_policy,
    mark_promoted,
    next_workstream_id,
    validate_proposal,
)

WORKSTREAM_END = "<!-- AUTO:APPROVED_ROADMAP:END -->"
CHANGELOG_END = "<!-- AUTO:ROADMAP_CHANGE_LOG:END -->"


def main() -> int:
    parser = argparse.ArgumentParser(description="Preview or apply an approved roadmap proposal")
    parser.add_argument("proposal")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    config = load_config()
    policy = load_roadmap_policy(config)
    settings = policy.roadmap
    proposal_path = resolve_inside(config.root, args.proposal)
    roadmap_path = resolve_inside(
        config.root,
        settings.get("roadmap_file", config.project.get("roadmap_file", "docs/project-context/roadmap.md")),
    )
    data = load_proposal(proposal_path)
    findings = validate_proposal(data, policy, require_approved=True, current_roadmap=roadmap_path)
    if findings:
        print("ROADMAP PROMOTION BLOCKED")
        for finding in findings:
            print(f"- {finding}")
        return 1

    original = roadmap_path.read_text(encoding="utf-8")
    proposal_id = str(data["id"])
    if proposal_id in original:
        raise ValueError(f"proposal already appears in official roadmap: {proposal_id}")
    workstream_id = next_workstream_id(original, str(settings.get("workstream_prefix", "W")))
    dependencies = ", ".join(str(x) for x in data.get("dependencies", [])) or "—"
    verification = "; ".join(str(x) for x in data.get("verification_required", [])) or "—"
    purpose = str(data.get("user_value") or data.get("scope_summary") or data.get("reason"))
    row = "| " + " | ".join([
        escape_markdown_cell(workstream_id),
        escape_markdown_cell(str(data["title"])),
        escape_markdown_cell(str(data["management_type"])),
        escape_markdown_cell(purpose),
        escape_markdown_cell(dependencies),
        escape_markdown_cell(str(policy.promotion.get("initial_state", "Planned"))),
        escape_markdown_cell(str(data.get("primary_location") or "TBD")),
        escape_markdown_cell(verification),
        escape_markdown_cell(proposal_id),
    ]) + " |"
    updated = insert_before_marker(original, WORKSTREAM_END, row)
    approved_at = str(data.get("approved_at", ""))
    date = approved_at[:10] if len(approved_at) >= 10 else datetime.now(timezone.utc).date().isoformat()
    change = "| " + " | ".join([
        escape_markdown_cell(date),
        escape_markdown_cell(f"Promoted {proposal_id} as {workstream_id}: {data['title']}"),
        escape_markdown_cell(str(data["reason"])),
        escape_markdown_cell(str(data["approved_by"])),
    ]) + " |"
    updated = insert_before_marker(updated, CHANGELOG_END, change)

    diff = "".join(difflib.unified_diff(
        original.splitlines(keepends=True),
        updated.splitlines(keepends=True),
        fromfile=f"a/{relative_posix(config.root, roadmap_path)}",
        tofile=f"b/{relative_posix(config.root, roadmap_path)}",
    ))
    print(diff)
    print(f"Validated promotion: {proposal_id} -> {workstream_id}")
    if not args.apply:
        print("Dry run only. Re-run with --apply after reviewing this diff.")
        return 0

    backup_root = resolve_inside(config.root, settings.get("backup_root", ".context-work/roadmap/backups"))
    backup_root.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = backup_root / f"roadmap.{timestamp}.md.bak"
    shutil.copy2(roadmap_path, backup)
    roadmap_path.write_text(updated, encoding="utf-8")
    mark_promoted(proposal_path)

    record_path = resolve_inside(config.root, settings.get("promotion_record", ".project-context/generated/roadmap-promotions.json"))
    records: list[dict[str, str]] = []
    if record_path.is_file():
        loaded = json.loads(record_path.read_text(encoding="utf-8"))
        if isinstance(loaded, list):
            records = [dict(item) for item in loaded]
    records.append({
        "proposal_id": proposal_id,
        "workstream_id": workstream_id,
        "title": str(data["title"]),
        "approved_by": str(data["approved_by"]),
        "approved_at": approved_at,
        "promoted_at": datetime.now(timezone.utc).isoformat(),
        "route": str(data["route"]),
        "management_type": str(data["management_type"]),
    })
    write_json(record_path, records)
    print(f"Applied roadmap promotion. Backup: {relative_posix(config.root, backup)}")
    print(f"Promotion record: {relative_posix(config.root, record_path)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
