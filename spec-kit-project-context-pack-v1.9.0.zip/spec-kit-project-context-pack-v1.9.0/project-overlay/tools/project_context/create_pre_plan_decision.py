from __future__ import annotations

import argparse
import hashlib
from datetime import date
from pathlib import Path

from project_context_lib import load_config, next_request_id, relative_posix, resolve_inside


def resolve_spec(root: Path, value: str) -> Path:
    path = resolve_inside(root, value)
    if path.is_dir():
        path = path / "spec.md"
    if path.name != "spec.md" and path.suffix.lower() != ".md":
        candidate = path / "spec.md"
        if candidate.is_file():
            path = candidate
    if not path.is_file():
        raise FileNotFoundError(f"Specification does not exist: {value}")
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a pre-plan technical decision from an approved specification")
    parser.add_argument("feature", help="Feature directory or spec.md path")
    parser.add_argument("--intent", required=True, help="Short technical-selection intent")
    parser.add_argument("--decision-type", default="dependency-selection")
    parser.add_argument("--decision-id")
    args = parser.parse_args()

    config = load_config()
    policy = config.data.get("pre_plan", {})
    allowed = set(policy.get("allowed_decision_types", []))
    if allowed and args.decision_type not in allowed:
        raise ValueError(f"Unsupported decision type: {args.decision_type}")

    spec = resolve_spec(config.root, args.feature)
    work_root = resolve_inside(config.root, policy.get("work_root", ".context-work/pre-plan"))
    work_root.mkdir(parents=True, exist_ok=True)
    prefix = str(policy.get("id_prefix", "TP"))
    decision_id = args.decision_id or next_request_id(work_root, prefix)
    decision_dir = work_root / decision_id
    if decision_dir.exists():
        raise FileExistsError(f"Pre-plan decision already exists: {decision_dir.relative_to(config.root)}")

    template = resolve_inside(
        config.root,
        policy.get("template_file", ".project-context/templates/pre-plan-decision.md"),
    ).read_text(encoding="utf-8")
    spec_hash = hashlib.sha256(spec.read_bytes()).hexdigest()
    rendered = (
        template.replace("{{TECHNICAL_DECISION_ID}}", decision_id)
        .replace("{{FEATURE_PATH}}", relative_posix(config.root, spec.parent))
        .replace("{{SPEC_SHA256}}", spec_hash)
        .replace("{{DECISION_TYPE}}", args.decision_type)
        .replace("{{CREATED_DATE}}", date.today().isoformat())
        .replace("{{TECHNICAL_INTENT}}", args.intent)
    )
    decision_dir.mkdir(parents=True)
    decision = decision_dir / "decision.md"
    decision.write_text(rendered, encoding="utf-8")
    print(f"Created {decision.relative_to(config.root)}")
    print(f"Specification: {relative_posix(config.root, spec)}")
    print("Status: Draft. Do not run /speckit.plan until the decision passes approved validation.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
