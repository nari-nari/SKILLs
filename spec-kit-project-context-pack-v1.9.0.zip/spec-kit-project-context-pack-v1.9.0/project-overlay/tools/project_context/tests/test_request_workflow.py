from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

from project_context_lib import next_request_id, parse_flat_frontmatter  # noqa: E402


class RequestWorkflowTests(unittest.TestCase):
    def test_next_request_id(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "REQ-0001").mkdir()
            (root / "REQ-0010").mkdir()
            (root / "OTHER-9999").mkdir()
            self.assertEqual(next_request_id(root, "REQ"), "REQ-0011")

    def test_parse_flat_frontmatter(self) -> None:
        text = "---\nrequest_id: REQ-0001\nstatus: Approved\nroute: plan\n---\n# Body\n"
        self.assertEqual(
            parse_flat_frontmatter(text),
            {"request_id": "REQ-0001", "status": "Approved", "route": "plan"},
        )

    def test_create_and_validate_request(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            (repo / ".project-context" / "templates").mkdir(parents=True)
            (repo / "tools" / "project_context").mkdir(parents=True)
            template = Path(__file__).resolve().parents[3] / ".project-context" / "templates" / "request-brief.md"
            (repo / ".project-context" / "templates" / "request-brief.md").write_text(template.read_text(encoding="utf-8"), encoding="utf-8")
            (repo / ".project-context" / "context.toml").write_text(
                "[requests]\nwork_root='.context-work/requests'\ntemplate_file='.project-context/templates/request-brief.md'\nid_prefix='REQ'\n",
                encoding="utf-8",
            )
            env = {"PYTHONPATH": str(TOOLS)}
            result = subprocess.run(
                [sys.executable, str(TOOLS / "create_request.py"), "--intent", "short intent"],
                cwd=repo,
                env=env,
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            request = repo / ".context-work" / "requests" / "REQ-0001" / "request.md"
            self.assertTrue(request.is_file())
            self.assertIn("short intent", request.read_text(encoding="utf-8"))

            validation = subprocess.run(
                [sys.executable, str(TOOLS / "validate_request.py"), str(request.relative_to(repo))],
                cwd=repo,
                env=env,
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(validation.returncode, 0, validation.stdout + validation.stderr)


class RequestIntakeRoutingTests(unittest.TestCase):
    def _make_repo(self, root: Path) -> None:
        (root / ".project-context" / "templates").mkdir(parents=True)
        template = Path(__file__).resolve().parents[3] / ".project-context" / "templates" / "request-brief.md"
        policy = Path(__file__).resolve().parents[3] / ".project-context" / "request-intake-policy.toml"
        (root / ".project-context" / "templates" / "request-brief.md").write_text(template.read_text(encoding="utf-8"), encoding="utf-8")
        (root / ".project-context" / "request-intake-policy.toml").write_text(policy.read_text(encoding="utf-8"), encoding="utf-8")
        (root / ".project-context" / "context.toml").write_text(
            "[requests]\nwork_root='.context-work/requests'\ntemplate_file='.project-context/templates/request-brief.md'\nid_prefix='REQ'\nintake_policy_file='.project-context/request-intake-policy.toml'\n",
            encoding="utf-8",
        )

    def test_quick_docs_routes_without_request(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            result = subprocess.run(
                [sys.executable, str(TOOLS / "parse_request_intake.py"), "--input", "quick [docs] READMEに設定保存機能を反映したい"],
                cwd=repo,
                env={"PYTHONPATH": str(TOOLS)},
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('"mode": "quick"', result.stdout)
            self.assertIn('"route": "readme-assessment"', result.stdout)
            self.assertIn('"request_required": false', result.stdout)

    def test_standard_feature_requires_full_intake(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            result = subprocess.run(
                [sys.executable, str(TOOLS / "parse_request_intake.py"), "--input", "[feature] 設定保存機能を追加したい"],
                cwd=repo,
                env={"PYTHONPATH": str(TOOLS)},
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('"mode": "standard"', result.stdout)
            self.assertIn('"hint": "feature"', result.stdout)
            self.assertIn('"request_required": true', result.stdout)

    def test_research_after_spec_routes_to_pre_plan(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            result = subprocess.run(
                [sys.executable, str(TOOLS / "parse_request_intake.py"), "--input", "[research] spec完成後のGUIパッケージをplan前に選定したい"],
                cwd=repo,
                env={"PYTHONPATH": str(TOOLS)},
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('"route": "pre-plan-intake"', result.stdout)
            self.assertIn('"request_required": false', result.stdout)

    def test_create_request_records_intake_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            result = subprocess.run(
                [sys.executable, str(TOOLS / "create_request.py"), "--intent", "統合したい", "--mode", "deep", "--hint", "refactor", "--triage-reason", "cross component"],
                cwd=repo,
                env={"PYTHONPATH": str(TOOLS)},
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            text = (repo / ".context-work" / "requests" / "REQ-0001" / "request.md").read_text(encoding="utf-8")
            self.assertIn("intake_mode: deep", text)
            self.assertIn("request_hint: refactor", text)
            self.assertIn("triage_reason: cross component", text)


if __name__ == "__main__":
    unittest.main()
