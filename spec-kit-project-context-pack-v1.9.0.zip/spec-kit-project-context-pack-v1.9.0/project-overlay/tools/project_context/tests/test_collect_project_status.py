from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

from collect_project_status import inspect_feature, replace_block  # noqa: E402


class CollectStatusTests(unittest.TestCase):
    def test_inspect_feature_counts_tasks_without_claiming_acceptance(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            feature = Path(temp) / "001-demo"
            feature.mkdir()
            (feature / "spec.md").write_text("# Spec\n", encoding="utf-8")
            (feature / "plan.md").write_text("# Plan\n", encoding="utf-8")
            (feature / "tasks.md").write_text("- [X] done\n- [ ] pending\n", encoding="utf-8")
            status = inspect_feature(feature)
            self.assertEqual(status.tasks_done, 1)
            self.assertEqual(status.tasks_total, 2)
            self.assertEqual(status.derived_state, "In progress")

    def test_replace_block(self) -> None:
        source = "A\n<!-- AUTO:FEATURE_STATUS:START -->\nold\n<!-- AUTO:FEATURE_STATUS:END -->\nB\n"
        updated = replace_block(source, "new")
        self.assertIn("\nnew\n", updated)
        self.assertNotIn("old", updated)


if __name__ == "__main__":
    unittest.main()
