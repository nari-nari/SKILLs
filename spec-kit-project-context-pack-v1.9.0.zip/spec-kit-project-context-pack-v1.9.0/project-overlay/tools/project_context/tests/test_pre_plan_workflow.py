from __future__ import annotations

import hashlib
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
OVERLAY = Path(__file__).resolve().parents[3]


class PrePlanWorkflowTests(unittest.TestCase):
    def _make_repo(self, root: Path) -> Path:
        (root / ".project-context" / "templates").mkdir(parents=True)
        (root / "specs" / "001-demo").mkdir(parents=True)
        (root / ".project-context" / "templates" / "pre-plan-decision.md").write_text(
            (OVERLAY / ".project-context" / "templates" / "pre-plan-decision.md").read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        (root / ".project-context" / "pre-plan-policy.toml").write_text(
            (OVERLAY / ".project-context" / "pre-plan-policy.toml").read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        (root / ".project-context" / "context.toml").write_text(
            "[pre_plan]\nwork_root='.context-work/pre-plan'\ntemplate_file='.project-context/templates/pre-plan-decision.md'\nid_prefix='TP'\nallowed_decision_types=['dependency-selection','framework-selection']\n",
            encoding="utf-8",
        )
        spec = root / "specs" / "001-demo" / "spec.md"
        spec.write_text("# Demo specification\n\nThe GUI supports interactive range editing.\n", encoding="utf-8")
        return spec

    def _create(self, repo: Path) -> Path:
        result = subprocess.run(
            [sys.executable, str(TOOLS / "create_pre_plan_decision.py"), "specs/001-demo", "--intent", "Select GUI framework", "--decision-type", "framework-selection"],
            cwd=repo,
            env={"PYTHONPATH": str(TOOLS)},
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return repo / ".context-work" / "pre-plan" / "TP-0001" / "decision.md"

    def _approve(self, decision: Path) -> None:
        text = decision.read_text(encoding="utf-8")
        text = text.replace("status: Draft", "status: Approved")
        text = text.replace("approved_by:", "approved_by: project-owner")
        text = text.replace("approved_at:", "approved_at: 2026-08-07T10:00:00+09:00")
        text = text.replace("### Accepted\n\n- TBD", "### Accepted\n\n- PySide6 for the desktop GUI")
        text = text.replace("### Prohibited\n\n- None specified", "### Prohibited\n\n- tkinter for the production GUI")
        for label in (
            "Requirement and constraints approved",
            "Accepted and prohibited technologies approved",
            "Ready for /speckit.plan",
        ):
            text = text.replace(f"- [ ] {label}", f"- [x] {label}")
        decision.write_text(text, encoding="utf-8")

    def test_create_records_current_spec_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            spec = self._make_repo(repo)
            decision = self._create(repo)
            self.assertIn(hashlib.sha256(spec.read_bytes()).hexdigest(), decision.read_text(encoding="utf-8"))

    def test_approved_decision_validates(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            decision = self._create(repo)
            self._approve(decision)
            result = subprocess.run(
                [sys.executable, str(TOOLS / "validate_pre_plan_decision.py"), str(decision.relative_to(repo)), "--require-approved"],
                cwd=repo,
                env={"PYTHONPATH": str(TOOLS)},
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_stale_spec_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            spec = self._make_repo(repo)
            decision = self._create(repo)
            self._approve(decision)
            spec.write_text(spec.read_text(encoding="utf-8") + "\nChanged requirement.\n", encoding="utf-8")
            result = subprocess.run(
                [sys.executable, str(TOOLS / "validate_pre_plan_decision.py"), str(decision.relative_to(repo)), "--require-approved"],
                cwd=repo,
                env={"PYTHONPATH": str(TOOLS)},
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("spec.md changed", result.stdout)

    def test_accepted_and_prohibited_overlap_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            decision = self._create(repo)
            self._approve(decision)
            text = decision.read_text(encoding="utf-8").replace(
                "- tkinter for the production GUI", "- PySide6 for the desktop GUI"
            )
            decision.write_text(text, encoding="utf-8")
            result = subprocess.run(
                [sys.executable, str(TOOLS / "validate_pre_plan_decision.py"), str(decision.relative_to(repo)), "--require-approved"],
                cwd=repo,
                env={"PYTHONPATH": str(TOOLS)},
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("also prohibited", result.stdout)


if __name__ == "__main__":
    unittest.main()
