from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
OVERLAY = Path(__file__).resolve().parents[3]


class RoadmapManagementTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.repo = Path(self.temp.name)
        (self.repo / ".project-context" / "templates").mkdir(parents=True)
        (self.repo / "docs" / "project-context").mkdir(parents=True)
        (self.repo / ".project-context" / "roadmap-policy.toml").write_text(
            (OVERLAY / ".project-context" / "roadmap-policy.toml").read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        (self.repo / ".project-context" / "templates" / "roadmap-proposal.toml").write_text(
            (OVERLAY / ".project-context" / "templates" / "roadmap-proposal.toml").read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        (self.repo / "docs" / "project-context" / "roadmap.md").write_text(
            (OVERLAY / "docs" / "project-context" / "roadmap.md").read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        (self.repo / ".project-context" / "context.toml").write_text(
            "[project]\nroadmap_file='docs/project-context/roadmap.md'\n"
            "[roadmap]\npolicy_file='.project-context/roadmap-policy.toml'\n",
            encoding="utf-8",
        )
        self.env = {**os.environ, "PYTHONPATH": str(TOOLS)}

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_tool(self, name: str, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(TOOLS / name), *args],
            cwd=self.repo,
            env=self.env,
            check=False,
            capture_output=True,
            text=True,
        )

    def test_create_validate_and_apply_approved_proposal(self) -> None:
        created = self.run_tool(
            "create_roadmap_proposal.py",
            "--title", "Settings persistence",
            "--proposal-type", "deferred-feature",
            "--reason", "Too large for the first analysis PoC",
            "--user-value", "Restore ranges when reopening the same file",
            "--source-ref", "specs/001-analysis/spec.md",
            "--verification", "Synthetic fixture save and reload test",
        )
        self.assertEqual(created.returncode, 0, created.stdout + created.stderr)
        proposal = self.repo / ".context-work" / "roadmap" / "proposals" / "RM-0001.toml"
        self.assertTrue(proposal.is_file())

        text = proposal.read_text(encoding="utf-8")
        text = text.replace('status = "Draft"', 'status = "Approved"')
        text = text.replace('management_type = "Undecided"', 'management_type = "Spec Kit"')
        text = text.replace('route = "Undecided"', 'route = "speckit-specify"')
        text = text.replace('approved_by = ""', 'approved_by = "project owner"')
        text = text.replace('approved_at = ""', 'approved_at = "2026-08-07T04:00:00+09:00"')
        proposal.write_text(text, encoding="utf-8")

        validation = self.run_tool(
            "validate_roadmap_proposal.py",
            str(proposal.relative_to(self.repo)),
            "--require-approved",
        )
        self.assertEqual(validation.returncode, 0, validation.stdout + validation.stderr)

        roadmap = self.repo / "docs" / "project-context" / "roadmap.md"
        original = roadmap.read_text(encoding="utf-8")
        preview = self.run_tool("apply_roadmap_update.py", str(proposal.relative_to(self.repo)))
        self.assertEqual(preview.returncode, 0, preview.stdout + preview.stderr)
        self.assertIn("Settings persistence", preview.stdout)
        self.assertEqual(roadmap.read_text(encoding="utf-8"), original)

        applied = self.run_tool("apply_roadmap_update.py", str(proposal.relative_to(self.repo)), "--apply")
        self.assertEqual(applied.returncode, 0, applied.stdout + applied.stderr)
        updated = roadmap.read_text(encoding="utf-8")
        self.assertIn("Settings persistence", updated)
        self.assertIn("RM-0001", updated)
        self.assertIn("W001", updated)
        self.assertIn('status = "Promoted"', proposal.read_text(encoding="utf-8"))
        self.assertTrue(any((self.repo / ".context-work" / "roadmap" / "backups").glob("*.bak")))
        self.assertTrue((self.repo / ".project-context" / "generated" / "roadmap-promotions.json").is_file())

    def test_predicted_feature_requires_evidence(self) -> None:
        result = self.run_tool(
            "create_roadmap_proposal.py",
            "--title", "Automatic anomaly classification",
            "--proposal-type", "predicted-feature",
            "--reason", "May be useful later",
            "--user-value", "Reduce manual review",
            "--source-ref", "docs/project-context/status.md",
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("requires at least one evidence", result.stdout)

    def test_stale_roadmap_blocks_promotion(self) -> None:
        created = self.run_tool(
            "create_roadmap_proposal.py",
            "--title", "Export reports",
            "--reason", "Deferred from current scope",
            "--user-value", "Share results",
            "--source-ref", "user-approved-scope",
            "--verification", "Export acceptance test",
        )
        self.assertEqual(created.returncode, 0, created.stdout + created.stderr)
        proposal = self.repo / ".context-work" / "roadmap" / "proposals" / "RM-0001.toml"
        text = proposal.read_text(encoding="utf-8")
        for old, new in [
            ('status = "Draft"', 'status = "Approved"'),
            ('management_type = "Undecided"', 'management_type = "manual"'),
            ('route = "Undecided"', 'route = "manual-workstream"'),
            ('approved_by = ""', 'approved_by = "owner"'),
            ('approved_at = ""', 'approved_at = "2026-08-07T04:00:00+09:00"'),
        ]:
            text = text.replace(old, new)
        proposal.write_text(text, encoding="utf-8")
        roadmap = self.repo / "docs" / "project-context" / "roadmap.md"
        roadmap.write_text(roadmap.read_text(encoding="utf-8") + "\nExternal edit.\n", encoding="utf-8")
        applied = self.run_tool("apply_roadmap_update.py", str(proposal.relative_to(self.repo)), "--apply")
        self.assertNotEqual(applied.returncode, 0)
        self.assertIn("roadmap changed", applied.stdout)


if __name__ == "__main__":
    unittest.main()
