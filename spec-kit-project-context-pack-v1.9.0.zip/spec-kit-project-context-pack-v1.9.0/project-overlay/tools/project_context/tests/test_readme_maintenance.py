from __future__ import annotations

import hashlib
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

from readme_maintenance_lib import ReadmePolicy, replace_or_append_section, validate_change_sections  # noqa: E402


class ReadmeMaintenanceTests(unittest.TestCase):
    def test_replace_section_preserves_other_sections(self) -> None:
        source = "# Demo\n\n## Overview\n\nOld text.\n\n## License\n\nKeep me.\n"
        updated, action = replace_or_append_section(source, "Overview", "New text.", replace_only=True)
        self.assertEqual(action, "replaced")
        self.assertIn("## Overview\n\nNew text.", updated)
        self.assertIn("## License\n\nKeep me.", updated)
        self.assertNotIn("Old text", updated)

    def test_append_missing_allowlisted_section(self) -> None:
        source = "# Demo\n"
        updated, action = replace_or_append_section(source, "Usage", "Run `demo`.", replace_only=False)
        self.assertEqual(action, "appended")
        self.assertIn("## Usage", updated)

    def test_protected_section_is_rejected(self) -> None:
        policy = ReadmePolicy(
            Path("policy.toml"),
            {"readme": {"managed_sections": ["Overview"], "protected_sections": ["License"]}},
        )
        with self.assertRaises(ValueError):
            validate_change_sections([{"section": "License", "action": "upsert", "content": "x"}], policy)

    def test_apply_requires_approved_and_matching_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            (repo / ".project-context").mkdir()
            (repo / ".context-work" / "readme" / "updates").mkdir(parents=True)
            readme = repo / "README.md"
            readme.write_text("# Demo\n\n## Overview\n\nOld.\n", encoding="utf-8")
            digest = hashlib.sha256(readme.read_bytes()).hexdigest()
            (repo / ".project-context" / "context.toml").write_text("[project]\nreadme_file='README.md'\n", encoding="utf-8")
            (repo / ".project-context" / "readme-policy.toml").write_text(
                "[readme]\nreadme_file='README.md'\nmanaged_sections=['Overview']\nprotected_sections=['License']\nbackup_root='.context-work/readme/backups'\n",
                encoding="utf-8",
            )
            proposal = repo / ".context-work" / "readme" / "updates" / "README-UPDATE-0001.toml"
            proposal.write_text(
                f'''status = "Approved"\nreadme_file = "README.md"\nreadme_sha256 = "{digest}"\napproved_by = "tester"\n[[changes]]\nsection = "Overview"\naction = "replace"\ncontent = "New."\n''',
                encoding="utf-8",
            )
            result = subprocess.run(
                [sys.executable, str(TOOLS / "apply_readme_update.py"), str(proposal.relative_to(repo)), "--apply"],
                cwd=repo,
                env={"PYTHONPATH": str(TOOLS)},
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("New.", readme.read_text(encoding="utf-8"))
            self.assertTrue((repo / ".context-work" / "readme" / "backups").is_dir())


if __name__ == "__main__":
    unittest.main()
