from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
OVERLAY = Path(__file__).resolve().parents[3]
PACK_ROOT = OVERLAY.parent


class AIExchangeWorkspaceTests(unittest.TestCase):
    def _make_repo(self, root: Path) -> None:
        (root / ".project-context").mkdir(parents=True)
        (root / "ai-exchange" / "templates").mkdir(parents=True)
        (root / "ai-exchange" / "current").mkdir(parents=True)
        (root / ".project-context" / "context.toml").write_text(
            """[ai_exchange]\ncurrent_dir='ai-exchange/current'\ntemplate_dir='ai-exchange/templates'\narchive_dir='.context-work/ai-exchange/archive'\nid_prefix='AI'\n\n[redaction]\npatterns=[]\nforbidden_literals=[]\n""",
            encoding="utf-8",
        )
        (root / "ai-exchange" / "templates" / "general-consultation.md").write_text(
            "# Prompt\n\nCompare options.\n", encoding="utf-8"
        )

    def _run(self, repo: Path, script: str, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(TOOLS / script), *args],
            cwd=repo,
            env={"PYTHONPATH": str(TOOLS)},
            check=False,
            capture_output=True,
            text=True,
        )

    def test_create_visible_session_and_empty_response(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            result = self._run(
                repo,
                "create_ai_exchange_session.py",
                "--type", "general",
                "--title", "GUI framework",
                "--source", ".context-work/requests/REQ-0001/request.md",
                "--prompt-file", "ai-exchange/templates/general-consultation.md",
            )
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            current = repo / "ai-exchange" / "current"
            for name in ("README.md", "prompt.md", "response.md", "result.md", "session.toml"):
                self.assertTrue((current / name).is_file(), name)
            self.assertIn("AI-0001", (current / "session.toml").read_text(encoding="utf-8"))
            self.assertIn("/import-current-internal-ai-response", (current / "README.md").read_text(encoding="utf-8"))
            response = (current / "response.md").read_text(encoding="utf-8")
            self.assertIn("Paste the final", response)

    def test_active_session_cannot_be_replaced(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            args = (
                "--type", "general", "--title", "First",
                "--prompt-file", "ai-exchange/templates/general-consultation.md",
            )
            self.assertEqual(self._run(repo, "create_ai_exchange_session.py", *args).returncode, 0)
            second = self._run(repo, "create_ai_exchange_session.py", *args)
            self.assertNotEqual(second.returncode, 0)
            self.assertIn("still active", second.stderr)

    def test_processed_session_is_archived_when_next_starts(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            args = (
                "--type", "general", "--title", "First",
                "--prompt-file", "ai-exchange/templates/general-consultation.md",
            )
            self.assertEqual(self._run(repo, "create_ai_exchange_session.py", *args).returncode, 0)
            (repo / "ai-exchange" / "current" / "response.md").write_text("# Internal AI response\n\nAnswer\n", encoding="utf-8")
            self.assertEqual(self._run(repo, "mark_ai_exchange_session.py", "--status", "processed").returncode, 0)
            second = self._run(repo, "create_ai_exchange_session.py", "--type", "pre-plan", "--title", "Second", "--prompt-file", "ai-exchange/templates/general-consultation.md")
            self.assertEqual(second.returncode, 0, second.stdout + second.stderr)
            self.assertTrue((repo / ".context-work" / "ai-exchange" / "archive" / "AI-0001" / "response.md").is_file())
            self.assertIn("AI-0002", (repo / "ai-exchange" / "current" / "session.toml").read_text(encoding="utf-8"))

    def test_validation_requires_pasted_response(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            self._make_repo(repo)
            result = self._run(repo, "create_ai_exchange_session.py", "--type", "new-project", "--title", "New", "--prompt-file", "ai-exchange/templates/general-consultation.md")
            self.assertEqual(result.returncode, 0)
            empty = self._run(repo, "validate_current_ai_exchange.py", "--require-response")
            self.assertNotEqual(empty.returncode, 0)
            (repo / "ai-exchange" / "current" / "response.md").write_text("# Internal AI response\n\nFinal specification\n", encoding="utf-8")
            valid = self._run(repo, "validate_current_ai_exchange.py", "--require-response")
            self.assertEqual(valid.returncode, 0, valid.stdout + valid.stderr)

    def test_upgrade_preserves_active_current_workspace(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp) / "target"
            target.mkdir()
            first = subprocess.run(
                [sys.executable, str(PACK_ROOT / "install.py"), str(target)],
                cwd=PACK_ROOT,
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(first.returncode, 0, first.stdout + first.stderr)
            response = target / "ai-exchange" / "current" / "response.md"
            response.write_text("# Internal AI response\n\nDO NOT OVERWRITE\n", encoding="utf-8")
            upgrade = subprocess.run(
                [sys.executable, str(PACK_ROOT / "install.py"), str(target), "--overwrite-managed"],
                cwd=PACK_ROOT,
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(upgrade.returncode, 0, upgrade.stdout + upgrade.stderr)
            self.assertIn("DO NOT OVERWRITE", response.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
