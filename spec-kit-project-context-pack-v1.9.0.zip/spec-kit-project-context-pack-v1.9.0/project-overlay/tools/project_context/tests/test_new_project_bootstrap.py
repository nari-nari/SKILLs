from __future__ import annotations

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]


class NewProjectBootstrapTests(unittest.TestCase):
    def test_bootstrap_templates_exist(self) -> None:
        required = [
            "docs/project-context/new-project-bootstrap.md",
            "docs/project-context/ai-exchange/templates/prompts/new-project-spec-intake.md",
            "docs/project-context/ai-exchange/templates/prompts/new-project-spec-revision.md",
            "docs/project-context/ai-exchange/templates/prompts/new-project-spec-approval.md",
            "docs/project-context/ai-exchange/templates/prompts/new-project-spec-example-nc.md",
            ".project-context/templates/internal-ai-new-project-intake.md",
        ]
        for relative in required:
            self.assertTrue((ROOT / relative).is_file(), relative)

    def test_intake_keeps_manual_input_small_and_uses_approval_gate(self) -> None:
        text = (
            ROOT
            / "docs/project-context/ai-exchange/templates/prompts/new-project-spec-intake.md"
        ).read_text(encoding="utf-8")
        for heading in ["### 作りたいもの", "### 分かっている制約", "### 最初に実現したいこと"]:
            self.assertIn(heading, text)
        self.assertIn("質問は一度に最大3件", text)
        self.assertIn("私が明示的に承認するまで", text)
        self.assertIn("/speckit.specify", text)
        self.assertIn("/speckit.plan", text)


if __name__ == "__main__":
    unittest.main()
