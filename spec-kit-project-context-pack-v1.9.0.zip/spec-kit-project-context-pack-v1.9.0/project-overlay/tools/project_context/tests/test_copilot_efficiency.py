from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
OVERLAY = Path(__file__).resolve().parents[3]


class CopilotEfficiencyTests(unittest.TestCase):
    def test_always_on_instructions_are_bounded(self) -> None:
        path = OVERLAY / ".github" / "copilot-instructions.md"
        self.assertLessEqual(len(path.read_text(encoding="utf-8").split()), 220)

    def test_user_guides_and_examples_exist(self) -> None:
        for relative in [
            "docs/project-context/START-HERE.md",
            "docs/project-context/prompt-examples.md",
            "docs/project-context/copilot-efficient-usage.md",
            "docs/project-context/request-intake-cheatsheet.md",
            ".project-context/request-intake-policy.toml",
            "tools/project_context/parse_request_intake.py",
            ".github/prompts/project-context-help.prompt.md",
        ]:
            self.assertTrue((OVERLAY / relative).is_file(), relative)
        examples = (OVERLAY / "docs/project-context/prompt-examples.md").read_text(encoding="utf-8")
        self.assertIn("/request-intake", examples)
        self.assertIn("/propose-roadmap-update", examples)
        self.assertIn("/assess-readme-update", examples)
        self.assertIn("/request-intake quick", examples)
        self.assertIn("/request-intake deep", examples)


    def test_request_intake_is_staged_and_bounded(self) -> None:
        agent = (OVERLAY / ".github" / "agents" / "request-intake.agent.md").read_text(encoding="utf-8")
        prompt = (OVERLAY / ".github" / "prompts" / "request-intake.prompt.md").read_text(encoding="utf-8")
        for term in ["Quick", "Standard", "Deep", "parse_request_intake.py", "`request.md`を作らない"]:
            self.assertIn(term, agent)
        self.assertIn("quick|standard|deep", prompt)
        self.assertIn("[feature|bug|research", prompt)

    def test_custom_agents_scope_tools(self) -> None:
        for path in sorted((OVERLAY / ".github" / "agents").glob("*.agent.md")):
            text = path.read_text(encoding="utf-8")
            header = text.split("---", 2)[1]
            self.assertIn("tools:", header, path.name)
            self.assertNotIn("web", header, path.name)
            self.assertNotIn("browser", header, path.name)

    def test_snapshot_generation_is_bounded_and_contains_state(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            for relative in [
                ".project-context/generated",
                "docs/project-context",
                "src",
                "tests",
            ]:
                (repo / relative).mkdir(parents=True, exist_ok=True)
            (repo / "README.md").write_text("# Demo\n\nA compact demo project.\n", encoding="utf-8")
            (repo / "docs/project-context/status.md").write_text(
                "# Project Status\n\nLast updated: 2026-08-07\nOverall state: In progress\n"
                "Current phase: PoC\nActive workstream/component: reader\nRelated Spec Kit feature: none\n\n"
                "## Current goal\n\nRead one file.\n\n## In progress\n\n- Parser\n\n"
                "## Blocked\n\n- None\n\n## Verification status\n\n- Unit tests passed\n\n"
                "## Known limitations\n\n- Synthetic only\n\n## Next actions\n\n1. GUI\n",
                encoding="utf-8",
            )
            (repo / "docs/project-context/roadmap.md").write_text(
                "# Project Roadmap\n\n## Milestones\n\n| Milestone | Outcome | Target/Order | Status | Exit criteria |\n"
                "|---|---|---|---|---|\n| M1 | Reader | 1 | In progress | Tests |\n\n"
                "## Workstream map\n\n| ID | Workstream/component | Management type | Purpose | Depends on | State | Primary location | Verification required | Source proposal |\n"
                "|---|---|---|---|---|---|---|---|---|\n| W001 | Reader | manual | Read | — | In progress | src | Unit | — |\n",
                encoding="utf-8",
            )
            (repo / "docs/project-context/project-map.md").write_text("# Project Map\n", encoding="utf-8")
            (repo / "docs/project-context/known-issues.md").write_text("# Known Issues\n", encoding="utf-8")
            (repo / ".project-context/components.toml").write_text(
                "[[components]]\nid='reader'\npaths=['src/**']\norigin='manual'\nlifecycle='active'\n",
                encoding="utf-8",
            )
            inventory = {
                "files": [
                    {"path": "src/main.py", "category": "source", "origin": "project"},
                    {"path": "tests/test_main.py", "category": "tests", "origin": "project"},
                ]
            }
            (repo / ".project-context/generated/project-inventory.json").write_text(
                json.dumps(inventory), encoding="utf-8"
            )
            (repo / ".project-context/context.toml").write_text(
                "[project]\nname='Demo'\nreadme_file='README.md'\nstatus_file='docs/project-context/status.md'\n"
                "roadmap_file='docs/project-context/roadmap.md'\nproject_map_file='docs/project-context/project-map.md'\n"
                "generated_inventory_json='.project-context/generated/project-inventory.json'\n"
                "component_registry='.project-context/components.toml'\n"
                "[copilot_context]\nsnapshot_file='.project-context/generated/copilot-snapshot.md'\n"
                "budget_report_json='.project-context/generated/copilot-context-budget.json'\n"
                "budget_report_markdown='.project-context/generated/copilot-context-budget.md'\n"
                "snapshot_max_chars=5000\nsection_max_chars=600\ndefault_max_relevant_files=8\n",
                encoding="utf-8",
            )
            result = subprocess.run(
                [sys.executable, str(TOOLS / "build_copilot_snapshot.py")],
                cwd=repo,
                env={**os.environ, "PYTHONPATH": str(TOOLS)},
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            snapshot = (repo / ".project-context/generated/copilot-snapshot.md").read_text(encoding="utf-8")
            self.assertLessEqual(len(snapshot), 5001)
            self.assertIn("Read one file", snapshot)
            self.assertIn("Reader", snapshot)
            self.assertIn("Default limit: 8", snapshot)
            budget = json.loads((repo / ".project-context/generated/copilot-context-budget.json").read_text(encoding="utf-8"))
            self.assertIn("always_on_instruction_words", budget)
            self.assertTrue(budget["always_on_within_budget"])


if __name__ == "__main__":
    unittest.main()
