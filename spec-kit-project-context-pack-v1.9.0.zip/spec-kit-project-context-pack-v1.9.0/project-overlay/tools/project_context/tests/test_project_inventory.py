from __future__ import annotations

import sys
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

from collect_project_inventory import classify, component_for  # noqa: E402


class InventoryTests(unittest.TestCase):
    def test_classifies_spec_and_source(self) -> None:
        cfg = {
            "source_globs": ["src/**"],
            "test_globs": ["tests/**"],
            "documentation_globs": ["docs/**", "README*"],
            "configuration_globs": ["*.toml"],
            "data_globs": ["data/**"],
        }
        self.assertEqual(classify("specs/001-x/spec.md", cfg), "spec-kit")
        self.assertEqual(classify("src/main.py", cfg), "source")
        self.assertEqual(classify("tests/test_main.py", cfg), "tests")

    def test_registry_can_mark_imported_component(self) -> None:
        components = [{"id": "copied", "paths": ["vendor-tool/**"], "origin": "imported"}]
        found = component_for("vendor-tool/core.py", components)
        self.assertIsNotNone(found)
        assert found is not None
        self.assertEqual(found["origin"], "imported")


if __name__ == "__main__":
    unittest.main()
