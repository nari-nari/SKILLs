from __future__ import annotations

import argparse

from ai_exchange_lib import exchange_paths, read_session
from project_context_lib import load_config

PLACEHOLDER = "<!-- Paste the final internal-AI response below this line. -->"


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the visible current internal-AI exchange")
    parser.add_argument("--require-response", action="store_true")
    args = parser.parse_args()
    config = load_config()
    current, _, _ = exchange_paths(config)
    findings: list[str] = []
    for name in ("README.md", "prompt.md", "response.md", "result.md", "session.toml"):
        if not (current / name).is_file():
            findings.append(f"missing current exchange file: ai-exchange/current/{name}")
    session = read_session(current / "session.toml")
    if args.require_response:
        if not session.get("id"):
            findings.append("no active session")
        response_path = current / "response.md"
        if response_path.is_file():
            response = response_path.read_text(encoding="utf-8", errors="replace")
            content = response.replace("# Internal AI response", "").replace(PLACEHOLDER, "").strip()
            if not content:
                findings.append("response.md does not contain an internal-AI response")
    if findings:
        print("CURRENT AI EXCHANGE VALIDATION FAILED")
        for finding in findings:
            print(f"- {finding}")
        return 1
    print("CURRENT AI EXCHANGE VALIDATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
