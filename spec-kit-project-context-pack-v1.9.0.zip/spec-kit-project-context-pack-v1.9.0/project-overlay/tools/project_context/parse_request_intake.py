from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError as exc:  # pragma: no cover
    raise RuntimeError("Python 3.11 or newer is required") from exc

from project_context_lib import load_config, resolve_inside


@dataclass(frozen=True)
class IntakeTriage:
    mode: str
    hint: str
    intent: str
    route: str
    request_required: bool
    ai_route_needed: bool
    reason: str
    suggested_command: str


def _load_policy() -> tuple[dict[str, Any], Path]:
    config = load_config()
    relative = config.requests.get("intake_policy_file", ".project-context/request-intake-policy.toml")
    path = resolve_inside(config.root, relative)
    with path.open("rb") as stream:
        return tomllib.load(stream), path


def _strip_mode(text: str, aliases: dict[str, str], default: str) -> tuple[str, str]:
    stripped = text.strip()
    if not stripped:
        return default, ""
    first, *rest = stripped.split(maxsplit=1)
    normalized = aliases.get(first.lower()) or aliases.get(first)
    if normalized:
        return normalized, rest[0].strip() if rest else ""
    return default, stripped


def _strip_hint(text: str, allowed: set[str]) -> tuple[str, str]:
    match = re.match(r"^\s*\[([A-Za-z0-9_-]+)\]\s*(.*)$", text, re.DOTALL)
    if not match:
        return "unknown", text.strip()
    hint = match.group(1).lower()
    if hint not in allowed:
        return "unknown", text.strip()
    return hint, match.group(2).strip()


def _contains(text: str, terms: tuple[str, ...]) -> bool:
    lowered = text.lower()
    return any(term.lower() in lowered for term in terms)


def triage(text: str, policy: dict[str, Any]) -> IntakeTriage:
    default_mode = str(policy.get("default_mode", "standard"))
    aliases = {str(key): str(value) for key, value in policy.get("mode_aliases", {}).items()}
    allowed = {str(value) for value in policy.get("allowed_hints", [])}
    mode, remainder = _strip_mode(text, aliases, default_mode)
    hint, intent = _strip_hint(remainder, allowed)

    readme_terms = ("readme", "README")
    defer_terms = ("延期", "後回し", "後続", "分離", "今回には複雑", "defer")
    discover_terms = ("実装後", "完了後", "将来候補", "今後必要", "ロードマップ候補", "feature-completed")
    refresh_terms = ("文脈を更新", "コンテキストを更新", "snapshot", "スナップショット", "refresh")
    technical_terms = ("パッケージ", "ライブラリ", "フレームワーク", "GUI", "技術選定", "dependency", "framework", "tkinter", "PySide")
    plan_terms = ("plan", "speckit.plan", "仕様後", "仕様ができ", "spec")

    if (hint == "docs" or _contains(intent, readme_terms)) and _contains(intent, readme_terms):
        return IntakeTriage(mode, hint, intent, "readme-assessment", False, False,
                            "README整合確認は専用コマンドで完結できるため。",
                            f"/assess-readme-update {intent}".strip())
    if hint == "roadmap" and _contains(intent, defer_terms):
        return IntakeTriage(mode, hint, intent, "roadmap-deferral", False, False,
                            "現在範囲からの延期は専用ロードマップ候補フローで扱えるため。",
                            f"/defer-feature-to-roadmap {intent}".strip())
    if hint == "roadmap" and _contains(intent, discover_terms):
        return IntakeTriage(mode, hint, intent, "roadmap-discovery", False, False,
                            "実装後の将来候補探索は専用コマンドで扱えるため。",
                            "/propose-roadmap-update feature-completed")
    if hint == "research" and _contains(intent, technical_terms) and _contains(intent, plan_terms):
        return IntakeTriage(mode, hint, intent, "pre-plan-intake", False, False,
                            "仕様後の技術選定は専用pre-plan承認フローで扱えるため。",
                            f"/pre-plan-intake {intent}".strip())
    if hint == "context" or _contains(intent, refresh_terms):
        return IntakeTriage(mode, hint, intent, "context-refresh", False, False,
                            "機械的な文脈更新は専用コマンドとPythonツールで完結できるため。",
                            "/refresh-project-context")

    if mode == "quick":
        return IntakeTriage(mode, hint, intent, "specialist-recommendation", False, True,
                            "Quickモードではrequest.mdを作らず、スナップショットだけで専門ルートを1つ選ぶため。",
                            "")
    if mode == "deep":
        return IntakeTriage(mode, hint, intent, "full-intake", True, False,
                            "Deepモードは横断調査と承認可能な依頼ブリーフを必須とするため。",
                            "")
    return IntakeTriage(mode, hint, intent, "full-intake", True, False,
                        "専用コマンドだけでは範囲・承認・下流ルートを確定できないため。",
                        "")


def main() -> int:
    parser = argparse.ArgumentParser(description="Parse /request-intake mode and hint without using AI")
    parser.add_argument("text", nargs="?", help="Text after /request-intake")
    parser.add_argument("--input", dest="input_text", help="Text after /request-intake")
    parser.add_argument("--json", action="store_true", help="Print compact JSON only")
    args = parser.parse_args()
    raw = args.input_text if args.input_text is not None else (args.text or "")
    policy, _ = _load_policy()
    result = triage(raw, policy)
    payload = asdict(result)
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
    else:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
