from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path
from typing import Any

from project_context_lib import load_config, relative_posix, resolve_inside, write_json
from readme_maintenance_lib import headings, load_readme_policy, normalize_heading, sha256_file


def file_state(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"exists": False, "sha256": None, "mtime_ns": None}
    return {"exists": True, "sha256": sha256_file(path), "mtime_ns": path.stat().st_mtime_ns}


def inventory_signature(path: Path) -> str | None:
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    rows = [(item.get("path"), item.get("sha256"), item.get("size"), item.get("origin")) for item in data.get("files", [])]
    import hashlib
    return hashlib.sha256(json.dumps(rows, sort_keys=True).encode("utf-8")).hexdigest()


def render(payload: dict[str, Any]) -> str:
    lines = [
        "# README Update Assessment",
        "",
        f"Generated: {payload['generated_on']}",
        f"README: `{payload['readme_file']}`",
        f"Assessment: **{payload['assessment']}**",
        "",
        "## Reasons",
        "",
    ]
    reasons = payload.get("reasons", [])
    lines += [f"- {item}" for item in reasons] if reasons else ["- No deterministic review trigger was detected."]
    lines += ["", "## Missing project-context links", ""]
    missing = payload.get("missing_context_links", [])
    lines += [f"- `{item}`" for item in missing] if missing else ["- None"]
    lines += ["", "## README headings", ""]
    lines += [f"- `{item}`" for item in payload.get("headings", [])] or ["- No Markdown headings found"]
    lines += [
        "",
        "## Next step",
        "",
        "Run `/assess-readme-update` for semantic review. If an update is justified, create a Draft proposal from `.project-context/templates/readme-update.toml`, review it, set `status = \"Approved\"`, and run `/update-project-readme`.",
        "",
        "> This report detects structural and recorded-context changes. It does not prove that README prose is accurate or complete.",
    ]
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Assess deterministic triggers for reviewing the project README")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    config = load_config()
    policy = load_readme_policy(config)
    settings = policy.readme
    readme = resolve_inside(config.root, settings.get("readme_file", config.project.get("readme_file", "README.md")))
    assessment_json = resolve_inside(config.root, settings.get("assessment_json", ".project-context/generated/readme-assessment.json"))
    previous: dict[str, Any] = {}
    if assessment_json.is_file():
        try:
            previous = json.loads(assessment_json.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            previous = {}
    status = resolve_inside(config.root, config.project.get("status_file", "docs/project-context/status.md"))
    roadmap = resolve_inside(config.root, config.project.get("roadmap_file", "docs/project-context/roadmap.md"))
    project_map = resolve_inside(config.root, config.project.get("project_map_file", "docs/project-context/project-map.md"))
    inventory = resolve_inside(config.root, config.project.get("generated_inventory_json", ".project-context/generated/project-inventory.json"))
    source_states = {name: file_state(path) for name, path in {"status": status, "roadmap": roadmap, "project_map": project_map}.items()}
    readme_text = readme.read_text(encoding="utf-8") if readme.is_file() else ""
    reasons: list[str] = []
    if not readme.is_file():
        reasons.append("The configured README file does not exist.")
    if not previous:
        reasons.append("This is the first README assessment for the repository.")
    previous_sources = previous.get("source_states", {})
    for name, state in source_states.items():
        if previous_sources and previous_sources.get(name, {}).get("sha256") != state.get("sha256"):
            reasons.append(f"The project-context source `{name}` changed since the previous assessment.")
    current_inventory = inventory_signature(inventory)
    if previous and previous.get("inventory_signature") != current_inventory:
        reasons.append("The project file inventory changed since the previous assessment.")
    expected_links = [str(x) for x in settings.get("expected_context_links", [])]
    missing_links = [link for link in expected_links if link not in readme_text]
    if missing_links:
        reasons.append("One or more expected project-context links are missing from README.md.")
    payload = {
        "generated_on": date.today().isoformat(),
        "assessment": "Review recommended" if reasons else "No deterministic trigger detected",
        "readme_file": relative_posix(config.root, readme),
        "readme_state": file_state(readme),
        "source_states": source_states,
        "inventory_signature": current_inventory,
        "missing_context_links": missing_links,
        "headings": [title for _level, title, _start, _end in headings(readme_text)],
        "managed_sections": settings.get("managed_sections", []),
        "protected_sections": settings.get("protected_sections", []),
        "update_triggers": settings.get("update_triggers", []),
        "reasons": reasons,
    }
    write_json(assessment_json, payload)
    markdown = resolve_inside(config.root, settings.get("assessment_markdown", ".project-context/generated/readme-assessment.md"))
    markdown.parent.mkdir(parents=True, exist_ok=True)
    markdown.write_text(render(payload), encoding="utf-8")
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(payload["assessment"])
        print(f"Wrote {relative_posix(config.root, assessment_json)}")
        print(f"Wrote {relative_posix(config.root, markdown)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
