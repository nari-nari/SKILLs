from __future__ import annotations

import hashlib
import json
import re
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from project_context_lib import PackConfig, resolve_inside


@dataclass(frozen=True)
class RoadmapPolicy:
    path: Path
    data: dict[str, Any]

    @property
    def roadmap(self) -> dict[str, Any]:
        return self.data.get("roadmap", {})

    @property
    def promotion(self) -> dict[str, Any]:
        return self.roadmap.get("promotion", {})


def load_roadmap_policy(config: PackConfig) -> RoadmapPolicy:
    path = resolve_inside(config.root, ".project-context/roadmap-policy.toml")
    with path.open("rb") as stream:
        return RoadmapPolicy(path, tomllib.load(stream))


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def next_numbered_id(root: Path, prefix: str, suffix: str = ".toml") -> str:
    highest = 0
    pattern = re.compile(rf"^{re.escape(prefix)}-(\d+){re.escape(suffix)}$")
    if root.is_dir():
        for item in root.iterdir():
            if not item.is_file():
                continue
            match = pattern.fullmatch(item.name)
            if match:
                highest = max(highest, int(match.group(1)))
    return f"{prefix}-{highest + 1:04d}"


def load_proposal(path: Path) -> dict[str, Any]:
    with path.open("rb") as stream:
        return tomllib.load(stream)


def _require_string(data: dict[str, Any], key: str, findings: list[str]) -> str:
    value = data.get(key, "")
    if not isinstance(value, str) or not value.strip():
        findings.append(f"{key} must be a non-empty string")
        return ""
    return value.strip()


def _list_of_strings(data: dict[str, Any], key: str, findings: list[str]) -> list[str]:
    value = data.get(key, [])
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        findings.append(f"{key} must be an array of strings")
        return []
    return [item.strip() for item in value if item.strip()]


def validate_proposal(
    data: dict[str, Any],
    policy: RoadmapPolicy,
    *,
    require_approved: bool = False,
    current_roadmap: Path | None = None,
) -> list[str]:
    findings: list[str] = []
    roadmap = policy.roadmap
    prefix = str(roadmap.get("id_prefix", "RM"))
    proposal_id = _require_string(data, "id", findings)
    if proposal_id and not re.fullmatch(rf"{re.escape(prefix)}-\d{{4,}}", proposal_id):
        findings.append(f"id must match {prefix}-NNNN")
    _require_string(data, "title", findings)
    proposal_type = _require_string(data, "proposal_type", findings)
    _require_string(data, "created_at", findings)
    _require_string(data, "created_by", findings)
    _require_string(data, "roadmap_sha256", findings)
    _require_string(data, "reason", findings)
    _require_string(data, "user_value", findings)

    source_refs = _list_of_strings(data, "source_refs", findings)
    evidence = _list_of_strings(data, "evidence", findings)
    _list_of_strings(data, "out_of_scope", findings)
    _list_of_strings(data, "dependencies", findings)
    verification = _list_of_strings(data, "verification_required", findings)

    allowed_map = {
        "proposal_type": "allowed_proposal_types",
        "status": "allowed_statuses",
        "confidence": "allowed_confidence",
        "estimated_complexity": "allowed_complexity",
        "priority": "allowed_priorities",
        "management_type": "allowed_management_types",
        "route": "allowed_routes",
    }
    for key, policy_key in allowed_map.items():
        value = str(data.get(key, ""))
        allowed = {str(item) for item in roadmap.get(policy_key, [])}
        if value not in allowed:
            findings.append(f"{key} must be one of: {', '.join(sorted(allowed))}")

    if not source_refs and not evidence:
        findings.append("at least one source_refs or evidence item is required")
    if (
        proposal_type == "predicted-feature"
        and bool(roadmap.get("require_evidence_for_predicted", True))
        and not evidence
    ):
        findings.append("predicted-feature requires at least one evidence item")

    if require_approved:
        if str(data.get("status", "")) != "Approved":
            findings.append("status must be Approved")
        _require_string(data, "approved_by", findings)
        _require_string(data, "approved_at", findings)
        if str(data.get("management_type", "Undecided")) == "Undecided":
            findings.append("management_type must be decided before promotion")
        route = str(data.get("route", "Undecided"))
        if route == "Undecided":
            findings.append("route must be decided before promotion")
        if bool(policy.promotion.get("require_verification", True)) and not verification:
            findings.append("verification_required must contain at least one item")
        management_type = str(data.get("management_type", "Undecided"))
        if route.startswith("speckit-") and management_type != "Spec Kit":
            findings.append("Spec Kit routes require management_type = 'Spec Kit'")
        if route == "manual-workstream" and management_type == "Spec Kit":
            findings.append("manual-workstream cannot use management_type = 'Spec Kit'")
        if current_roadmap is not None and bool(policy.promotion.get("require_current_roadmap_hash", True)):
            expected = str(data.get("roadmap_sha256", ""))
            actual = sha256_file(current_roadmap)
            if expected != actual:
                findings.append("roadmap changed after proposal creation/review; refresh the proposal hash and re-review")
    return findings


def toml_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def toml_array(values: list[str]) -> str:
    return json.dumps(values, ensure_ascii=False)


def render_proposal(data: dict[str, Any]) -> str:
    scalar_order = [
        "id", "title", "status", "proposal_type", "created_at", "created_by", "roadmap_sha256",
        "reason", "user_value", "scope_summary", "risk_if_ignored",
    ]
    list_order = ["source_refs", "evidence", "out_of_scope", "dependencies", "verification_required"]
    decision_order = [
        "confidence", "estimated_complexity", "priority", "target_milestone", "management_type",
        "route", "primary_location", "approved_by", "approved_at", "review_notes",
    ]
    lines: list[str] = []
    for key in scalar_order:
        lines.append(f"{key} = {toml_string(str(data.get(key, '')))}")
        if key in {"roadmap_sha256", "risk_if_ignored"}:
            lines.append("")
    for key in list_order:
        values = [str(item) for item in data.get(key, [])]
        lines.append(f"{key} = {toml_array(values)}")
    lines.append("")
    for key in decision_order:
        lines.append(f"{key} = {toml_string(str(data.get(key, '')))}")
    return "\n".join(lines).rstrip() + "\n"


def mark_promoted(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    updated, count = re.subn(r'(?m)^status\s*=\s*"Approved"\s*$', 'status = "Promoted"', text, count=1)
    if count != 1:
        raise ValueError("could not update proposal status from Approved to Promoted")
    path.write_text(updated, encoding="utf-8")


def escape_markdown_cell(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip()).replace("|", "\\|") or "—"


def next_workstream_id(roadmap_text: str, prefix: str = "W") -> str:
    numbers = [int(match.group(1)) for match in re.finditer(rf"\b{re.escape(prefix)}(\d+)\b", roadmap_text)]
    return f"{prefix}{max(numbers, default=0) + 1:03d}"


def insert_before_marker(text: str, marker: str, line: str) -> str:
    if marker not in text:
        raise ValueError(f"roadmap marker not found: {marker}")
    before, after = text.split(marker, 1)
    separator = "" if before.endswith("\n") else "\n"
    return f"{before}{separator}{line.rstrip()}\n{marker}{after}"
