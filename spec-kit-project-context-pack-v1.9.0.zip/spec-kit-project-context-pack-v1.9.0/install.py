from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

START = "<!-- PROJECT-CONTEXT-PACK:START -->"
END = "<!-- PROJECT-CONTEXT-PACK:END -->"


def merge_marked(target: Path, content: str) -> str:
    block = f"{START}\n{content.strip()}\n{END}\n"
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(block, encoding="utf-8")
        return "created"
    text = target.read_text(encoding="utf-8")
    if START in text and END in text:
        before, rest = text.split(START, 1)
        _, after = rest.split(END, 1)
        target.write_text(f"{before}{block}{after.lstrip()}", encoding="utf-8")
        return "updated-section"
    sep = "\n" if text.endswith("\n") else "\n\n"
    target.write_text(text + sep + block, encoding="utf-8")
    return "appended-section"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Install project-context overlay with visible internal-AI exchange workspace")
    parser.add_argument("target", type=Path)
    parser.add_argument("--overwrite-managed", action="store_true", help="Replace files previously installed by this pack")
    args = parser.parse_args()
    source = Path(__file__).resolve().parent / "project-overlay"
    target = args.target.resolve()
    target.mkdir(parents=True, exist_ok=True)
    manifest_path = target / ".project-context" / "install-manifest.json"
    previous = {}
    if manifest_path.is_file():
        previous = json.loads(manifest_path.read_text(encoding="utf-8"))
    previously_managed = {item["path"] for item in previous.get("files", [])}
    report = []
    runtime_preserve_prefixes = ("ai-exchange/current/",)
    snippet = source / ".github" / "copilot-instructions.md"
    for item in sorted(source.rglob("*")):
        if (
            not item.is_file()
            or item == snippet
            or item.name == ".gitignore"
            or "__pycache__" in item.parts
            or item.suffix == ".pyc"
        ):
            continue
        rel = item.relative_to(source)
        dest = target / rel
        action = "copied"
        rel_text = rel.as_posix()
        preserve_runtime = any(rel_text.startswith(prefix) for prefix in runtime_preserve_prefixes)
        if dest.exists() and (preserve_runtime or not (args.overwrite_managed and rel_text in previously_managed)):
            action = "preserved-runtime" if preserve_runtime else "skipped-existing"
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, dest)
        report.append({"path": rel.as_posix(), "action": action, "sha256": sha(item)})
    action = merge_marked(target / ".github" / "copilot-instructions.md", snippet.read_text(encoding="utf-8"))
    report.append({"path": ".github/copilot-instructions.md", "action": action, "sha256": sha(snippet)})
    gitignore = source / ".gitignore"
    action = merge_marked(target / ".gitignore", gitignore.read_text(encoding="utf-8"))
    report.append({"path": ".gitignore", "action": action, "sha256": sha(gitignore)})
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest = {"version": "1.9.0", "installed_at": datetime.now(timezone.utc).isoformat(), "files": report}
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Installed project-context support into {target}")
    print(f"Manifest: {manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
