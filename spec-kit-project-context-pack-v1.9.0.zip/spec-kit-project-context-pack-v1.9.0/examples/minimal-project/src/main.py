print("example")
