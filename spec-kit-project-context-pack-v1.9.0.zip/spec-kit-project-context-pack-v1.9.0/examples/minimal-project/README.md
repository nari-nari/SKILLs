# Example target project

This README belongs to the developed tool, not to the context pack.
