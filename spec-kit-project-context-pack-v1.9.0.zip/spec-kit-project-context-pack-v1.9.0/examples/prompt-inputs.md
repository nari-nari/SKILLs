# Prompt Input Examples

## Existing project: add a feature

```text
/request-intake 同じ.ncファイルを再度開いたとき、前回の解析範囲を復元したい
```

## Ask internal AI about technology

```text
/request-intake Python未導入のWindows PCへの配布方式を社内AIに比較してもらいたい
```

## Defer a complex feature

```text
/defer-feature-to-roadmap specs/001-analysis/spec.md 自動位置合わせを後続機能へ分離したい
```

## Find evidence-backed future work

```text
/propose-roadmap-update feature-completed
```

## Review README consistency

```text
/assess-readme-update 起動方法と設定保存機能が変わった
```

The installed project contains a larger Japanese cookbook at `docs/project-context/prompt-examples.md`.


## Staged request intake

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
/request-intake [bug] CSVの保存範囲がグラフ表示と一致しない
/request-intake deep [refactor] packages配下の2パッケージを統合したい
```


## Pre-plan technology selection

```text
/pre-plan-intake specs/001-single-file-analysis GUIはPySide6を候補に、tkinterを含め要求適合性で比較したい
```

```text
/prepare-speckit-plan-input specs/001-single-file-analysis .context-work/pre-plan/TP-0001/decision.md
```

## Visible internal-AI exchange

Start a new-project intake:

```text
/start-new-project-ai-intake
```

For any consultation, use these files after the prompt is prepared:

```text
ai-exchange/current/prompt.md
ai-exchange/current/response.md
```

Then import the final answer:

```text
/import-current-internal-ai-response
```
