# GitHub Copilot Credit-Saving Prompt Files

Spec Kitを使用しない開発フロー向けの、GitHub Copilot Prompt files一式です。

Prompt filesは`.github/prompts`に配置し、VS CodeのCopilot Chatで`/prompt-name`として呼び出せます。Prompt filesは現在Public Previewであり、仕様が変更される可能性があります。

## 導入

このZIPの内容を、リポジトリのルートへ展開してください。

```text
<repository-root>/
├── .github/
│   └── prompts/
└── docs/
    ├── current/
    └── copilot-workflow/
```

VS Codeで認識されない場合:

1. Copilot Chatで`/prompts`を入力する。
2. `Chat: Configure Prompt Files`または`Chat: Open Customizations`を実行する。
3. Agent Debug Logで検出エラーを確認する。

## モデル選択

モデル名は契約・組織設定・更新で変わるため、frontmatterでは固定していません。

- 軽量モデル: 文書整形、Plan展開、計画済み実装、定型レビュー
- 高性能モデル: `technical-decisions`、`package-research`、難しい`diagnose-and-fix`

各prompt実行前にモデルピッカーで選択してください。

## 推奨ワークフロー

| 順番 | Slash command | 推奨モデル | 目的 |
|---:|---|---|---|
| 1 | `/create-feature-brief` | 軽量 | 社内AIの要求整理結果を保存 |
| 2 | `/apply-feature-review` | 軽量 | 要求レビューを最小差分で反映 |
| 3 | `/technical-decisions` | 高性能 | リポジトリ調査と方式決定 |
| 4 | `/package-research` | 高性能 | 必要時のみ外部パッケージ比較 |
| 5 | `/create-implementation-plan` | 軽量 | Planモードで計画を作成 |
| 6 | `/persist-plan-and-implement-batch` | 軽量 | Plan保存と最初の実装 |
| 7 | `/implement-batch` | 軽量 | 2〜4 Stepずつ実装 |
| 8 | `/diagnose-and-fix` | 中〜高性能 | 原因不明時のみ使用 |
| 9 | `/review-implementation` | 中位または軽量 | 差分レビューを保存 |
| 10 | `/fix-review-findings` | 軽量 | 承認した指摘だけ修正 |
| 11 | `/update-handoff` | 軽量 | セッション引き継ぎ作成 |
| 12 | `/resume-from-handoff` | 軽量 | 新セッションで作業再開 |

## 社内AIチャット

社内AI用のコピー可能なテンプレートは次にあります。

```text
docs/copilot-workflow/INTERNAL_AI_PROMPTS.md
```

## クレジット節約の運用ルール

- 高性能モデルには長いPlanや実装コードを生成させず、重要な判断だけを担当させる。
- 調査対象と変更可能範囲を毎回指定する。
- 詳細はMarkdownへ書き、チャット上の完了報告を短くする。
- 計画済み実装は2〜4 Stepずつ行う。
- 同じ原因で2回失敗したら、軽量モデルの再試行を止める。
- 長い会話を継続せず、`handoff.md`を使って新セッションへ移る。
- 小さな手動修正は、可能なら課金対象外のコード補完やNext Edit Suggestionsを利用する。

## 注意

- Agentは変更可能範囲の指示に常に完全準拠するとは限りません。適用前にdiffを確認してください。
- Web検索の利用可否はCopilotポリシーと組織設定に依存します。
- Planモードで生成した計画は、最初の実装前に必ず人間が確認してください。
