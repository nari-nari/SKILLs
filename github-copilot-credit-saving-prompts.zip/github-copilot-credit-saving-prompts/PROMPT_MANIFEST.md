# Prompt Manifest

- `create-feature-brief.prompt.md`
- `apply-feature-review.prompt.md`
- `technical-decisions.prompt.md`
- `package-research.prompt.md`
- `create-implementation-plan.prompt.md`
- `persist-plan-and-implement-batch.prompt.md`
- `implement-batch.prompt.md`
- `diagnose-and-fix.prompt.md`
- `review-implementation.prompt.md`
- `fix-review-findings.prompt.md`
- `update-handoff.prompt.md`
- `resume-from-handoff.prompt.md`
