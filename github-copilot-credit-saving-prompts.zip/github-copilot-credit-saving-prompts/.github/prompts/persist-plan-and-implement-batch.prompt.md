---
name: persist-plan-and-implement-batch
description: 承認済みPlanを永続化し最初の実装バッチを実行する
argument-hint: "実装するStep範囲と変更可能範囲を入力"
agent: 'agent'
---

現在のチャットで直前に承認されたPlanを、内容を変更せず`docs/current/implementation-plan.md`へ保存してください。

承認済みPlanが現在のチャットコンテキストに存在しない場合は、実装を開始せず停止してください。

その後、指定された最初の実装バッチだけを実装してください。

## 実装するステップ

${input:steps:例: Step 1〜3}

## 変更可能範囲

${input:editableScope:変更してよいソース・テストの範囲を列挙してください}

次の文書を参照してください。

- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)
- 作成する`docs/current/implementation-plan.md`

## 追加で変更可能

- `docs/current/implementation-plan.md`
- `docs/current/implementation-log.md`

## 変更禁止

- 計画外のファイル
- 公開API（計画で明示されていない限り）
- 新規依存
- 無関係なリファクタリング
- フォーマットだけの大規模変更
- 既存テストの削除・弱体化
- 次の実装バッチへの着手

## 実装ルール

1. Planの順番に実装する。
2. 各ステップ後に対象テストを実行する。
3. 最後に関連する回帰テストを実行する。
4. テスト失敗を無効化や期待値変更で隠さない。
5. 計画との矛盾があれば独自判断せず停止する。
6. 型や解析結果を推測で確定しない。
7. 同じ原因に対する修正を2回試して解決しなければ停止する。
8. 計画外の機能を追加しない。

## implementation-log.mdへの記録

- 実装したステップ
- 変更したファイル
- 主な変更内容
- 実行したテスト
- テスト結果
- Planからの差異
- 残った問題
- 次に実装可能なステップ

詳細はファイルへ記録し、チャットでは結果を簡潔に報告してください。
