---
name: implement-batch
description: 承認済みimplementation-plan.mdの指定バッチだけを実装する
argument-hint: "実装するStep範囲と変更可能範囲を入力"
agent: 'agent'
---

承認済みの実装計画に従い、指定されたステップだけを実装してください。

## 参照資料

- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)
- [Implementation Plan](../../docs/current/implementation-plan.md)
- [Implementation Log](../../docs/current/implementation-log.md)（存在する場合）

## 実装するステップ

${input:steps:例: Step 4〜6}

## 変更可能範囲

${input:editableScope:変更してよいソース・テストの範囲を列挙してください}

## 追加で変更可能

- `docs/current/implementation-log.md`

## 変更禁止

- 計画外のファイル
- 公開API（計画で明示されていない限り）
- 新規依存
- 無関係なリファクタリング
- フォーマットだけの大規模変更
- 既存テストの削除・弱体化
- 指定外のステップ

## 実装ルール

1. Planの順番に実装する。
2. 各ステップ後に対象テストを実行する。
3. 最後に関連する回帰テストを実行する。
4. テスト失敗を無効化や期待値変更で隠さない。
5. 計画との矛盾があれば独自判断せず停止する。
6. 型や意味を推測で確定しない。
7. 同じ原因に対する修正を2回試して解決しなければ停止する。
8. 実装範囲を勝手に拡張しない。

## 停止条件

次の場合は追加修正を行わず停止してください。

- 計画外のAPI変更が必要
- 計画外の新規依存が必要
- 原因不明の回帰が発生
- 複数の技術方式から選択が必要
- 関連ファイルの特定からやり直す必要がある
- 要求、技術判断、Planに矛盾がある
- 入力から型や意味を一意に決定できない
- 自動処理の安全性を保証できない

停止時は、停止ステップ、確認済み事実、未確認の推測、必要な判断、再現コマンドを`implementation-log.md`へ記録してください。

チャットでは、完了したステップ、テスト結果、停止有無だけを簡潔に報告してください。
