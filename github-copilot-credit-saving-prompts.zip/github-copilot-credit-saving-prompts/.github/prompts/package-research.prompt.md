---
name: package-research
description: 候補パッケージを公式情報とリポジトリ適合性から比較し技術判断へ反映する
argument-hint: "技術課題、候補パッケージ、調査範囲を入力"
agent: 'agent'
---

外部パッケージの採否を調査し、結果を`docs/current/technical-decisions.md`へ最小差分で反映してください。

## 技術課題

${input:technicalProblem:解決したい技術課題を入力してください}

## 比較候補

${input:candidates:候補パッケージと既存実装案を列挙してください}

## リポジトリ調査対象

${input:researchScope:参照してよいファイル・ディレクトリを列挙してください}

## 必須参照

- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)（存在する場合）
- プロジェクトの依存関係・ビルド設定ファイル

## 変更可能

- `docs/current/technical-decisions.md`

## 変更禁止

- ソースコード
- テストコード
- 設定ファイル
- 依存関係
- その他のファイル

## 評価基準

- 必要機能への対応
- 対象言語・ランタイムへの対応
- 既存コードへの導入負荷
- APIの安定性
- ライセンス
- 公式リリースの新しさとメンテナンス状況
- オフライン導入のしやすさ
- 既存依存との競合
- 不完全な入力への耐性
- テスト容易性
- 採用前に必要な技術スパイク

## 外部調査

- Web検索が利用できる場合は、公式ドキュメント、公式GitHubリポジトリ、公式リリースノート、原著論文など一次情報を優先する。
- 出典と確認日を記録する。
- Web上の評判だけで採用を決めない。
- 候補を必要以上に増やさない。

## 出力

`technical-decisions.md`に、次を含む専用Decisionを追加または更新してください。

- Decision
- Candidate Comparison
- Rationale
- Alternatives Rejected or Deferred
- Required Technical Spike
- Fallback
- Safety Stop Conditions
- Sources Checked

## 制約

- 実装や依存追加は行わない。
- 未検証の候補を採用確定としない。
- 同じ調査を繰り返さない。
- チャットでは推奨候補、確信度、技術スパイク要否だけを報告する。
