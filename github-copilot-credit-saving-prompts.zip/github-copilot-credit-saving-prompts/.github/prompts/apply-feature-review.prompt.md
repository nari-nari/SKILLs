---
name: apply-feature-review
description: 社内AI等のレビュー指摘をfeature-brief.mdへ最小差分で反映する
argument-hint: "レビュー指摘を入力"
agent: 'agent'
---

[Feature Brief](../../docs/current/feature-brief.md)だけを最小差分で編集してください。

## レビュー指摘

${input:reviewFindings:反映するレビュー指摘を貼り付けてください}

## 変更可能

- `docs/current/feature-brief.md`

## 変更禁止

- その他のファイル
- ソースコード
- テストコード
- 設定ファイル

## 制約

- 指摘された内容だけを反映する。
- 指摘されていない節を全面的に書き換えない。
- 新しい要求を独自に追加しない。
- 意味が確定しない事項は推測せず、`Open Questions`へ追加する。
- 見出し構成は必要がない限り変更しない。
- リポジトリ調査やコマンド実行を行わない。
- チャットでは、更新した節と未解決事項の件数だけを簡潔に報告する。
