---
name: fix-review-findings
description: review.mdの承認済み指摘だけを最小差分で修正する
argument-hint: "修正するBlocker/Major項目と変更可能範囲を入力"
agent: 'agent'
---

[Implementation Review](../../docs/current/review.md)のうち、ユーザーが指定した指摘だけを修正してください。

## 修正対象

${input:findings:修正するBlockerまたはMajor項目を指定してください}

## 変更可能範囲

${input:editableScope:変更してよいファイル・ディレクトリを列挙してください}

## 参照資料

- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)
- [Implementation Plan](../../docs/current/implementation-plan.md)
- [Implementation Log](../../docs/current/implementation-log.md)
- [Implementation Review](../../docs/current/review.md)

## 追加で変更可能

- `docs/current/implementation-log.md`

## 制約

- 指定されていない指摘には対応しない。
- 技術判断やPlanを独自に変更しない。
- 新規依存を追加しない。
- 無関係なリファクタリングを行わない。
- テストを削除・弱体化しない。
- 各修正後に対象テストを実行し、最後に関連回帰テストを実行する。
- 同じ原因で2回失敗した場合は停止する。

修正内容とテスト結果を`implementation-log.md`へ追記してください。
チャットでは、修正済み項目、テスト結果、未解決項目だけを報告してください。
