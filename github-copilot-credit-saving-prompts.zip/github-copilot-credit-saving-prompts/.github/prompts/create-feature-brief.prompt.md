---
name: create-feature-brief
description: 社内AI等で整理した要求をfeature-brief.mdとして保存・整形する
argument-hint: "社内AIの出力または要求素材を入力"
agent: 'agent'
---

`docs/current/feature-brief.md`だけを作成または編集してください。

## 入力

${input:featureBriefSource:社内AIの出力または要求素材を貼り付けてください}

## 変更可能

- `docs/current/feature-brief.md`

## 変更禁止

- ソースコード
- テストコード
- 設定ファイル
- その他のMarkdownファイル

## 作業内容

入力を次の構成のMarkdownへ整理してください。

```markdown
# Feature Brief

## 1. Background
## 2. Objective
## 3. Intended Use
## 4. Scope
## 5. Out of Scope
## 6. Functional Requirements
## 7. Safety and Reliability Requirements
## 8. Normal Cases
## 9. Error and Boundary Cases
## 10. Acceptance Criteria
## 11. Human Approval Points
## 12. Open Questions
```

## 制約

- 内容を勝手に追加しない。
- 技術方式や使用パッケージを決定しない。
- 実装コードを生成しない。
- 不明な事項は推測せず、`Open Questions`へ残す。
- 受入条件は可能な限りテスト可能な表現にする。
- 重複だけを必要最小限に統合する。
- リポジトリ全体を調査しない。
- コマンドを実行しない。
- 詳細はファイルへ保存し、チャットでは変更したファイル名だけを報告する。
