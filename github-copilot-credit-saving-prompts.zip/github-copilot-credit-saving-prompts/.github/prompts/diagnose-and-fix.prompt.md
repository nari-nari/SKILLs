---
name: diagnose-and-fix
description: 原因不明の不具合を調査し原因確認後のみ最小差分で修正する
argument-hint: "期待挙動、実際の挙動、再現手順、変更可能範囲を入力"
agent: 'agent'
---

不具合を調査してください。原因を十分に確認する前にソースコードを変更しないでください。

## 参照資料

- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)
- [Implementation Plan](../../docs/current/implementation-plan.md)
- [Implementation Log](../../docs/current/implementation-log.md)

## 問題情報

${input:problemReport:期待する挙動、実際の挙動、再現手順、エラー、既に試したことを入力してください}

## 関連範囲

${input:researchScope:参照してよいソース・テストを列挙してください}

## 修正可能範囲

${input:editableScope:原因特定後に変更してよいファイルを列挙してください}

## 第1段階: 読み取り調査

1. 確認できた事実
2. 原因候補（最大5件）
3. 各候補を確認する最小テスト
4. 最も可能性が高い原因
5. `technical-decisions.md`またはPlan変更の要否

## 第2段階: 条件付き修正

原因が十分に特定でき、既存の技術判断とPlan内で修正できる場合だけ、最小差分で修正してください。

## 変更可能

- ユーザー指定の修正可能範囲
- `docs/current/implementation-log.md`

## 変更禁止

- 無関係なファイル
- 新規依存
- 公開API（承認済みでない限り）
- 大規模なリファクタリング
- `technical-decisions.md`の独自変更
- `implementation-plan.md`の独自変更

設計判断またはPlan変更が必要な場合は、コードを変更せず停止してください。

`implementation-log.md`へ、根本原因、根拠、修正内容、実行テスト、回帰リスク、計画変更要否を記録してください。

チャットでは、根本原因、修正有無、テスト結果だけを簡潔に報告してください。
