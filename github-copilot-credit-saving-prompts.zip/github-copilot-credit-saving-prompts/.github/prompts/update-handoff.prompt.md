---
name: update-handoff
description: 現在の実装状態から次セッション用handoff.mdを更新する
argument-hint: "次に承認されたStepや特記事項を入力"
agent: 'agent'
---

現在のリポジトリ状態と開発文書を確認し、`docs/current/handoff.md`だけを作成または更新してください。

## 参照資料

- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)
- [Implementation Plan](../../docs/current/implementation-plan.md)
- [Implementation Log](../../docs/current/implementation-log.md)
- [Implementation Review](../../docs/current/review.md)（存在する場合）
- 現在のgit diffまたはgit status

## 追加情報

${input:handoffNotes:次に承認されたStep、既知の注意点などを入力してください}

## 変更可能

- `docs/current/handoff.md`

## 変更禁止

- ソースコード
- テストコード
- その他の文書
- 設定ファイル

## handoff.mdの構成

```markdown
# Development Handoff

## Current Objective
## Completed Steps
## Current Implementation State
## Confirmed Technical Decisions
## Files Changed
## Tests Executed
## Known Failures
## Remaining Risks
## Next Approved Step
## Files Needed for the Next Step
## Files That Should Not Be Inspected
## Stop Conditions
## Important Constraints
```

## 制約

- 未実施の作業を完了済みとしない。
- `implementation-log.md`と実際の変更状態を照合する。
- 過去の長い経緯を繰り返さない。
- 次のセッションに必要な情報だけを残す。
- 1000語以内を目安とする。
- チャットでは次の承認済みStepと既知のFailure件数だけを報告する。
