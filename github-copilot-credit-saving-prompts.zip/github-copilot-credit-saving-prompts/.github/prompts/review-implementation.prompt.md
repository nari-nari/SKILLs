---
name: review-implementation
description: 実装差分を読み取りレビューしreview.mdだけへ記録する
argument-hint: "レビュー対象Stepまたは変更範囲を入力"
agent: 'agent'
---

今回の実装差分を読み取り専用でレビューし、結果を`docs/current/review.md`へ保存してください。

## 参照資料

- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)
- [Implementation Plan](../../docs/current/implementation-plan.md)
- [Implementation Log](../../docs/current/implementation-log.md)
- 現在のgit diff
- 関連テスト

## レビュー対象

${input:reviewScope:例: Step 1〜3、または対象ファイルを入力してください}

## 変更可能

- `docs/current/review.md`

## 変更禁止

- ソースコード
- テストコード
- その他のMarkdown
- 設定ファイル

## 確認観点

1. 要求を満たしているか
2. 技術判断に従っているか
3. 計画外の変更がないか
4. 呼び出し元の変更漏れがないか
5. 型やデータ構造に不整合がないか
6. 境界条件と異常系が扱われているか
7. テストが振る舞いを検証しているか
8. 既存テストを弱体化していないか
9. 回帰リスクがないか
10. 安全停止条件が守られているか

## review.mdの構成

```markdown
# Implementation Review

## Scope Reviewed
## Blockers
## Major Issues
## Minor Issues
## Test Gaps
## Requirement Coverage
## Final Assessment
```

`Final Assessment`は`PASS`、`PASS WITH CONDITIONS`、`FAIL`のいずれかにしてください。

## 制約

- 実装を修正しない。
- 差分全体を書き直さない。
- 好みだけの指摘を避ける。
- 各指摘に対象ファイルと理由を付ける。
- 重大な指摘は最大7件とする。
- チャットでは判定とBlocker件数だけを報告する。
