---
name: resume-from-handoff
description: handoff.mdを基に再調査を抑えて次の承認済みStepを再開する
argument-hint: "今回実装するStepと変更可能範囲を入力"
agent: 'agent'
---

以下の文書を前提に作業を再開してください。

- [Development Handoff](../../docs/current/handoff.md)
- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)
- [Implementation Plan](../../docs/current/implementation-plan.md)
- [Implementation Log](../../docs/current/implementation-log.md)（存在する場合）

## 今回の実装対象

${input:steps:Next Approved Stepと一致するStepを入力してください}

## 変更可能範囲

${input:editableScope:変更してよいファイル・ディレクトリを列挙してください}

## 最初に確認すること

- `Next Approved Step`
- そのStepに必要なファイル
- 現在のテスト状態
- `Stop Conditions`

過去の経緯をリポジトリ全体から再調査しないでください。

不整合がある場合は、実装を開始せず報告してください。

不整合がなく、指定Stepが承認済みなら、`implement-batch`と同じ規則で実装し、`implementation-log.md`へ結果を追記してください。

## 制約

- 指定外のStepへ進まない。
- 計画外のファイルを変更しない。
- 新規依存を独自に追加しない。
- 技術判断やPlanを独自に変更しない。
- 同じ原因で2回失敗した場合は停止する。
- チャットでは再開可否、完了Step、テスト結果だけを簡潔に報告する。
