---
name: create-implementation-plan
description: 確定済みの要求と技術判断から実装計画を作成する
argument-hint: "今回計画する範囲と参照可能範囲を入力"
agent: 'plan'
---

以下の資料に基づき、実装計画を作成してください。

- [Feature Brief](../../docs/current/feature-brief.md)
- [Technical Decisions](../../docs/current/technical-decisions.md)

## 今回の計画対象

${input:planningScope:今回計画する機能・段階を入力してください}

## 追加で参照可能な範囲

${input:repositoryScope:実装対象の特定に必要なソース・テスト範囲を入力してください}

`technical-decisions.md`のDecisionは確定事項です。

## 行わないこと

- 確定済み技術方式の再比較
- 新しいアーキテクチャの独自導入
- 新規依存の独自追加
- 要求範囲の拡張
- 実装コードの生成

## 計画形式

独立して検証可能なステップへ分割し、各ステップに次を含めてください。

1. ステップ名
2. 目的
3. 変更対象ファイル
4. 追加・変更するクラス、関数、データ構造
5. 具体的な変更内容
6. 変更してはいけない内容
7. 追加するテスト
8. 実行する検証コマンド
9. 完了条件
10. 停止条件
11. 依存する先行ステップ

## 計画制約

- 1ステップで扱う主要責務は1つにする。
- 各ステップ終了時に検証可能にする。
- 大規模な一括書き換えを避ける。
- 既存挙動を守る回帰テストを含める。
- 一度に実装するバッチは2～4ステップを想定する。
- 最大15ステップとする。
- 同じ説明を繰り返さない。
- 未確定事項を独自判断しない。

未確定事項が見つかった場合は、該当ステップを`BLOCKED`とし、最後に最大5件を列挙してください。

最後に次を含めてください。

- `Recommended Implementation Batches`
- `Overall Completion Criteria`
