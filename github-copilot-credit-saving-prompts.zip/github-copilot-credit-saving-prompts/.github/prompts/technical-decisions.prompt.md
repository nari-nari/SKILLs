---
name: technical-decisions
description: リポジトリを調査し重要な技術判断をtechnical-decisions.mdへ記録する
argument-hint: "決定する論点と調査対象範囲を入力"
agent: 'agent'
---

リポジトリを読み取り調査し、`docs/current/technical-decisions.md`だけを作成または編集してください。

## 必須参照

- [Feature Brief](../../docs/current/feature-brief.md)
- `pyproject.toml`、`package.json`、ビルド設定など、このプロジェクトの主要設定ファイル

## 今回決定する論点

${input:decisionTopics:決定する技術論点を列挙してください}

## 調査対象

${input:researchScope:参照してよいディレクトリ・ファイルを列挙してください}

## 固定制約

${input:fixedConstraints:言語、テスト、互換性、新規依存の可否などを列挙してください}

## 変更可能

- `docs/current/technical-decisions.md`

## 変更禁止

- ソースコード
- テストコード
- `docs/current/feature-brief.md`
- 設定ファイル
- 依存パッケージ
- その他のファイル

## 調査・判断の方針

- 指定範囲を優先し、リポジトリ全体を無制限に探索しない。
- 現在のコードから確認できた事実と推測を区別する。
- 各論点について、正確性、既存コードとの整合性、後方互換性、検証可能性、安全性、保守性を評価する。
- 外部パッケージ調査が必要な場合だけWeb検索を使い、公式ドキュメント、公式リポジトリ、公式リリース情報など一次情報を優先する。
- 未検証の候補は採用確定ではなく、条件付き候補として扱う。
- 未確定事項を独自判断しない。

## 出力構成

```markdown
# Technical Decisions

## Context

## Decision 1: <論点名>
### Decision
### Rationale
### Alternatives Rejected
### Fallback
### Safety Stop Conditions
### Required Validation

## Decision 2: <論点名>
...

## Cross-Cutting Constraints
## Unresolved Issues
## Confirmed Inputs for Planning
```

## 制約

- 実装計画やタスクリストを作成しない。
- 実装コードやテストコードを生成しない。
- 一般論を長く説明しない。
- 文書は必要最小限とする。
- 同じ内容を複数節で繰り返さない。
- 作成後に全文を何度も再生成しない。
- チャットでは、変更ファイル、未解決事項数、Planへ進めるかだけを報告する。
