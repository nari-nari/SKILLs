# Current Development Documents

このディレクトリは、Prompt filesが作成・更新する開発成果物の保存先です。

標準ファイル:

- `feature-brief.md`
- `technical-decisions.md`
- `implementation-plan.md`
- `implementation-log.md`
- `review.md`
- `handoff.md`

最初は`/create-feature-brief`から開始してください。
