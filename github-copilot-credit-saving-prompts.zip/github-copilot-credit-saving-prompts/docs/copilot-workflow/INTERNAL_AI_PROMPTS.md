# 社内AIチャット用プロンプト

このファイルの内容はGitHub Copilotのslash commandではありません。社内AIチャットへコピーして使います。

## 1. Feature Briefの素材を作る

```text
以下の開発要望を、ソフトウェア機能の要求定義として整理してください。

【開発したい内容】
[自由記述]

【背景】
[なぜ必要か]

【現在の問題】
[問題、失敗例、面倒な作業]

【既知の制約】
- [制約1]
- [制約2]

以下の構成で、完成したMarkdownを出力してください。

# Feature Brief
## 1. Background
## 2. Objective
## 3. Intended Use
## 4. Scope
## 5. Out of Scope
## 6. Functional Requirements
## 7. Safety and Reliability Requirements
## 8. Normal Cases
## 9. Error and Boundary Cases
## 10. Acceptance Criteria
## 11. Human Approval Points
## 12. Open Questions

注意:
- 技術方式や使用パッケージは決定しない。
- 実装コードを生成しない。
- 不明点はOpen Questionsへ残す。
- 受入条件はテスト可能な表現にする。
- 前置きなしでMarkdown本文だけを出力する。
```

## 2. Feature Briefの安全性レビュー

```text
以下のFeature Briefをレビューしてください。

[feature-brief.mdの内容]

文章の美化ではなく、実装後の手戻りや危険な自動処理につながる曖昧さを発見してください。

確認観点:
1. 成功条件が客観的に判定できるか
2. 失敗時の挙動が定義されているか
3. 自動処理を禁止すべき条件があるか
4. 人間の承認条件が明確か
5. 不完全な入力の扱い
6. 後方互換性
7. ロールバックや元データ保持
8. テスト可能性
9. 対象範囲の膨張
10. 要求間の矛盾

出力:
## Critical Issues
## Minor Issues
## Proposed Changes
## Readiness

Feature Brief全体を書き直さないでください。
```

## 3. 実装計画の要件レビュー

```text
以下の要求、技術判断、実装計画をレビューしてください。

【要求】
[feature-brief.md]

【技術判断】
[technical-decisions.md]

【実装計画】
[implementation-plan.md]

確認観点:
1. すべての要求がPlanへ反映されているか
2. 技術判断と矛盾していないか
3. 依存順序が妥当か
4. 各Stepが独立して検証可能か
5. 回帰テストが不足していないか
6. 停止条件があるか
7. 後方互換性を確認できるか
8. 1回の変更範囲が広すぎないか
9. 対象外機能が混入していないか
10. 人間の承認点が不足していないか

出力:
## Critical Problems
## Minor Improvements
## Implementation Readiness
## Minimum Required Plan Changes

Plan全体を書き直さず、修正箇所だけを示してください。
```

## 4. 実装結果の要件レビュー

```text
以下の実装結果を、要求と安全性の観点からレビューしてください。

【当初の目的】
[記載]

【受入条件】
[記載]

【確定した技術判断】
[記載]

【実装した内容】
[記載]

【実行したテストと結果】
[記載]

【Planから変更した点】
[記載]

【未解決問題】
[記載]

出力:
## Achieved
## Not Achieved
## Additional Validation Required
## Human Approval Required
## Conditions for Next Stage
## Decision

判断できない事項を確認済みのように推測しないでください。
```
