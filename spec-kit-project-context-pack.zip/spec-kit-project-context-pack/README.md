# Spec Kit × プロジェクト状況管理 × 社内AI連携パック

このフォルダは、既存のSpec Kitプロジェクトへ追加して使う、ベンダー非依存のコンテキスト管理テンプレートです。
Spec Kitが管理する機能単位の成果物と、プロジェクト全体の状況、社内AIとの相談記録を分離します。

## 目的

- `spec.md`、`plan.md`、`tasks.md`を機能単位の正本として維持する
- プロジェクト全体の現在地点を`docs/project-status.md`へ集約する
- 社内AIへ渡す相談資料を、許可リスト方式で生成する
- 社内AIの回答を未承認の助言として隔離する
- 人間が承認した内容だけをSpec Kit成果物へ反映する
- 会話や担当者が変わっても、現在の状態から作業を再開できるようにする

## 既存Spec Kitプロジェクトへの追加

1. このパックの内容をプロジェクトルートへコピーします。
2. 既存ファイルがある場合は上書きせず、差分を確認して統合します。
3. `context-pack.toml`のプロジェクト名、許可パス、秘匿パターンを編集します。
4. `templates/constitution-addendum.md`から必要な原則を、既存の`.specify/memory/constitution.md`へ統合します。
5. `docs/project-status.md`と`docs/roadmap.md`を現在のプロジェクトに合わせて編集します。

このパックは、Spec Kit本体が生成した`.specify/scripts/`、`.specify/templates/`、`specs/<feature>/`を上書きしません。

## 情報の正本

| 種別 | 主な保存先 | 扱い |
|---|---|---|
| 長期原則 | `.specify/memory/constitution.md` | 正本 |
| 機能要求 | `specs/<feature>/spec.md` | 正本 |
| 技術計画 | `specs/<feature>/plan.md` | 正本 |
| 実装タスク | `specs/<feature>/tasks.md` | 正本 |
| 実装・テスト結果 | ソースコード、テスト、CIログ | 正本 |
| 全体状況 | `docs/project-status.md` | 上記から作る現在スナップショット |
| 中期計画 | `docs/roadmap.md` | 人間が管理する全体計画 |
| 社内AIの生回答 | `.context-work/ai-exchange/inbox/` | 未承認・Git管理外 |
| 承認済みの評価記録 | `docs/ai-exchange/records/` | 追跡可能な記録 |

詳細は[`docs/context-governance.md`](docs/context-governance.md)を参照してください。

## 基本ワークフロー

### 新規機能

```text
/speckit.specify
→ /speckit.clarify
→ /speckit.plan
→ /speckit.tasks
→ /speckit.analyze
→ /speckit.implement
→ テスト
→ /speckit.converge
→ project-status更新
```

### 仕様・設計変更

```text
気付き・社内AI提案
→ 人間が採否判断
→ spec / research / plan / tasksへ振り分け
→ /speckit.analyze
→ 変更タスクだけ実装
→ /speckit.converge
→ project-status更新
```

### 社内AI相談

```text
相談目的を決める
→ 許可された文書だけで相談パッケージを生成
→ 機密性を検査
→ 人間が最終確認
→ 社内AIへ手動投入
→ 回答を未承認領域へ保存
→ 回答を分類・評価
→ 承認した内容だけSpec Kitへ反映
```

## 状況収集

機能ごとの`tasks.md`を集計し、`docs/project-status.md`の自動生成領域を更新します。

```bash
python tools/context_pack/collect_project_status.py --update-markdown
```

重要: チェックボックスがすべて完了しても、スクリプトは「Tasks complete」としか判定しません。本番検証や受入完了を自動的に主張しません。

## 社内AI相談パッケージの生成

```bash
python tools/context_pack/build_ai_context.py \
  --topic "CALL引数解析の方針" \
  --question-file .context-work/question.md \
  --source docs/project-status.md \
  --source docs/roadmap.md \
  --source specs/002-call-analysis/spec.md \
  --source specs/002-call-analysis/plan.md
```

生成先は既定で`.context-work/ai-exchange/outbox/`です。ネットワーク送信は行いません。

検査のみ実行する場合:

```bash
python tools/context_pack/validate_ai_context.py .context-work/ai-exchange/outbox/<package>
```

## 整合性の簡易確認

```bash
python tools/context_pack/check_context_consistency.py
```

これはファイル存在や基本構造の決定論的チェックです。意味上の整合性は`/speckit.analyze`と人間のレビューで確認します。

## Copilotで使える主なプロンプト

VS Codeのローカルエージェントでは`.github/prompts/`を利用できます。Agent Hostではプロンプトファイルが使われない場合があるため、長期運用の中核手順は`.github/skills/`にも用意しています。

| コマンド名 | 用途 |
|---|---|
| `/classify-internal-ai-response` | 社内AI回答をspec/research/plan/tasks等へ分類 |
| `/prepare-speckit-specify-input` | 承認済み要求から`/speckit.specify`入力を作成 |
| `/prepare-speckit-plan-input` | 承認済み技術案から`/speckit.plan`入力を作成 |
| `/prepare-speckit-tasks-input` | 更新範囲を限定した`/speckit.tasks`入力を作成 |
| `/prepare-speckit-implement-input` | タスク範囲を限定した`/speckit.implement`入力を作成 |
| `/prepare-internal-ai-consultation` | 相談資料の下書き作成 |
| `/review-internal-ai-response` | 回答の採否・リスク評価 |
| `/apply-approved-spec-change` | 承認済み要求だけをspecへ反映 |
| `/apply-approved-plan-change` | 承認済み技術案だけをplanへ反映 |
| `/apply-approved-task-change` | 既存完了状態を保持してtasksへ反映 |
| `/pre-implementation-gate` | 実装前の読み取り専用確認 |
| `/update-project-status` | 実装・検証後の状況更新 |
| `/post-implementation-review` | 実装後の漏れと上流への戻し先を確認 |

## テスト

標準ライブラリだけでテストできます。

```bash
python -m unittest discover -s tools/context_pack/tests -v
```

## 導入時の注意

- `.github/copilot-instructions.md`が既にある場合は、全文を置き換えず「Project context and Spec Kit」節を統合してください。
- 社内AIの仕様、API、保存ポリシーは会社ごとに異なるため、このパックは送信機能を持ちません。
- `docs/project-status.md`は詳細履歴ではなく、作業再開に必要な短い現在状態に保ちます。
- `docs/key-decisions.md`には横断的で長期的な重要判断だけを残します。機能固有の判断は各`plan.md`または`research.md`へ記録します。
