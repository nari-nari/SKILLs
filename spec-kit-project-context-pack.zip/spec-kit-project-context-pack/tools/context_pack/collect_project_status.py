from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from datetime import date
from pathlib import Path

from context_pack_lib import load_config, resolve_inside, write_json

TASK_RE = re.compile(r"^\s*-\s*\[([ xX])\]\s+")
START = "<!-- AUTO:FEATURE_STATUS:START -->"
END = "<!-- AUTO:FEATURE_STATUS:END -->"


@dataclass
class FeatureStatus:
    feature: str
    spec: bool
    research: bool
    plan: bool
    tasks: bool
    tasks_done: int
    tasks_total: int
    derived_state: str


def derive_state(done: int, total: int, has_spec: bool, has_plan: bool) -> str:
    if total > 0 and done == total:
        return "Tasks complete"
    if done > 0:
        return "In progress"
    if total > 0 or has_plan or has_spec:
        return "Planned"
    return "Uninitialized"


def inspect_feature(directory: Path) -> FeatureStatus:
    tasks_path = directory / "tasks.md"
    done = total = 0
    if tasks_path.is_file():
        for line in tasks_path.read_text(encoding="utf-8", errors="replace").splitlines():
            match = TASK_RE.match(line)
            if match:
                total += 1
                if match.group(1).lower() == "x":
                    done += 1
    has_spec = (directory / "spec.md").is_file()
    has_plan = (directory / "plan.md").is_file()
    return FeatureStatus(
        feature=directory.name,
        spec=has_spec,
        research=(directory / "research.md").is_file(),
        plan=has_plan,
        tasks=tasks_path.is_file(),
        tasks_done=done,
        tasks_total=total,
        derived_state=derive_state(done, total, has_spec, has_plan),
    )


def render_table(features: list[FeatureStatus]) -> str:
    lines = [
        "| Feature | Artifacts | Tasks | Derived state |",
        "|---|---|---:|---|",
    ]
    for item in features:
        artifacts = ", ".join(
            name for name, present in [
                ("spec", item.spec), ("research", item.research),
                ("plan", item.plan), ("tasks", item.tasks)
            ] if present
        ) or "—"
        progress = f"{item.tasks_done}/{item.tasks_total}" if item.tasks_total else "—"
        lines.append(f"| `{item.feature}` | {artifacts} | {progress} | {item.derived_state} |")
    if not features:
        lines.append("| — | — | — | No feature directories found |")
    lines.append("")
    lines.append("> Derived state reflects artifact/task presence only. It does not establish acceptance or production validation.")
    return "\n".join(lines)


def replace_block(text: str, block: str) -> str:
    if START not in text or END not in text:
        raise ValueError("project-status.md does not contain the required AUTO markers")
    before, remainder = text.split(START, 1)
    _, after = remainder.split(END, 1)
    return f"{before}{START}\n{block}\n{END}{after}"


def main() -> int:
    parser = argparse.ArgumentParser(description="Collect Spec Kit feature/task status")
    parser.add_argument("--update-markdown", action="store_true")
    parser.add_argument("--json", action="store_true", help="Print JSON to stdout")
    args = parser.parse_args()

    config = load_config()
    specs_dir = resolve_inside(config.root, config.project.get("specs_dir", "specs"))
    features = []
    if specs_dir.is_dir():
        features = [inspect_feature(item) for item in sorted(specs_dir.iterdir()) if item.is_dir()]

    payload = {
        "generated_on": date.today().isoformat(),
        "project": config.project.get("name", "CHANGE_ME"),
        "features": [asdict(item) for item in features],
    }
    json_path = resolve_inside(config.root, config.project.get("generated_status_json", "docs/generated/spec-status.json"))
    write_json(json_path, payload)

    if args.update_markdown:
        status_path = resolve_inside(config.root, config.project.get("status_file", "docs/project-status.md"))
        current = status_path.read_text(encoding="utf-8")
        status_path.write_text(replace_block(current, render_table(features)), encoding="utf-8")

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"Collected {len(features)} feature(s); wrote {json_path.relative_to(config.root)}")
        if args.update_markdown:
            print("Updated project status auto-generated block")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
