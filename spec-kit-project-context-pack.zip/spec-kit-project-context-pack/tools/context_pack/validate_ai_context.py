from __future__ import annotations

import argparse
import json
from pathlib import Path

from context_pack_lib import iter_text_files, load_config, resolve_inside, scan_forbidden


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a generated AI consultation package")
    parser.add_argument("package")
    args = parser.parse_args()

    config = load_config()
    package = resolve_inside(config.root, args.package)
    if not package.is_dir():
        raise NotADirectoryError(package)

    findings: list[str] = []
    manifest_path = package / "manifest.json"
    consultation_path = package / "consultation.md"
    if not manifest_path.is_file():
        findings.append("manifest.json is missing")
    if not consultation_path.is_file():
        findings.append("consultation.md is missing")

    allowed_extensions = config.ai_exchange.get("allowed_extensions", [])
    for file in iter_text_files(package, allowed_extensions):
        text = file.read_text(encoding="utf-8", errors="replace")
        for issue in scan_forbidden(text, config):
            findings.append(f"{file.relative_to(package)}: {issue}")

    if manifest_path.is_file():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            if manifest.get("network_transmission_performed") is not False:
                findings.append("manifest must state network_transmission_performed=false")
            if manifest.get("status") != "draft-human-review-required":
                findings.append("manifest status must remain draft-human-review-required until human review")
        except json.JSONDecodeError as exc:
            findings.append(f"manifest.json is invalid: {exc}")

    if findings:
        print("VALIDATION FAILED")
        for finding in findings:
            print(f"- {finding}")
        return 1

    print("VALIDATION PASSED")
    print("Automated validation does not replace human disclosure review.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
