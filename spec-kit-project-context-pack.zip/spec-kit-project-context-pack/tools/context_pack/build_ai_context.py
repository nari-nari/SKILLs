from __future__ import annotations

import argparse
import json
import re
from datetime import datetime
from pathlib import Path

from context_pack_lib import (
    is_allowed_source,
    load_config,
    redact_text,
    relative_posix,
    resolve_inside,
    sha256_bytes,
    write_json,
)


def slugify(value: str) -> str:
    value = re.sub(r"[^0-9A-Za-z_-]+", "-", value.strip()).strip("-").lower()
    return value[:60] or "consultation"


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a sanitized internal-AI consultation package")
    parser.add_argument("--topic", required=True)
    question_group = parser.add_mutually_exclusive_group(required=True)
    question_group.add_argument("--question")
    question_group.add_argument("--question-file")
    parser.add_argument("--source", action="append", required=True, help="Repeat for each allowlisted source")
    parser.add_argument("--output-dir")
    args = parser.parse_args()

    config = load_config()
    question = args.question
    if args.question_file:
        qpath = resolve_inside(config.root, args.question_file)
        question = qpath.read_text(encoding="utf-8")
    assert question is not None

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    if args.output_dir:
        output = resolve_inside(config.root, args.output_dir)
    else:
        work_root = config.ai_exchange.get("work_root", ".context-work/ai-exchange")
        output = resolve_inside(config.root, Path(str(work_root)) / "outbox" / f"{timestamp}-{slugify(args.topic)}")
    output.mkdir(parents=True, exist_ok=False)

    manifest_sources = []
    sections = []
    total_redactions = 0

    for source_arg in args.source:
        source = resolve_inside(config.root, source_arg)
        if not source.is_file():
            raise FileNotFoundError(f"Source does not exist: {source_arg}")
        allowed, reason = is_allowed_source(source, config)
        if not allowed:
            raise ValueError(f"Source rejected ({reason}): {source_arg}")

        raw_bytes = source.read_bytes()
        raw_text = raw_bytes.decode("utf-8", errors="replace")
        sanitized, redactions = redact_text(raw_text, config)
        total_redactions += sum(int(item["count"]) for item in redactions)
        relative = relative_posix(config.root, source)
        sections.append(f"## Source: `{relative}`\n\n{sanitized.rstrip()}\n")
        manifest_sources.append({
            "path": relative,
            "original_sha256": sha256_bytes(raw_bytes),
            "sanitized_sha256": sha256_bytes(sanitized.encode("utf-8")),
            "redactions": redactions,
        })

    sanitized_question, question_redactions = redact_text(question, config)
    total_redactions += sum(int(item["count"]) for item in question_redactions)

    consultation = f"""# Internal AI Consultation Package\n\nTopic: {args.topic}\nGenerated: {datetime.now().isoformat(timespec='seconds')}\nStatus: Draft — human disclosure review required\n\n## Question\n\n{sanitized_question.strip()}\n\n## Included context\n\n""" + "\n".join(sections) + "\n\n## Instructions to reviewer\n\n- Confirm that every included source is necessary.\n- Confirm that redactions and exclusions are sufficient.\n- Do not submit until a human approves disclosure.\n"
    (output / "consultation.md").write_text(consultation, encoding="utf-8")

    manifest = {
        "schema_version": 1,
        "topic": args.topic,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "status": "draft-human-review-required",
        "question_redactions": question_redactions,
        "total_redactions": total_redactions,
        "sources": manifest_sources,
        "network_transmission_performed": False,
    }
    write_json(output / "manifest.json", manifest)
    print(f"Created {output.relative_to(config.root)}")
    print(f"Sources: {len(manifest_sources)}; redactions: {total_redactions}")
    print("No network transmission was performed. Run validate_ai_context.py next.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
