# Context Pack Tools

All tools use Python 3.11+ standard library only.

- `collect_project_status.py`: counts Spec Kit task checkboxes and updates only the marked block in project status
- `build_ai_context.py`: creates a sanitized, allowlisted draft package; never transmits it
- `validate_ai_context.py`: scans a package for configured forbidden patterns
- `check_context_consistency.py`: checks required files and basic artifact structure

Run tools from the repository root so `context-pack.toml` can be discovered.
