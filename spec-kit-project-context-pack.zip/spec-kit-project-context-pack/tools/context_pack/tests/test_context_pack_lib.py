from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

from context_pack_lib import PackConfig, redact_text, resolve_inside  # noqa: E402


class ContextPackLibTests(unittest.TestCase):
    def test_resolve_inside_rejects_escape(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve()
            with self.assertRaises(ValueError):
                resolve_inside(root, "../outside.txt")

    def test_redaction(self) -> None:
        config = PackConfig(
            Path.cwd(),
            {"redaction": {"replacement": "[X]", "patterns": [r"secret=\S+"], "forbidden_literals": []}},
        )
        result, redactions = redact_text("a secret=VALUE b", config)
        self.assertEqual(result, "a [X] b")
        self.assertEqual(redactions[0]["count"], 1)


if __name__ == "__main__":
    unittest.main()
