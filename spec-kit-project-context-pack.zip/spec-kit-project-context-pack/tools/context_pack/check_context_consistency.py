from __future__ import annotations

import argparse
from pathlib import Path

from context_pack_lib import load_config, resolve_inside

REQUIRED_ROOT_FILES = [
    ".github/copilot-instructions.md",
    "docs/context-governance.md",
    "docs/project-status.md",
    "docs/roadmap.md",
    "docs/known-issues.md",
    "docs/ai-exchange/README.md",
]


def main() -> int:
    parser = argparse.ArgumentParser(description="Check deterministic project-context structure")
    parser.parse_args()
    config = load_config()
    findings: list[str] = []

    for relative in REQUIRED_ROOT_FILES:
        if not resolve_inside(config.root, relative).is_file():
            findings.append(f"missing required file: {relative}")

    status_path = resolve_inside(config.root, config.project.get("status_file", "docs/project-status.md"))
    if status_path.is_file():
        status = status_path.read_text(encoding="utf-8")
        if "<!-- AUTO:FEATURE_STATUS:START -->" not in status or "<!-- AUTO:FEATURE_STATUS:END -->" not in status:
            findings.append("project-status.md is missing auto-generated markers")

    specs_dir = resolve_inside(config.root, config.project.get("specs_dir", "specs"))
    if specs_dir.is_dir():
        for feature in sorted(item for item in specs_dir.iterdir() if item.is_dir()):
            if not (feature / "spec.md").is_file():
                findings.append(f"{feature.relative_to(config.root)}: spec.md is missing")
            if (feature / "tasks.md").is_file() and not (feature / "plan.md").is_file():
                findings.append(f"{feature.relative_to(config.root)}: tasks.md exists but plan.md is missing")

    if findings:
        print("CONTEXT CHECK FAILED")
        for finding in findings:
            print(f"- {finding}")
        return 1

    print("CONTEXT CHECK PASSED")
    print("This structural check does not replace /speckit.analyze or human review.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
