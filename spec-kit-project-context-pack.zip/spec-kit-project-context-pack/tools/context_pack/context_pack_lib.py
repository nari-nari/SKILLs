from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

try:
    import tomllib
except ModuleNotFoundError as exc:  # pragma: no cover
    raise RuntimeError("Python 3.11 or newer is required") from exc


@dataclass(frozen=True)
class PackConfig:
    root: Path
    data: dict[str, Any]

    @property
    def project(self) -> dict[str, Any]:
        return self.data.get("project", {})

    @property
    def ai_exchange(self) -> dict[str, Any]:
        return self.data.get("ai_exchange", {})

    @property
    def redaction(self) -> dict[str, Any]:
        return self.data.get("redaction", {})


def find_repo_root(start: Path | None = None) -> Path:
    current = (start or Path.cwd()).resolve()
    for candidate in (current, *current.parents):
        if (candidate / "context-pack.toml").is_file():
            return candidate
    raise FileNotFoundError("context-pack.toml was not found in this directory or its parents")


def load_config(root: Path | None = None) -> PackConfig:
    repo = (root or find_repo_root()).resolve()
    with (repo / "context-pack.toml").open("rb") as stream:
        return PackConfig(repo, tomllib.load(stream))


def resolve_inside(root: Path, value: str | Path) -> Path:
    path = (root / value).resolve() if not Path(value).is_absolute() else Path(value).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"Path escapes repository root: {value}") from exc
    return path


def relative_posix(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def redact_text(text: str, config: PackConfig) -> tuple[str, list[dict[str, Any]]]:
    replacement = str(config.redaction.get("replacement", "[REDACTED]"))
    redactions: list[dict[str, Any]] = []
    result = text

    for index, pattern in enumerate(config.redaction.get("patterns", []), start=1):
        regex = re.compile(str(pattern))
        result, count = regex.subn(replacement, result)
        if count:
            redactions.append({"kind": "regex", "index": index, "count": count})

    for literal in config.redaction.get("forbidden_literals", []):
        literal = str(literal)
        if not literal or literal.startswith("CHANGE_ME_"):
            continue
        count = result.count(literal)
        if count:
            result = result.replace(literal, replacement)
            redactions.append({"kind": "literal", "value": literal, "count": count})

    return result, redactions


def scan_forbidden(text: str, config: PackConfig) -> list[str]:
    findings: list[str] = []
    for index, pattern in enumerate(config.redaction.get("patterns", []), start=1):
        if re.search(str(pattern), text):
            findings.append(f"redaction pattern {index} remains")
    for literal in config.redaction.get("forbidden_literals", []):
        literal = str(literal)
        if literal and not literal.startswith("CHANGE_ME_") and literal in text:
            findings.append(f"forbidden literal remains: {literal}")
    return findings


def is_allowed_source(path: Path, config: PackConfig) -> tuple[bool, str]:
    root = config.root
    try:
        rel = path.resolve().relative_to(root)
    except ValueError:
        return False, "outside repository"

    allowed_roots = [Path(str(item)) for item in config.ai_exchange.get("allowed_source_roots", [])]
    if not any(rel == item or item in rel.parents for item in allowed_roots):
        return False, "outside allowlisted source roots"

    extensions = {str(item).lower() for item in config.ai_exchange.get("allowed_extensions", [])}
    if path.suffix.lower() not in extensions:
        return False, f"extension {path.suffix} is not allowed"

    max_bytes = int(config.ai_exchange.get("max_file_bytes", 200000))
    if path.stat().st_size > max_bytes:
        return False, f"file exceeds {max_bytes} bytes"
    return True, "allowed"


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def iter_text_files(path: Path, allowed_extensions: Iterable[str]) -> Iterable[Path]:
    extensions = {ext.lower() for ext in allowed_extensions}
    if path.is_file():
        if path.suffix.lower() in extensions:
            yield path
        return
    for item in sorted(path.rglob("*")):
        if item.is_file() and item.suffix.lower() in extensions:
            yield item
