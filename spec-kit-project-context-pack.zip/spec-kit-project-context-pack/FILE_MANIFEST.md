# File Manifest

Total files (excluding this manifest): 47

| Path | Bytes |
|---|---:|
| `.github/copilot-instructions.md` | 3272 |
| `.github/instructions/spec-kit-context.instructions.md` | 901 |
| `.github/prompts/apply-approved-plan-change.prompt.md` | 1122 |
| `.github/prompts/apply-approved-spec-change.prompt.md` | 956 |
| `.github/prompts/apply-approved-task-change.prompt.md` | 1045 |
| `.github/prompts/classify-internal-ai-response.prompt.md` | 1838 |
| `.github/prompts/post-implementation-review.prompt.md` | 919 |
| `.github/prompts/pre-implementation-gate.prompt.md` | 929 |
| `.github/prompts/prepare-internal-ai-consultation.prompt.md` | 1251 |
| `.github/prompts/prepare-speckit-implement-input.prompt.md` | 947 |
| `.github/prompts/prepare-speckit-plan-input.prompt.md` | 1093 |
| `.github/prompts/prepare-speckit-specify-input.prompt.md` | 987 |
| `.github/prompts/prepare-speckit-tasks-input.prompt.md` | 982 |
| `.github/prompts/review-internal-ai-response.prompt.md` | 1154 |
| `.github/prompts/update-project-status.prompt.md` | 1145 |
| `.github/skills/internal-ai-handoff/SKILL.md` | 1332 |
| `.github/skills/project-context-management/SKILL.md` | 1371 |
| `.gitignore` | 181 |
| `PACK_VERSION` | 6 |
| `README.md` | 6628 |
| `context-pack.toml` | 956 |
| `docs/ai-exchange/README.md` | 1578 |
| `docs/ai-exchange/records/README.md` | 451 |
| `docs/ai-exchange/templates/consultation-brief.md` | 1104 |
| `docs/ai-exchange/templates/prompts/architecture-review.md` | 834 |
| `docs/ai-exchange/templates/prompts/dependency-selection.md` | 934 |
| `docs/ai-exchange/templates/prompts/implementation-gap-analysis.md` | 755 |
| `docs/ai-exchange/templates/prompts/project-direction.md` | 1009 |
| `docs/ai-exchange/templates/prompts/specification-review.md` | 709 |
| `docs/ai-exchange/templates/prompts/verification-plan.md` | 752 |
| `docs/ai-exchange/templates/response-review.md` | 1342 |
| `docs/context-governance.md` | 3947 |
| `docs/generated/.gitkeep` | 0 |
| `docs/key-decisions.md` | 594 |
| `docs/known-issues.md` | 548 |
| `docs/project-status.md` | 1275 |
| `docs/roadmap.md` | 761 |
| `templates/constitution-addendum.md` | 1342 |
| `templates/feature-change-request.md` | 807 |
| `tools/context_pack/README.md` | 521 |
| `tools/context_pack/build_ai_context.py` | 4107 |
| `tools/context_pack/check_context_consistency.py` | 1989 |
| `tools/context_pack/collect_project_status.py` | 4446 |
| `tools/context_pack/context_pack_lib.py` | 4706 |
| `tools/context_pack/tests/test_collect_project_status.py` | 1302 |
| `tools/context_pack/tests/test_context_pack_lib.py` | 987 |
| `tools/context_pack/validate_ai_context.py` | 2049 |
