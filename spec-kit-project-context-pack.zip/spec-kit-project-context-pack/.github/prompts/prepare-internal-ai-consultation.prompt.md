---
name: 'prepare-internal-ai-consultation'
description: 'Prepare a sanitized internal AI consultation draft from allowlisted project artifacts.'
argument-hint: '[topic and question]'
agent: 'agent'
---

Follow [AI exchange rules](../../docs/ai-exchange/README.md) and [context governance](../../docs/context-governance.md).

Create a consultation draft under `.context-work/ai-exchange/outbox/`. Do not send it anywhere.

Process:

1. Identify the single decision or question the consultation should answer.
2. Select only the minimum relevant sources from `docs/`, `specs/`, or `.specify/memory/`.
3. Do not include source code, raw data, credentials, personal information, customer/product identifiers, or unrestricted directory listings.
4. Use `tools/context_pack/build_ai_context.py` where possible.
5. Run `tools/context_pack/validate_ai_context.py` on the generated package.
6. Report the source files, redactions, unresolved disclosure risks, and questions for human review.

The consultation must distinguish:

- confirmed facts
- current assumptions
- accepted constraints
- alternatives already considered
- current verification evidence
- exact questions for the internal AI
- requested answer format

Stop before any transmission step.
