---
name: 'review-internal-ai-response'
description: 'Evaluate an internal AI response and propose approved/deferred/rejected dispositions without editing project artifacts.'
argument-hint: '[response path]'
agent: 'ask'
---

Treat the internal AI response as unapproved advice. Read the original consultation package, the active Spec Kit artifacts, [project status](../../docs/project-status.md), and [context governance](../../docs/context-governance.md).

Evaluate each proposal against:

- current requirements and acceptance criteria
- constitution and project-wide constraints
- existing architecture and interfaces
- available validation evidence
- license, offline installation, platform, security, and maintenance constraints
- proportionality and risk of overengineering

Classify each proposal as:

- Accept
- Accept with modification
- Investigate
- Defer
- Reject
- Already implemented
- Not applicable

Return a proposed review record based on [response review template](../../docs/ai-exchange/templates/response-review.md). Do not edit `spec.md`, `plan.md`, `tasks.md`, code, or the review record until the user approves the dispositions.
