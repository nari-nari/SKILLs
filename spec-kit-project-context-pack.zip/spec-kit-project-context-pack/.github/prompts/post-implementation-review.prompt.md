---
name: 'post-implementation-review'
description: 'Review implementation against Spec Kit artifacts and identify convergence work without silently changing requirements.'
argument-hint: '[feature path or implemented task IDs]'
agent: 'ask'
---

Compare the implementation and test evidence with the target `spec.md`, `plan.md`, and `tasks.md`.

Identify:

- missing requirements or acceptance scenarios
- implementation that deviates from the accepted plan
- tasks marked complete without corresponding evidence
- untested abnormal or boundary behavior
- configuration, packaging, license, migration, documentation, or status-update omissions
- discoveries that require returning to spec, research, plan, or tasks
- accidental inclusion of unapproved internal AI proposals

Separate mandatory convergence work from optional improvement. Do not modify code or artifacts. Recommend `/speckit.converge` when applicable.
