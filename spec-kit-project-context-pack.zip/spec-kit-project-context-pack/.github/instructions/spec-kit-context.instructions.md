---
name: 'Spec Kit context governance'
description: 'Rules for editing Spec Kit artifacts, project status, and internal AI exchange records.'
applyTo: 'specs/**/*.md,docs/**/*.md,.specify/memory/**/*.md'
---

# Spec Kit context governance

Use [`docs/context-governance.md`](../../docs/context-governance.md) as the detailed policy.

- Identify whether the requested change is a requirement, technical plan, task decomposition, implementation, status update, or unapproved advice.
- Modify the smallest authoritative artifact first, then reconcile only affected downstream artifacts.
- Never convert unapproved AI advice into a requirement or implementation decision.
- Preserve completed tasks and historical limitations during partial updates.
- Separate facts, assumptions, decisions, proposals, and verification results.
- Do not claim production applicability without production-level evidence.
