---
name: project-context-management
description: Maintain project-wide status and context across Spec Kit features. Use when updating project status, preparing a handoff, reconciling feature progress, or checking context consistency.
argument-hint: '[feature or milestone]'
---

# Project context management

Use this skill when a task affects project-wide state rather than only one feature.

## Sources of truth

Read [context governance](../../../docs/context-governance.md), [project status](../../../docs/project-status.md), and [roadmap](../../../docs/roadmap.md).

Treat feature `spec.md`, `plan.md`, `tasks.md`, code, and tests as authoritative. Treat project status as a concise derived snapshot.

## Procedure

1. Identify the affected feature and authoritative artifacts.
2. Determine whether the change is a requirement, plan, task, implementation, verification, blocker, or roadmap change.
3. Reconcile only affected downstream artifacts.
4. Run [`collect_project_status.py`](../../../tools/context_pack/collect_project_status.py) to update the generated feature summary.
5. Update the human-maintained status sections using evidence, not inference.
6. Run [`check_context_consistency.py`](../../../tools/context_pack/check_context_consistency.py).
7. Report unresolved discrepancies and limitations.

Never infer production readiness from task completion.
