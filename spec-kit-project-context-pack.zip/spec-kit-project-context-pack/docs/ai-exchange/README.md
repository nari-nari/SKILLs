# Internal AI Exchange

This directory stores templates and approved, sanitized records of consultations with an internal AI.

## Directory policy

- `templates/`: reusable outbound and inbound templates
- `records/`: approved consultation/review records safe to retain in the repository
- `.context-work/ai-exchange/outbox/`: generated outbound drafts; Git ignored
- `.context-work/ai-exchange/inbox/`: raw inbound responses; Git ignored

Do not store raw confidential prompts or unreviewed AI responses under `docs/`.

## Outbound process

1. Define one consultation topic and decision.
2. Select the minimum source files.
3. Generate a package with `tools/context_pack/build_ai_context.py`.
4. Validate with `tools/context_pack/validate_ai_context.py`.
5. Human reviewer checks disclosure risk and question quality.
6. Manually submit through the approved company interface.

## Inbound process

1. Save the raw response under `.context-work/ai-exchange/inbox/`.
2. Use `/classify-internal-ai-response`.
3. Review each proposal against current Spec Kit artifacts and evidence.
4. Create a record using `templates/response-review.md`.
5. Obtain explicit human approval.
6. Apply approved changes to the correct artifact.
7. Run `/speckit.analyze`, implement the bounded task scope, test, and review convergence.

## Prohibited shortcuts

- Do not paste the whole repository.
- Do not ask an LLM to perform the only confidentiality filter.
- Do not treat the response as an approved specification.
- Do not modify requirements merely to match an attractive technical proposal.
