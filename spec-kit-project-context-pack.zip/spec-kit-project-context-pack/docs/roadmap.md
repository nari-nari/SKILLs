# Project Roadmap

Last updated: YYYY-MM-DD

## Milestones

| Milestone | Outcome | Target/Order | Status | Exit criteria |
|---|---|---|---|---|
| M1 | <Outcome> | 1 | Planned | <Criteria> |

## Feature map

| Feature | Purpose | Depends on | State | Spec directory | Verification required |
|---|---|---|---|---|---|
| F001 | <Purpose> | — | Planned | `specs/001-example/` | <Evidence> |

## Sequencing rules

- Do not start a dependent feature until its required upstream interface or evidence is stable.
- A feature with completed tasks is not automatically accepted.
- Record major sequencing changes in the change log below.

## Change log

| Date | Change | Reason | Approved by |
|---|---|---|---|
| YYYY-MM-DD | Initial roadmap | — | <name/role> |
