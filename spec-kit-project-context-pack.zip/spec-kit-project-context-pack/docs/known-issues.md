# Known Issues and Limitations

Last updated: YYYY-MM-DD

| ID | Area | Issue or limitation | Impact | Workaround | Resolution condition | Related feature |
|---|---|---|---|---|---|---|
| KI-001 | <area> | <description> | <impact> | <workaround> | <condition> | `specs/<feature>/` |

## Recording rules

- Record current, material limitations only.
- Keep implementation tasks in `tasks.md`, not here.
- Keep detailed incident history in issue tracking or Git history.
- Reflect blockers that affect the current phase in `docs/project-status.md`.
