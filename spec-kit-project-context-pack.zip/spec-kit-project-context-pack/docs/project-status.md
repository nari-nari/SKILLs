# Project Status

Last updated: YYYY-MM-DD
Overall state: Planned
Current phase: <current phase>
Active feature: `specs/<NNN-feature>/`

## Current goal

<The single outcome currently being pursued.>

## Feature summary

<!-- AUTO:FEATURE_STATUS:START -->
| Feature | Artifacts | Tasks | Derived state |
|---|---|---:|---|
| — | — | — | No feature directories found |

> Derived state reflects artifact/task presence only. It does not establish acceptance or production validation.
<!-- AUTO:FEATURE_STATUS:END -->

## Completed

- <Verified fact only>

## In progress

- <Current work>

## Blocked

- <Blocker and required resolution>

## Verification status

| Evidence | Status | Last run | Notes |
|---|---|---|---|
| Unit tests | Not run | — | — |
| Integration tests | Not run | — | — |
| Build/compile | Not run | — | — |
| Numerical regression | Not run | — | — |
| Production-code validation | Not performed | — | Do not claim production applicability |

## Known limitations

- <Limitation>

## Next actions

1. <Next action>
2. <Next action>

## Restart context

Read in this order:

1. `.specify/memory/constitution.md`
2. This file
3. `docs/roadmap.md`
4. Active feature `spec.md`
5. Active feature `plan.md`
6. Active feature `tasks.md`
