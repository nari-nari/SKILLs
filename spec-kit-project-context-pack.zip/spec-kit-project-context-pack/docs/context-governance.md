# Context Governance

Last reviewed: 2026-08-06

## 1. Purpose

This document defines how project facts, Spec Kit artifacts, project-wide status, and internal AI advice are stored and reconciled.

## 2. Information classes

### Authoritative

- `.specify/memory/constitution.md`: stable project principles
- `specs/<feature>/spec.md`: intended user-visible behavior and requirements
- `specs/<feature>/research.md`: relevant technical investigation and alternatives
- `specs/<feature>/plan.md`: accepted technical approach
- `specs/<feature>/tasks.md`: actionable work and completion state
- source code, tests, build output, and approved verification records: implementation evidence

### Derived current state

- `docs/project-status.md`
- generated feature/task summary under `docs/generated/`

Derived documents summarize authoritative artifacts. They must not silently override them.

### Planning

- `docs/roadmap.md`: feature sequencing, dependencies, and milestones
- `docs/known-issues.md`: current known limitations and risks

### Unapproved advice

- `.context-work/ai-exchange/inbox/`
- `.context-work/ai-exchange/outbox/`

These files are local drafts and are excluded from Git by default.

### Approved exchange records

- `docs/ai-exchange/records/`

An approved record documents the consultation, proposal dispositions, human approver, affected artifacts, and verification required. It is not itself a requirement unless the corresponding authoritative artifact is updated.

## 3. Change routing

| Change discovered | First authoritative artifact | Possible downstream artifacts |
|---|---|---|
| User-visible behavior or acceptance change | `spec.md` | `plan.md`, `tasks.md`, tests, code |
| Package, algorithm, architecture, module/folder structure | `research.md` or `plan.md` | `tasks.md`, code, tests |
| Work order or implementation decomposition | `tasks.md` | code, tests |
| Implementation defect with unchanged intent | code/tests, possibly a corrective task | status |
| Stable cross-feature principle | constitution | affected specs/plans/tasks |
| Current blocker or evidence change | project status / known issues | roadmap if sequencing changes |

## 4. Partial updates

- Do not regenerate unaffected artifacts.
- Preserve accepted decisions and completed tasks.
- Add corrective tasks when completed work must be revised.
- Mark obsolete work as Superseded or Deprecated instead of erasing history.
- Run `/speckit.analyze` after material changes to spec, plan, or tasks.
- Run relevant tests and a convergence review after implementation.

## 5. Status vocabulary

Use these states precisely:

- Planned: no implementation evidence yet
- In progress: implementation tasks have started
- Tasks complete: all task checkboxes are complete, but acceptance may remain
- Implemented: code exists for the intended scope
- Test passed: specified automated test was executed and passed
- Validated: required validation evidence meets defined criteria
- Accepted: a human stakeholder approved the result
- Production verified: verified with approved production-level code/data/environment
- Blocked: progress cannot continue without a dependency or decision

Never collapse these states into a single percentage.

## 6. Internal AI boundary

- An AI response is a proposal, not a decision.
- A package or folder-structure suggestion normally belongs in research/plan, not spec.
- A suggestion that changes user-visible behavior must be approved and reflected in spec first.
- Use an allowlist for outbound context. Do not provide the whole repository.
- Deterministic redaction and validation must precede human review.
- No script in this pack transmits data.

## 7. Decision recording threshold

Use `docs/key-decisions.md` only when a decision is cross-feature, costly to reverse, has credible alternatives, or is likely to be questioned later. Feature-local choices belong in the feature's `research.md` or `plan.md`.
