# Spec Kit × Project Context × Internal AI Pack

Version: 1.7.0

このZIPのルートは**配布パック自身**です。開発対象プロジェクトではありません。
開発対象プロジェクトのルート`README.md`を上書きしないよう、導入ファイルはすべて`project-overlay/`に分離しています。

## まずここから

1. [`START_HERE.md`](START_HERE.md)を読む
2. 対象プロジェクトへインストールする
3. `python tools/project_context/refresh_project_context.py`を一度実行する
4. 対象プロジェクトの`docs/project-context/START-HERE.md`から、現在の目的に合う入力例を1つ選ぶ


## ディレクトリ

```text
spec-kit-project-context-pack-v1.7.0/
├── README.md                 # この配布パックの説明
├── install.py                # 対象プロジェクトへの安全な導入
├── project-overlay/          # 対象プロジェクトへ導入されるファイル
│   ├── .github/
│   ├── .project-context/
│   ├── docs/project-context/
│   └── tools/project_context/
└── examples/
```

対象プロジェクト内では、次の役割を分離します。

```text
target-project/
├── README.md                       # 開発対象ツール・製品のREADME
├── src/ packages/ tests/ ...       # 開発対象ファイル
├── specs/ .specify/                # Spec Kitを使う機能がある場合
├── docs/project-context/           # 全体状況・プロジェクトマップ
├── .project-context/               # 設定・自動生成インベントリ
├── .context-work/                  # ローカル承認作業、Git管理外
└── tools/project_context/          # 状況収集とAI受け渡し支援
```

## 導入

```bash
python install.py /path/to/target-project
```

既存ファイルは既定で上書きしません。`.github/copilot-instructions.md`と`.gitignore`は識別マーカー付きの節として統合します。導入結果は対象プロジェクトの`.project-context/install-manifest.json`へ保存します。


## 旧版からの更新

既存プロジェクトへv1.2.0〜v1.6.0を導入済みの場合は、管理パック由来のファイルだけを更新します。

```bash
python install.py /path/to/target-project --overwrite-managed
```

対象プロジェクトのルート`README.md`は、この更新でも上書きされません。READMEの継続更新は、後述の承認付きワークフローで行います。

## 新規プロジェクトの最初のFeature（v1.4.0）

コードや既存文書がない状態では、Copilotではなく社内AIで最初の仕様を具体化できます。人間が入力するのは次の3項目だけです。

- 作りたいもの
- 分かっている制約
- 最初に実現したいこと

社内AIは最大3件ずつ推奨案付き質問を返し、人間の修正・承認後に`/speckit.specify`へ渡せる正式プロンプトを生成します。

入口：

```text
docs/project-context/new-project-bootstrap.md
docs/project-context/ai-exchange/templates/prompts/new-project-spec-intake.md
```

`.nc`解析ツール向けの短い記入例も含まれます。

## Spec Kit外のファイルも対象

`project-overlay/tools/project_context/collect_project_inventory.py`は、原則としてGitの追跡ファイルと未追跡・非無視ファイルを棚卸しします。次を同時に扱います。

- Spec Kitで作成したfeature
- 標準Agent/Planモードで追加した機能
- 手動で追加したコードや文書
- 他プロジェクトから流用したファイル
- テスト、設定、スクリプト、データ、生成物

流用元など機械的に判定できない情報は、`.project-context/components.toml`で最小限補足します。

## 初回実行

```bash
cd /path/to/target-project
python tools/project_context/refresh_project_context.py
```

その後、VS Code Chatで次のように短く依頼できます。

```text
/request-intake 次に実装すべき機能と社内AIへ相談する論点を整理したい
```

## 目的別の最初の入力例

| 目的 | 最初の入力 |
|---|---|
| 既存機能を変更 | `/request-intake 同じ.ncファイルを開いたとき前回設定を復元したい` |
| 技術選定を社内AIへ相談 | `/request-intake Windows配布方式を社内AIに比較してもらいたい` |
| 複雑な機能を延期 | `/defer-feature-to-roadmap <対象spec> 自動位置合わせを後続へ分離` |
| 実装後の将来候補 | `/propose-roadmap-update feature-completed` |
| README整合確認 | `/assess-readme-update 起動方法と主要機能が変わった` |

より多くの例は、導入先の`docs/project-context/prompt-examples.md`にあります。

## 日常の入口

```text
/refresh-project-context
/request-intake コピーして追加した解析モジュールを今後の開発計画に含めたい
/generate-approved-request-change-input .context-work/requests/REQ-0001/request.md
```

`/generate-approved-request-change-input`は、依頼がSpec Kitに属する場合だけSpec Kit入力を作り、それ以外は標準Agent向けの変更指示を生成します。



## 段階式の汎用受付（v1.7.0）

`/request-intake`は、何でも重く調査する万能エージェントではなく、低コストで専門ルートへ振り分ける共通入口になりました。

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
/request-intake [feature] 同じ.ncを開いたとき前回の解析範囲を復元したい
/request-intake deep [refactor] packages配下の2パッケージを統合したい
```

- Quick: snapshotだけを読み、質問・request作成なしで専門コマンドを1つ返す
- Standard: 単純作業は直接ルート、仕様・複数領域・承認が必要な場合だけrequestを作る
- Deep: 横断変更として必ずrequestを作り、依存関係と段階計画を調査する

任意ヒント：`feature`、`bug`、`research`、`refactor`、`docs`、`roadmap`、`validation`、`import`、`context`、`unknown`。

詳しい入力例は、導入先の次を参照してください。

```text
docs/project-context/request-intake-cheatsheet.md
docs/project-context/prompt-examples.md
```

`/project-context-help`を毎回前段に置く必要はありません。目的が明確なら専門コマンド、迷う場合は`/request-intake`、入口自体が分からない場合だけ静的START-HEREまたはhelpを使います。

## Copilot使用量を抑える設計（v1.6.0）

- 全チャットへ付く`.github/copilot-instructions.md`を短縮
- 詳細規則をパス別instructionsへ分離
- カスタムエージェントの利用可能ツールを読込・検索・編集・ローカル実行へ限定し、Web・Browser・MCPを既定で除外
- `refresh_project_context.py`でコンパクトな`copilot-snapshot.md`を生成
- エージェントはスナップショットから開始し、原則8ファイル以内へ絞る
- 全インベントリを会話へ貼らず、候補パスの特定だけに使う
- 採番、棚卸し、検証、差分適用はPythonへ任せる
- requestにMust read／必要時だけ／除外パスを記録し、下流工程で再利用

利用例は対象プロジェクトの次の文書へ集約しています。

```text
docs/project-context/START-HERE.md
docs/project-context/prompt-examples.md
docs/project-context/copilot-efficient-usage.md
```

実際の消費量はモデル、会話履歴、ツール出力、検索範囲に依存するため保証値ではありません。

## AI支援ロードマップ管理（v1.5.0）

AIは、現在の仕様から延期された範囲、コード・テスト・検証から判明した不足、繰り返す既知問題、承認済み社内AI調査などを根拠として、将来作業の候補を作成できます。

```text
/propose-roadmap-update feature-completed
/defer-feature-to-roadmap <対象specまたは要求>
/review-roadmap-proposals
```

候補は次へ保存され、正式ロードマップとは分離されます。

```text
.context-work/roadmap/proposals/RM-xxxx.toml
```

AIは候補を`Ready for review`まで整理できますが、人間の承認情報は設定できません。承認後は、まず差分を確認します。

```bash
python tools/project_context/apply_roadmap_update.py   .context-work/roadmap/proposals/RM-0001.toml
```

明示的な承認後だけ適用します。

```bash
python tools/project_context/apply_roadmap_update.py   .context-work/roadmap/proposals/RM-0001.toml --apply
```

適用時には正式`roadmap.md`のハッシュ、重複、承認者、route、検証条件を検査し、バックアップと昇格記録を残します。昇格後は`/generate-roadmap-item-change-input`でSpec Kitまたは標準Agent向けの次工程入力を生成できます。実装は自動開始しません。

## README継続保守（v1.3.0）

導入時は対象プロジェクトの`README.md`を保護しますが、導入後は主要機能、インストール、使い方、対応環境、公開インターフェース、主要構成、重要な制限の変化を承認付きで反映できます。

```text
/assess-readme-update
```

Copilotはリポジトリ全体とプロジェクト状況を確認し、README更新が必要なら次へDraft提案を生成します。

```text
.context-work/readme/updates/README-UPDATE-xxxx.toml
```

人間が文面を修正し、`status = "Approved"`と`approved_by`を設定した後、まず差分だけを確認します。

```bash
python tools/project_context/apply_readme_update.py \
  .context-work/readme/updates/README-UPDATE-0001.toml
```

承認した差分だけを適用します。

```bash
python tools/project_context/apply_readme_update.py \
  .context-work/readme/updates/README-UPDATE-0001.toml --apply
```

更新可能な見出しと保護見出しは、対象プロジェクトの`.project-context/readme-policy.toml`で設定します。適用時にはREADMEのSHA-256を確認し、提案作成後にREADMEが変わっていれば停止します。また、適用前のREADMEを`.context-work/readme/backups/`へ保存します。


## v1.7.0の検証

- 自動テスト：26件
- 新規導入：確認済み
- v1.6.0からの管理ファイル更新：確認済み
- 対象プロジェクトのルートREADME保持：確認済み
- QuickのREADME直接ルート：確認済み
- 構造整合性チェック：成功
- Pythonキャッシュ非同梱：配布時に検査
