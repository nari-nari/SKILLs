# Internal AI Exchange

短い依頼から相談を始める場合は、先に[`../request-orchestration.md`](../request-orchestration.md)の依頼ブリーフを作成し、承認済みの`request.md`から正式相談文を生成してください。

This directory stores templates and approved, sanitized records of consultations with an internal AI.

## 新規プロジェクトの最初のFeature

コードやプロジェクト文書がまだない場合は、[`../new-project-bootstrap.md`](../new-project-bootstrap.md)と[`templates/prompts/new-project-spec-intake.md`](templates/prompts/new-project-spec-intake.md)を使用します。人間が記入するのは「作りたいもの」「分かっている制約」「最初に実現したいこと」の3項目だけです。社内AIが推奨案付き質問を行い、明示的な承認後に`/speckit.specify`用の正式プロンプトを生成します。

## Directory policy

- `templates/`: reusable outbound and inbound templates
- `records/`: approved consultation/review records safe to retain in the repository
- `.context-work/ai-exchange/outbox/`: generated outbound drafts; Git ignored
- `.context-work/ai-exchange/inbox/`: raw inbound responses; Git ignored

Do not store raw confidential prompts or unreviewed AI responses under `docs/`.

## Outbound process

1. Define one consultation topic and decision.
2. Select the minimum source files.
3. Generate a package with `tools/project_context/build_ai_context.py`.
4. Validate with `tools/project_context/validate_ai_context.py`.
5. Human reviewer checks disclosure risk and question quality.
6. Manually submit through the approved company interface.

## Inbound process

1. Save the raw response under `.context-work/ai-exchange/inbox/`.
2. Use `/classify-internal-ai-response`.
3. Review each proposal against current Spec Kit artifacts and evidence.
4. Create a record using `templates/response-review.md`.
5. Obtain explicit human approval.
6. Apply approved changes to the correct artifact.
7. Run `/speckit.analyze`, implement the bounded task scope, test, and review convergence.

## Prohibited shortcuts

- Do not paste the whole repository.
- Do not ask an LLM to perform the only confidentiality filter.
- Do not treat the response as an approved specification.
- Do not modify requirements merely to match an attractive technical proposal.
