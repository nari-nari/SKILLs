# Approved AI Exchange Records

Store only reviewed and approved, sanitized records here.

Recommended filename:

```text
YYYYMMDD-topic-review.md
```

Each record should identify:

- source consultation
- proposal dispositions
- human approver and approved scope
- affected Spec Kit artifacts
- required implementation and validation
- unresolved risks

Raw responses remain under `.context-work/ai-exchange/inbox/` and are not committed by default.
