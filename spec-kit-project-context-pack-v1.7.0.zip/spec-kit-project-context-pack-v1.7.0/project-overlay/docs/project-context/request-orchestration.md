# Short-Request Orchestration

Last reviewed: 2026-08-07

## Purpose

`/request-intake`は、既存プロジェクトの共通入口です。ただし、すべての依頼について重い調査と`request.md`作成を行うのではなく、最初に低コストで専門ルートを決めます。

```text
short request
→ deterministic mode/hint parsing
→ snapshot-only triage
→ specialist command OR reviewed request brief
→ approval
→ formal downstream input
```

## Entry syntax

```text
/request-intake [quick|standard|deep] [hint] 短い依頼
```

モードとヒントは任意です。省略時は`standard [unknown]`です。

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
/request-intake [bug] CSVの出力範囲が画面と一致しない
/request-intake deep [refactor] packages配下の2パッケージを統合したい
```

## Deterministic parsing

AIによる調査前に、次のスクリプトがモード、ヒント、意図、直接ルートを解析します。

```bash
python tools/project_context/parse_request_intake.py \
  --input "quick [docs] READMEに設定保存機能を反映したい"
```

この処理はPython標準ライブラリだけを使い、AIトークンを消費しません。

## Modes

| Mode | 調査量 | 質問 | request.md | 主な用途 |
|---|---:|---:|---|---|
| Quick | snapshotのみ | 0 | 作らない | 専門コマンドを1つ知りたい |
| Standard | 原則8ファイル以内 | 最大3 | 必要時のみ | 通常の機能・不具合・相談 |
| Deep | 原則20ファイル以内 | 最大3 | 必ず作る | 統合、移行、横断API、構成変更 |

## Optional hints

```text
[feature] [bug] [research] [refactor] [docs]
[roadmap] [validation] [import] [context] [unknown]
```

ヒントはルート判定と検索範囲を狭めるためのものです。最終的にはユーザーの文章を優先します。

## When to skip a request brief

通常、次は専門コマンドへ直接送ります。

- 文脈スナップショット更新
- README更新要否の確認だけ
- ロードマップ候補の生成・一覧
- 既存テストの実行
- 明確な誤字修正
- 既知の単一ファイル修正
- 承認済み依頼の続行

## When to create a request brief

次のいずれかがあれば、Standardでも`request.md`を作ります。

- 利用者から見える挙動変更
- 複数ファイルまたは複数コンポーネント
- 要求の曖昧さ
- 社内AI相談
- Spec Kit正本の変更
- 技術選択
- 公開インターフェース変更
- 明示的な承認記録が必要

## Request artifact

```text
.context-work/requests/REQ-0001/
├── request.md
├── internal-ai-prompt.md
├── internal-ai-response.md
├── speckit-input.md
└── change-input.md
```

frontmatterには`intake_mode`、`request_hint`、`triage_reason`も保存されます。

## Review loop

```text
short intent
→ proposed interpretation and route
→ user correction
→ revised proposal
→ human approval
→ formal downstream input generation
```

質問は、リポジトリから解決できず、結果を大きく変える事項だけに限定します。

## Approval gate

```bash
python tools/project_context/validate_request.py \
  .context-work/requests/REQ-0001/request.md \
  --require-approved
```

必要条件：

- `status: Approved`
- routeが確定済み
- 3つの承認チェックがすべて`[x]`

## `/project-context-help`との関係

`/project-context-help`は必須ルーターではありません。静的な`START-HERE.md`でも入口を選べず、対話式の案内が必要な場合だけ利用します。目的が分かる場合は、専門コマンドまたは`/request-intake`を直接使います。
