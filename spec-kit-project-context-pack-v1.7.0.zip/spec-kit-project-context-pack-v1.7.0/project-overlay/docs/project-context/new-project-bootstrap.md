# New Project Bootstrap with Internal AI and Spec Kit

既存コードや文書がほとんどない新規プロジェクトでは、Copilotが自動収集できる文脈がありません。そのため、最初のFeatureだけは社内AIとの要求整理から開始します。

## 使うファイル

| ファイル | 用途 |
|---|---|
| [`ai-exchange/templates/prompts/new-project-spec-intake.md`](ai-exchange/templates/prompts/new-project-spec-intake.md) | 最初に社内AIへ貼り付ける対話型テンプレート |
| [`ai-exchange/templates/prompts/new-project-spec-revision.md`](ai-exchange/templates/prompts/new-project-spec-revision.md) | 推奨案を短く修正する返信 |
| [`ai-exchange/templates/prompts/new-project-spec-approval.md`](ai-exchange/templates/prompts/new-project-spec-approval.md) | 仕様確定と正式入力生成の承認 |
| [`ai-exchange/templates/prompts/new-project-spec-example-nc.md`](ai-exchange/templates/prompts/new-project-spec-example-nc.md) | `.nc`解析ツールの記入例 |

## 推奨フロー

```text
人間が3項目だけ入力
  ↓
社内AIが構想を整理
  ↓
社内AIが最大3件の推奨案付き質問
  ↓
人間が短い返信で修正・選択
  ↓
社内AIが理解を更新し、必要なら再質問
  ↓
社内AIが仕様確定案を提示
  ↓
人間が承認
  ↓
社内AIが /speckit.specify 用正式プロンプトを生成
  ↓
新規プロジェクトで Spec Kit を初期化して入力
  ↓
spec.md生成後はCopilotのプロジェクト管理フローへ移行
```

## 手入力するのは3項目だけ

1. 作りたいもの
2. 分かっている制約
3. 最初に実現したいこと

技術パッケージ、フォルダ構成、クラス設計などは最初から入力せず、社内AIの最終出力で`/speckit.plan`への引き継ぎ事項として分離します。

## Spec Kitへ渡した後

1. `/speckit.specify`で`spec.md`を生成する。
2. 生成内容を人間が確認する。
3. 必要なら`/speckit.clarify`を実行する。
4. プロジェクト管理パックを導入し、`/refresh-project-context`を実行する。
5. 以後の変更は`/request-intake`を入口にして、社内AI相談、Spec Kit、標準Agentへ振り分ける。

## 注意事項

- 社内AIの推奨案は承認前の提案です。
- 最初のFeatureへ構想全体を詰め込まないでください。
- 技術選択を利用者要求として`spec.md`へ混入させないでください。
- 実測データや実環境が利用できない場合は、成功条件と未検証事項を明確に分けてください。
