# Prompt Examples

以下はそのままコピーし、末尾だけ変更できる入力例です。

## 既存プロジェクトの依頼受付

### 機能追加

```text
/request-intake 単一.nc解析で設定した基準面範囲と摺動面範囲を、同じファイルを再度開いたときに復元したい
```

### 不具合修正

```text
/request-intake 波形表示後に範囲を変更すると、保存CSVの範囲が画面表示と一致しない問題を修正したい
```

### 技術調査

```text
/request-intake Python未導入のWindows PCへ配布する方式を社内AIに比較してもらい、planへ反映する候補を整理したい
```

### 既存構成の整理

```text
/request-intake 別プロジェクトからコピーしたnetCDF読込モジュールを正式コンポーネントとして登録し、関連テストと保守範囲を明確化したい
```

## 依頼ブリーフの修正

```text
/review-request-brief .context-work/requests/REQ-0001/request.md
ドラッグ操作は今回の必須範囲に含めます。試験前後比較は対象外としてロードマップ候補へ移してください。
```

## 社内AI用プロンプトの生成

```text
/export-approved-request-to-internal-ai .context-work/requests/REQ-0001/request.md
```

## Spec Kit内外を自動判定した変更入力

```text
/generate-approved-request-change-input .context-work/requests/REQ-0001/request.md
```

## ロードマップ

```text
/defer-feature-to-roadmap specs/001-single-file-analysis/spec.md 試験前後の自動位置合わせを後続機能へ分離
```

```text
/propose-roadmap-update feature-completed
```

```text
/review-roadmap-proposals .context-work/roadmap/proposals/RM-0001.toml
```

## README

```text
/assess-readme-update GUIの起動方法と設定保存機能が変わった
```

## 状況更新

```text
/update-project-status 設定保存・復元の単体試験が合成fixtureで成功した。実測.ncでは未検証。
```

## 悪い入力と改善例

悪い例：

```text
このプロジェクトを全部調べて改善して
```

改善例：

```text
/request-intake 設定保存機能の実装状況と未検証点を確認し、次の1段階だけ提案して
```

悪い例：

```text
全コードと全specを読んで次の機能を考えて
```

改善例：

```text
/propose-roadmap-update feature-completed
```

後者はスナップショットと今回の変更範囲から調査を絞ります。

## `/request-intake`のモードとヒント

### Quick：専門コマンドだけ返す

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
```

```text
/request-intake quick [context] プロジェクト文脈を更新したい
```

### Standard：通常の依頼受付

```text
/request-intake [feature] 同じ.ncを再度開いたとき、前回の解析範囲を復元したい
```

```text
/request-intake [bug] CSVの保存範囲がグラフ表示と一致しない
```

```text
/request-intake [research] Windows配布方式を社内AIに比較してもらいたい
```

### Deep：横断変更

```text
/request-intake deep [refactor] packages配下の2パッケージを統合し、公開APIを一本化したい
```

```text
/request-intake deep [import] 別プロジェクトの解析基盤を取り込み、既存GUIとテストへ統合したい
```

ヒント一覧：`feature`、`bug`、`research`、`refactor`、`docs`、`roadmap`、`validation`、`import`、`context`、`unknown`。
