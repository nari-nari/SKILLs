# START HERE — Project Context Pack

迷った場合は、現在の状況に最も近い入口を1つだけ使います。`/project-context-help`を毎回前段に置く必要はありません。

## 0. 初回導入後に一度だけ

```bash
python tools/project_context/refresh_project_context.py
```

これにより、Copilotが最初に読む短いスナップショットが生成されます。

```text
.project-context/generated/copilot-snapshot.md
```

## 1. 完全な新規プロジェクト

コードも文書もない最初のFeatureでは、社内AIへ次を貼ります。

```text
docs/project-context/ai-exchange/templates/prompts/new-project-spec-intake.md
```

手入力は「作りたいもの」「分かっている制約」「最初に実現したいこと」の3項目です。

## 2. 既存プロジェクトで迷った場合

通常は`/request-intake`を使います。既定は`standard`です。

```text
/request-intake [feature] 同じ.ncファイルを再度開いたとき、前回の解析範囲を復元したい
```

詳細は[`request-intake-cheatsheet.md`](request-intake-cheatsheet.md)を参照してください。

## 3. 低コストで専門コマンドだけ知りたい

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
```

Quickはスナップショットだけを読み、質問せず、`request.md`も作らず、専門コマンドを1つ返します。

## 4. 大規模・横断変更

```text
/request-intake deep [refactor] packages配下の2パッケージを統合したい
```

Deepは必ず`request.md`を作り、依存関係と段階計画を調査します。

## 5. 目的が明確なら専門コマンドを直接使う

| 目的 | 入力 |
|---|---|
| プロジェクト文脈更新 | `/refresh-project-context` |
| README整合確認 | `/assess-readme-update 設定保存機能が完成した` |
| 複雑な機能を延期 | `/defer-feature-to-roadmap <対象spec> 自動位置合わせを後続へ分離` |
| 実装後の将来候補 | `/propose-roadmap-update feature-completed` |
| 承認済み依頼の変更入力 | `/generate-approved-request-change-input <request.md>` |

## 6. 技術選定を社内AIへ相談

```text
/request-intake [research] Windows配布を考慮したGUIと設定保存方式を社内AIに比較してもらいたい
```

承認後、「社内AI相談文を生成」を選びます。

## 7. 入口そのものが分からない

まずこの文書と[`prompt-examples.md`](prompt-examples.md)を読みます。対話形式の案内が必要な場合だけ次を使います。

```text
/project-context-help 既存プロジェクトへ新しいGUI機能を追加したい
```

## 使用量を抑える基本ルール

- 専門コマンドが分かる場合は直接使う。
- 迷う場合は`/request-intake`を使い、Quick／Standard／Deepを選ぶ。
- 毎回`/project-context-help`を呼ばない。
- スナップショット→対象コンポーネント→最寄りテストの順で読む。
- 棚卸し、採番、承認検査、差分適用はPythonツールへ任せる。
