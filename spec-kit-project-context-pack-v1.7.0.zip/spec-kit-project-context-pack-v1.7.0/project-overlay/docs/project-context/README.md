# Project Context Management

このディレクトリは、**開発対象プロジェクトそのもののREADMEではなく**、プロジェクト全体の文脈・状況・AI連携を管理するための補助文書です。

- プロジェクト本体の説明、利用方法、ビルド方法はリポジトリ直下の `README.md` に記載します。
- このディレクトリは、Spec Kitで作成した機能だけでなく、手動実装、標準Agent/Planで追加した機能、他プロジェクトから流用したコンポーネントも含めて扱います。
- `specs/` は機能単位の要求・計画・タスクの正本ですが、プロジェクト全体の唯一の文脈源ではありません。

## 最初に読む

- [`START-HERE.md`](START-HERE.md): 状況別の最短手順
- [`prompt-examples.md`](prompt-examples.md): コピー可能な入力例
- [`request-intake-cheatsheet.md`](request-intake-cheatsheet.md): Quick／Standard／Deepとヒントの早見表
- [`copilot-efficient-usage.md`](copilot-efficient-usage.md): AI使用量を抑える設計と運用

## 主なファイル

| ファイル | 役割 |
|---|---|
| `START-HERE.md` | 初回導入後と日常操作の入口 |
| `prompt-examples.md` | 目的別のコピー可能な入力例 |
| `request-intake-cheatsheet.md` | `/request-intake`のモード、ヒント、作成省略条件 |
| `copilot-efficient-usage.md` | コンテキスト・AI使用量を抑える運用 |
| `status.md` | 現在地点、検証状態、ブロッカー、次の行動 |
| `roadmap.md` | Spec Kit内外を含む、承認済みの中期計画 |
| `project-map.md` | リポジトリ全体の構成、コンポーネント、由来、関連spec |
| `known-issues.md` | 横断的な既知問題 |
| `key-decisions.md` | 少数の重要な横断判断 |
| `context-governance.md` | 文脈の正本、更新、AI連携の規約 |
| `request-orchestration.md` | 既存プロジェクトで短い依頼から正式プロンプトを生成する流れ |
| `new-project-bootstrap.md` | 新規プロジェクトの最初のFeatureを社内AIとの対話で具体化する流れ |
| `roadmap-management.md` | AIによる候補発見、レビュー、承認付き昇格、次工程準備 |
| `readme-maintenance.md` | ルートREADMEの評価・承認・限定更新 |
| `ai-exchange/` | 社内AI相談テンプレートと承認済み記録 |

## 新規プロジェクトの開始

既存コードや文書がない最初のFeatureでは、[`new-project-bootstrap.md`](new-project-bootstrap.md)を参照してください。社内AIへは、作りたいもの、既知の制約、最初に実現したいことの3項目だけを入力し、推奨案付き質問と承認を経て`/speckit.specify`用入力を生成します。

## 文脈の更新

```bash
python tools/project_context/refresh_project_context.py
```

このコマンドは、Git管理下および未追跡の非無視ファイルを棚卸しし、Spec Kit成果物とそれ以外のファイルを区別して `project-map.md` と自動生成JSONを更新します。

手動・流用・生成コードなど、機械的に推定できない由来は `.project-context/components.toml` で補足します。

## Spec Kitに依存しない変更ルート

承認済み依頼から正式な変更入力を作る場合は、通常こちらを使います。

```text
/generate-approved-request-change-input .context-work/requests/REQ-0001/request.md
```

対象がSpec Kit featureでなければ、標準Agent向けのコード・テスト・文書更新指示が生成されます。

## ルートREADMEの保守

```text
/assess-readme-update
/update-project-readme .context-work/readme/updates/README-UPDATE-0001.toml
```

詳細は [`readme-maintenance.md`](readme-maintenance.md) を参照してください。

## AIによるロードマップ候補

```text
/propose-roadmap-update feature-completed
/defer-feature-to-roadmap <対象specまたは要求>
/review-roadmap-proposals
```

候補は`.context-work/roadmap/proposals/`へ保存され、正式`roadmap.md`は人間承認と決定論的な差分適用まで変更されません。詳細は[`roadmap-management.md`](roadmap-management.md)を参照してください。

