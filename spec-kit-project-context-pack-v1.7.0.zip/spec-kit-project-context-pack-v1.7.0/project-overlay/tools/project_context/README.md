# Context Pack Tools

All tools use Python 3.11+ standard library only.

- `collect_project_status.py`: counts Spec Kit task checkboxes and updates only the marked block in project status
- `build_ai_context.py`: creates a sanitized, allowlisted draft package; never transmits it
- `validate_ai_context.py`: scans a package for configured forbidden patterns
- `check_context_consistency.py`: checks required files and basic artifact structure
- `create_request.py`: creates a local `REQ-xxxx/request.md` from one short intent
- `validate_request.py`: validates request structure and optional human-approval gates

Run tools from the repository root so `.project-context/context.toml` can be discovered.

Create a request with minimal manual input:

```bash
python tools/project_context/create_request.py \
  --intent "次の開発段階と利用パッケージを社内AIに相談したい"
```

Validate an approved request before generating a downstream prompt:

```bash
python tools/project_context/validate_request.py \
  .context-work/requests/REQ-0001/request.md \
  --require-approved
```

## README maintenance

- `assess_readme_update.py`: records deterministic README review triggers and missing project-context links
- `apply_readme_update.py`: validates an Approved, section-scoped TOML proposal, shows a dry-run diff, and applies with `--apply`

The apply tool checks the current README hash, allowlisted and protected headings, and creates a local backup before writing.

## Roadmap candidates

```bash
python tools/project_context/create_roadmap_proposal.py --help
python tools/project_context/validate_roadmap_proposal.py .context-work/roadmap/proposals/RM-0001.toml
python tools/project_context/apply_roadmap_update.py .context-work/roadmap/proposals/RM-0001.toml
```

The apply command is a dry run by default. `--apply` requires an Approved proposal and creates a backup and promotion record.



## Compact Copilot snapshot

`refresh_project_context.py` invokes `build_copilot_snapshot.py` after inventory and status collection. It creates a bounded first-pass context file and a context-budget report without using an AI model.

```text
.project-context/generated/copilot-snapshot.md
.project-context/generated/copilot-context-budget.md
```
