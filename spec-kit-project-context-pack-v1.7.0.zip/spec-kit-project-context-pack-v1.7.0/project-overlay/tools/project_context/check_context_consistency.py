from __future__ import annotations

import argparse

from project_context_lib import load_config, resolve_inside

REQUIRED_ROOT_FILES = [
    "docs/project-context/README.md",
    "docs/project-context/START-HERE.md",
    "docs/project-context/prompt-examples.md",
    "docs/project-context/request-intake-cheatsheet.md",
    "docs/project-context/copilot-efficient-usage.md",
    "tools/project_context/build_copilot_snapshot.py",
    "docs/project-context/context-governance.md",
    "docs/project-context/request-orchestration.md",
    "docs/project-context/status.md",
    "docs/project-context/roadmap.md",
    "docs/project-context/project-map.md",
    "docs/project-context/known-issues.md",
    "docs/project-context/ai-exchange/README.md",
    ".project-context/templates/request-brief.md",
    ".project-context/request-intake-policy.toml",
    "tools/project_context/parse_request_intake.py",
    ".project-context/components.toml",
    ".project-context/readme-policy.toml",
    ".project-context/templates/readme-update.toml",
    "docs/project-context/readme-maintenance.md",
    "docs/project-context/new-project-bootstrap.md",
    "docs/project-context/ai-exchange/templates/prompts/new-project-spec-intake.md",
    "docs/project-context/ai-exchange/templates/prompts/new-project-spec-revision.md",
    "docs/project-context/ai-exchange/templates/prompts/new-project-spec-approval.md",
    ".project-context/templates/internal-ai-new-project-intake.md",
    ".github/skills/roadmap-management/SKILL.md",
    ".github/agents/roadmap-curator.agent.md",
    ".project-context/templates/roadmap-proposal.toml",
    ".project-context/roadmap-policy.toml",
    "docs/project-context/roadmap-management.md",
]


def main() -> int:
    argparse.ArgumentParser(description="Check deterministic project-context structure").parse_args()
    config = load_config()
    findings: list[str] = []
    for relative in REQUIRED_ROOT_FILES:
        if not resolve_inside(config.root, relative).is_file():
            findings.append(f"missing required file: {relative}")
    status_path = resolve_inside(config.root, config.project.get("status_file", "docs/project-context/status.md"))
    if status_path.is_file():
        status = status_path.read_text(encoding="utf-8")
        if "<!-- AUTO:FEATURE_STATUS:START -->" not in status or "<!-- AUTO:FEATURE_STATUS:END -->" not in status:
            findings.append("status.md is missing Spec Kit feature-status markers")
    roadmap_path = resolve_inside(config.root, config.project.get("roadmap_file", "docs/project-context/roadmap.md"))
    if roadmap_path.is_file():
        roadmap = roadmap_path.read_text(encoding="utf-8")
        for marker in (
            "<!-- AUTO:APPROVED_ROADMAP:START -->",
            "<!-- AUTO:APPROVED_ROADMAP:END -->",
            "<!-- AUTO:ROADMAP_CHANGE_LOG:START -->",
            "<!-- AUTO:ROADMAP_CHANGE_LOG:END -->",
        ):
            if marker not in roadmap:
                findings.append(f"roadmap.md is missing marker: {marker}")
    map_path = resolve_inside(config.root, config.project.get("project_map_file", "docs/project-context/project-map.md"))
    if map_path.is_file():
        project_map = map_path.read_text(encoding="utf-8")
        if "<!-- AUTO:PROJECT_INVENTORY:START -->" not in project_map or "<!-- AUTO:PROJECT_INVENTORY:END -->" not in project_map:
            findings.append("project-map.md is missing inventory markers")
    specs_dir = resolve_inside(config.root, config.project.get("specs_dir", "specs"))
    if specs_dir.is_dir():
        for feature in sorted(item for item in specs_dir.iterdir() if item.is_dir()):
            if not (feature / "spec.md").is_file():
                findings.append(f"{feature.relative_to(config.root)}: spec.md is missing")
            if (feature / "tasks.md").is_file() and not (feature / "plan.md").is_file():
                findings.append(f"{feature.relative_to(config.root)}: tasks.md exists but plan.md is missing")
    if findings:
        print("CONTEXT CHECK FAILED")
        for finding in findings:
            print(f"- {finding}")
        return 1
    print("CONTEXT CHECK PASSED")
    print("This structural check covers the whole repository and does not replace semantic review.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
