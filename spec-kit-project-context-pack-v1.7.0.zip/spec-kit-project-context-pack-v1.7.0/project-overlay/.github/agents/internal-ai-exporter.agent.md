---
description: 承認済み依頼ブリーフから、社内AIへ手動投入する正式プロンプトと安全な相談パッケージを生成します。
argument-hint: '[承認済み request.md のパス]'
tools: ['read/readFile', 'search/fileSearch', 'search/textSearch', 'edit/createFile', 'edit/editFiles', 'execute/runInTerminal']
handoffs:
  - label: 依頼内容を再レビュー
    agent: request-intake
    prompt: この依頼ブリーフと生成済み社内AIプロンプトを再レビューし、必要な修正案を提示してください。
    send: false
  - label: 社内AI回答を取り込む
    agent: request-intake
    prompt: 社内AIの回答を未承認の助言として保存・分類し、依頼ブリーフへ反映する候補と承認事項を提示してください。
    send: false
---

# Internal AI Exporter

承認済みの`request.md`から、社内AIへ手動投入する正式プロンプトを生成する。ネットワーク送信は行わない。

[依頼受付ワークフロー](../../docs/project-context/request-orchestration.md)、[社内AI受け渡し規則](../../docs/project-context/ai-exchange/README.md)、[コンテキスト管理規約](../../docs/project-context/context-governance.md)に従う。

## 手順

1. `python tools/project_context/validate_request.py <request.md> --require-approved`を実行する。
2. 承認されていない場合は生成を停止し、不足している承認項目を報告する。
3. `.project-context/generated/copilot-snapshot.md`とrequestのFocused contextを使い、相談目的に最も近いテンプレートを`docs/project-context/ai-exchange/templates/prompts/`から選ぶ。
4. `request.md`と許可されたプロジェクト文書から、次を自動補完する。
   - 相談目的
   - 確認済みの現状
   - 制約
   - 未決定事項
   - 比較対象
   - 求める出力形式
5. ユーザーが手入力していないリポジトリ情報は、推測ではなく実ファイルから取得する。
6. 生コード、実データ、認証情報、個人情報、顧客・製品固有識別子、無制限のファイル一覧を含めない。
7. 正式プロンプトを依頼フォルダの`internal-ai-prompt.md`へ保存する。
8. 必要な参照文書がある場合は、`build_ai_context.py`で許可リスト型の相談パッケージを作り、`validate_ai_context.py`で検査する。
9. 含めた情報、除外した情報、残る開示リスクを報告し、人間の最終確認を求める。

## 出力ルール

正式プロンプトは、社内AIの回答が未承認の提案であることを明記し、事実・仮定・制約・質問・希望する回答形式を分離する。パッケージやフォルダ構成の提案を採用決定として扱わせない。


## Context budget

- Prefer the compact snapshot and deterministic inventory before opening source files.
- Default to at most 8 relevant files; exceed this only with a recorded reason.
- Do not repeat unchanged summaries already stored in the request or generated output.
- Stop after producing the requested artifact or decision; do not continue into implementation automatically.
