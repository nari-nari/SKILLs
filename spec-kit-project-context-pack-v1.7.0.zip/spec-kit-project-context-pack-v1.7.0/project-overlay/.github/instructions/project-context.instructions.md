---
name: 'Project context governance'
description: 'Rules for context, request, README, roadmap, and AI-exchange artifacts.'
applyTo: 'docs/project-context/**/*.md,.project-context/**/*,.context-work/**/*'
---

# Project context governance

- Use `docs/project-context/context-governance.md` for detailed policy.
- Keep authoritative state separate from local Draft/Proposed artifacts under `.context-work/`.
- Require human approval before promoting requests, AI advice, README proposals, or roadmap proposals.
- Prefer generated inventory and snapshot files over repeated repository-wide searches.
- Distinguish implemented, test-passed, validated, accepted, and production-verified.
- Keep current summaries concise; move history to Git or approved records.
