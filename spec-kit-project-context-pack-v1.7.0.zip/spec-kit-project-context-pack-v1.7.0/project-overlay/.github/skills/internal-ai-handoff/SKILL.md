---
name: internal-ai-handoff
description: Prepare, validate, review, and record controlled exchanges with an internal AI. Use when creating a consultation package or processing an internal AI response without directly adopting it.
argument-hint: '[topic or response path]'
---

# Internal AI handoff

Read [AI exchange policy](../../../docs/project-context/ai-exchange/README.md) and [context governance](../../../docs/project-context/context-governance.md).

## Outbound consultation

1. Define one decision or question.
2. Select minimum allowlisted sources.
3. Use [`build_ai_context.py`](../../../tools/project_context/build_ai_context.py).
4. Use [`validate_ai_context.py`](../../../tools/project_context/validate_ai_context.py).
5. Require a human disclosure review before transmission.
6. Never send content automatically.

## Inbound response

1. Store raw responses in `.context-work/ai-exchange/inbox/`.
2. Treat them as unapproved advice.
3. Classify each proposal into spec, research, plan, tasks, constitution, status, defer, reject, or advice-only.
4. Create an approved review record using [response review template](../../../docs/project-context/ai-exchange/templates/response-review.md).
5. Apply only explicitly accepted proposals.
6. Run `/speckit.analyze` before implementation and relevant tests after implementation.

Do not rely solely on model-based redaction.
