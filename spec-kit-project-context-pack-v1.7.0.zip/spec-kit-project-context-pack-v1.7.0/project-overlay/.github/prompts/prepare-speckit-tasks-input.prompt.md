---
name: 'prepare-speckit-tasks-input'
description: 'Create a ready-to-paste /speckit.tasks input that preserves existing completion history and covers approved plan changes.'
argument-hint: '[feature path and changed plan scope]'
agent: 'ask'
---

Read the target feature's current `spec.md`, `research.md`, `plan.md`, and `tasks.md`.

Create a ready-to-paste `/speckit.tasks` input that:

- states whether this is a new generation or a partial update
- preserves completed task boxes and IDs during partial updates
- adds corrective tasks instead of rewriting completed history
- maps tasks to requirements or plan decisions
- names target files/directories, dependencies, validation, and completion conditions
- includes dependency setup, migration, imports, tests, packaging, license/offline checks, documentation, and project-status updates when relevant
- excludes implementation work from the task-generation step

End by requiring `/speckit.analyze` before implementation.
