---
name: 'prepare-speckit-plan-input'
description: 'Create a ready-to-paste /speckit.plan input from an approved specification and reviewed technical proposals.'
argument-hint: '[feature path and approved review record]'
agent: 'ask'
---

Read the target `spec.md`, constitution, current repository structure, existing dependencies, and the approved review record.

Create a ready-to-paste `/speckit.plan` input containing:

- current language/version, platform, test/build environment, and distribution constraints
- existing dependencies and interfaces that must be preserved
- approved package, architecture, data model, module, and folder proposals
- unresolved options that must go to `research.md`
- license, offline availability, security, performance, and maintenance constraints
- validation method for each important technical decision
- explicit instructions not to change `spec.md` or implement code

Separate Accepted, Accepted with modification, Investigate, and Rejected proposals. Require the agent to inspect the actual repository before finalizing the documented structure.
