---
name: 'export-approved-request-to-internal-ai'
description: '承認済み依頼から、社内AIへ手動投入する正式プロンプトを生成します。'
argument-hint: '[承認済み request.md のパス]'
agent: 'internal-ai-exporter'
---

指定された承認済み`request.md`を検証し、依頼フォルダに`internal-ai-prompt.md`を生成してください。

社内AIへの送信は行わないでください。必要なプロジェクト情報は許可された文書から自動補完し、機密性検査と人間の開示確認を要求してください。
