---
name: 'import-internal-ai-response-to-request'
description: '社内AI回答を未承認の助言として依頼へ取り込み、採否案を提示します。'
argument-hint: '[request.md と社内AI回答ファイルのパス]'
agent: 'request-intake'
---

社内AI回答を依頼フォルダの`internal-ai-response.md`として扱い、未承認の助言として分類してください。

- spec、research、plan、tasks、constitution、status、defer、reject、advice-onlyへ分類する。
- 現在の正本、制約、実装、テストと比較する。
- Accept、Accept with modification、Investigate、Defer、Rejectを提案する。
- 人間が承認するまでSpec Kit成果物やコードへ反映しない。
- `request.md`の提案・未決定事項・推奨ルートを更新し、再承認を求める。
