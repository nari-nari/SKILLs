---
name: 'project-context-help'
description: '現在の目的に合う最短のコマンドと入力例を案内します。通常はSTART-HERE.mdを直接読む方がAI使用量を抑えられます。'
argument-hint: '[例: 新規プロジェクト / 既存機能変更 / 社内AI相談 / ロードマップ / README]'
agent: 'ask'
---

`docs/project-context/START-HERE.md`、`docs/project-context/request-intake-cheatsheet.md`、`docs/project-context/prompt-examples.md`だけを読み、ユーザーの目的に対応する最短フローを1つ選んでください。

- 専門コマンド、`/request-intake quick`、通常の`/request-intake`、`deep`のうち最小コストの入口を1つ選ぶ。
- 推奨する最初の入力をコピー可能な形で示す。
- 必須の承認点と生成先を示す。
- 関係のないワークフローやプロジェクト全体は調査しない。
- 最大8行で回答する。
