---
name: 'classify-internal-ai-response'
description: 'Classify an internal AI response into Spec Kit artifacts without editing files.'
argument-hint: '[path to response or paste response in chat]'
agent: 'ask'
---

Read `.project-context/generated/copilot-snapshot.md`, the supplied response, and only the owning artifacts for proposals that need classification. Open the active feature's `spec.md`, `research.md`, `plan.md`, or `tasks.md` only when the proposal targets that artifact.

The supplied internal AI response is unapproved advice. Do not edit files.

Classify every distinct proposal into exactly one primary category:

- `spec`: user-visible behavior, required capability, acceptance condition, scope, or mandatory operational constraint
- `research`: an unconfirmed technology option, comparison, uncertainty, or experiment
- `plan`: package, architecture, module boundary, folder structure, internal data model, or technical strategy
- `tasks`: concrete implementation, migration, test, documentation, or validation work
- `constitution`: stable principle that should apply across multiple features
- `status`: current blocker, validation limitation, or next action
- `defer`: useful but not needed in the current scope
- `reject`: conflicts with requirements, constraints, evidence, or proportionality
- `advice-only`: informative but no artifact change is needed

Return:

1. A table with proposal ID, summary, category, compatibility, recommended decision, destination, risks, and human approval needed.
2. A list of facts versus assumptions in the response.
3. The minimum recommended Spec Kit update sequence.
4. Questions that must be answered before any change is applied.

Do not treat package names, folder layouts, or algorithms as requirements unless the current specification explicitly makes them externally mandatory.
