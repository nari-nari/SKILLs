---
name: 'apply-approved-plan-change'
description: 'Apply approved technology, package, architecture, or folder-structure changes to plan.md and research.md.'
argument-hint: '[approved review record and feature path]'
agent: 'agent'
---

Read the approved review record, target `spec.md`, existing `research.md` if present, `plan.md`, constitution, and current code structure.

Apply only accepted technical proposals.

- Put undecided comparisons, alternatives, risks, and PoC needs in `research.md`.
- Put accepted language, dependencies, architecture, module boundaries, folder structure, data model, testing strategy, platform, and constraints in `plan.md`.
- Confirm the proposed structure against the actual repository before documenting it.
- Preserve unrelated accepted decisions.
- Do not edit `spec.md`, `tasks.md`, or code.
- For new dependencies, record license, platform support, offline availability, maintenance risk, and validation method when known.
- Mark unknown facts as unknown; do not invent package compatibility or approval status.

Report the exact downstream task changes that will be required.
