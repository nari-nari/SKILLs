---
name: 'pre-implementation-gate'
description: 'Read-only implementation readiness review across spec, plan, tasks, status, and approved AI records.'
argument-hint: '[feature path or task IDs]'
agent: 'ask'
---

Perform a read-only readiness review.

Check:

- every changed requirement has a corresponding accepted plan and task coverage
- no task introduces unapproved user-visible behavior
- new packages and folder changes have setup, migration, testing, and compatibility tasks
- completed tasks are not contradicted by the current plan
- blockers and unavailable validation are represented honestly
- unapproved internal AI advice has not entered the artifacts
- the requested implementation scope is explicit and bounded

Return findings by severity with artifact, location, issue, authoritative artifact to fix, and recommended action. End with one verdict: Ready, Conditionally ready, or Not ready. Do not edit files.
