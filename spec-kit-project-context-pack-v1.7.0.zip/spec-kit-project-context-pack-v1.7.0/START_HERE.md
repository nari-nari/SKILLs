# START HERE

## 1. 対象プロジェクトへ導入

```bash
python install.py /path/to/target-project
cd /path/to/target-project
python tools/project_context/refresh_project_context.py
```

## 2. 対象プロジェクトで案内を開く

```text
docs/project-context/START-HERE.md
```

## 3. 既存プロジェクトの通常依頼

```text
/request-intake [feature] 同じ.ncファイルを再度開いたとき、前回の解析範囲を復元したい
```

## 4. 専門コマンドだけ知りたい

```text
/request-intake quick [docs] READMEに設定保存機能を反映したい
```

## 5. 大規模・横断変更

```text
/request-intake deep [refactor] packages配下の2パッケージを統合したい
```

## 6. コードも文書もない新規プロジェクト

Copilotではなく、社内AIへ次のテンプレートを貼ります。

```text
docs/project-context/ai-exchange/templates/prompts/new-project-spec-intake.md
```
