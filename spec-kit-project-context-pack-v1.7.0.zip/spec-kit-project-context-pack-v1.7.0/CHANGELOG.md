# Changelog

## 1.7.0 — Staged request intake and low-cost specialist routing

- Added Quick, Standard, and Deep modes to `/request-intake`.
- Added optional request hints for feature, bug, research, refactor, docs, roadmap, validation, import, context, and unknown.
- Added deterministic `parse_request_intake.py` and `.project-context/request-intake-policy.toml` so mode/hint parsing and common direct routes do not consume AI tokens.
- Changed Standard intake to skip `request.md` for narrow deterministic operations and create it only for behavior, multi-component, ambiguous, technical-choice, or approval-sensitive changes.
- Added intake metadata to request briefs and `create_request.py`.
- Added a copy-ready request-intake cheat sheet and expanded prompt examples.
- Clarified that static help is preferred and `/project-context-help` is optional rather than a mandatory router.
- Added automated routing, metadata, structure, and documentation tests.

## 1.6.0 — Copilot context efficiency and guided usage

- Shortened always-on Copilot instructions and moved detailed rules to path-scoped instruction files.
- Added deterministic compact `copilot-snapshot.md` and context-budget reports.
- Updated agents and key prompts to start from the snapshot and default to at most eight relevant files.
- Scoped each custom agent to the minimum built-in read/search/edit/execute tools and excluded web/browser/MCP tools by default.
- Added Focused context sections to request briefs for downstream reuse.
- Added `START-HERE.md`, a prompt example cookbook, and Copilot-efficient usage guidance.
- Added an optional `/project-context-help` command that reads only the help documents.
- Added automated tests for instruction size, snapshot limits, and documentation/examples.

## 1.5.0

- Added AI-assisted roadmap candidate discovery from deferred scope, implementation/verification gaps, known issues, dependencies, and approved internal-AI research.
- Added `.project-context/roadmap-policy.toml` and structured `RM-xxxx.toml` proposal files.
- Added proposal validation with evidence, confidence, complexity, priority, route, management type, verification, approval, and stale-roadmap checks.
- Added deterministic dry-run and approval-gated roadmap promotion with backups and promotion records.
- Added roadmap-curator custom agent, roadmap-management skill, and prompts for discovery, deferral, review, preview, application, and next-step generation.
- Added request-intake handoff for future roadmap candidates without forcing them into the current Spec Kit feature.
- Added roadmap management documentation and structural checks.
- Added three roadmap workflow tests; total automated tests increased to 18.

## 1.4.0

- Added an internal-AI-first bootstrap flow for the first feature of a new project.
- Added a long-form intake template requiring only three short human inputs.
- Added recommendation-backed clarification rules with a maximum of three questions per round.
- Added short revision and final approval reply templates.
- Added an `.nc` surface-profile analysis example.
- Added `new-project-bootstrap.md` and a convenient copy under `.project-context/templates/`.
- Extended structural checks to require the new bootstrap templates.
- Removed Python cache artifacts from the distributable package.

## 1.3.0

- Added approval-gated maintenance for the target repository root `README.md`.
- Added `.project-context/readme-policy.toml` with managed sections, protected sections, review triggers, and expected context links.
- Added deterministic README assessment output under `.project-context/generated/`.
- Added Draft/Approved TOML proposal workflow under `.context-work/readme/updates/`.
- Added stale-proposal protection using the current README SHA-256.
- Added dry-run unified diff, exact-heading scoped updates, protected-section rejection, and local backups.
- Added `/assess-readme-update` and `/update-project-readme` prompt files.
- Added the `project-readme-maintenance` Agent Skill and README maintenance documentation.
- Extended `refresh_project_context.py` to assess README review triggers.
- Added README maintenance tests.

## 1.2.0

- Separated the distributable pack from the target-project overlay.
- Added safe installer behavior that preserves the target root README.
- Added repository-wide inventory covering Spec Kit and non-Spec-Kit files.
- Added component provenance registry and non-Spec-Kit change routing.

## 1.1.0

- Added short-request intake, approval gates, handoffs, and formal prompt generation.

## 1.0.0

- Initial Spec Kit, project status, and internal-AI integration pack.
