# Project Bootstrap Review

## 検出したProject概要

Proposed purpose:
<日本語で記述>

## 検出したCapabilities

- <現在確認できるCapability>

## Proposed Constraints

- <候補>

## Proposed Non-goals

- <候補>

## Proposed Success Criteria

- <候補>

## Proposed Roadmap

Current candidate: None
Next candidates: None
Later candidates: None
Backlog candidates: None

## Existing Feature Artifacts

Specification: None
Plan: None
Tasks: None
Evidence: None

## Active Work Candidate

Feature: None
Proposed initial state: READY

Evidence:
- <現在確認できる根拠。推測と事実を区別する。>

## Decisions

Explicit historical decisions found:
None

Unknown rationale that will NOT be reconstructed:
None

## Human確認が必要な事項

- <Purpose、Constraints、Roadmap、Active Feature、baseline approval等>

## 生成予定ファイル

- `docs/project/PROJECT.md`
- `docs/project/ROADMAP.md`
- `docs/project/STATUS.md`
- `docs/project/DECISIONS.md`
