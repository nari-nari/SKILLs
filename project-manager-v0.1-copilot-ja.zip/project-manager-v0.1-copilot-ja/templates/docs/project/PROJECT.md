# プロジェクト (Project)

## 目的 (Purpose)

<このProjectが存在する理由を日本語で1〜3段落にまとめる。>

## 現在の能力 (Capabilities)

- <Human accepted済みで、現在実際に利用可能な主要Capability>

## 制約 (Constraints)

- <将来のFeatureでも継続して守る必要がある重要な技術・運用・環境制約>

## 非目標 (Non-goals)

- <このProjectでは意図的に対象外とすること。単にv0.1で未実装というだけの事項は原則ここに置かない。>

## 成功条件 (Success Criteria)

- <Project全体として成功とみなす高レベルな条件>
