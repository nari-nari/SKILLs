# プロジェクトロードマップ (Project Roadmap)

## Current（現在）

None

## Next（次候補）

None

## Later（将来候補）

None

## Backlog（バックログ）

None

## Completed（完了）

None

<!-- Feature entry example
### F-001 — <Feature名>

Status: ACTIVE
Priority: HIGH
Depends on: None

Goal:
<このFeatureで実現したいことを日本語で記述>

Success:
<高レベルな成功条件を日本語で記述>

Reason for order:
<この順番にする理由。Nextで必要な場合のみ>
-->
