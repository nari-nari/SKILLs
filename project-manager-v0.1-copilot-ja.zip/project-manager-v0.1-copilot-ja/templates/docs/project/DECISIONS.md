# プロジェクト判断 (Project Decisions)

まだProject Manager初期化後の正式なProject-level Decisionは記録されていません。

<!-- Decision entry example
## D-001 — <判断タイトル>

Status: ACTIVE
Date: <YYYY-MM-DD>
Scope: PROJECT
Related features: None

### 判断 (Decision)

<何を決めたかを簡潔に日本語で記述>

### 背景 (Context)

<なぜこの判断が必要になったか>

### 理由 (Rationale)

<なぜこの選択肢を採用したか>

### 影響 (Consequences)

- <このDecisionによって生じる重要な効果・制約・コスト>

### 再検討条件 (Revisit Condition)

<どの条件になったら再検討するか。なければNone>

### Supersedes

None

### Superseded by

None
-->
