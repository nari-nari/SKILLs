# Feature

## Identity

ID: <F-xxx>
Name: <Feature名>

## Artifacts

Specification: <repository-root-relative path>
Plan: None
Tasks: <repository-root-relative path>
Evidence: <repository-root-relative path>

## Specification Approval

Approved at: None
Approved revision: None

## Notes

None
