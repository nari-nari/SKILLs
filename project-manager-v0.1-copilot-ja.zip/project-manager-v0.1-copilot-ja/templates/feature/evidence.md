# Feature Evidence

## Feature

ID: <F-xxx>
Updated: <ISO-8601 timestamp>

## 検証サマリー (Verification Summary)

Status: NOT_RUN
Tasks verified: 0 / 0
Feature-level verification: NOT_RUN
Known limitations: 0

## Task Evidence

None

<!-- Task evidence example
### T-001

Status: PASS

Verification:
- `<実行したtest/build/compiler command>`

Result:
<結果を日本語で簡潔に記述>
-->

## Feature-Level Verification

Status: NOT_RUN

Checks:
- <check>: NOT_RUN

Result:
まだFeature-level verificationは実行されていない。

## Known Limitations

None

<!-- Limitation example
### L-001

Description:
<未検証事項または制約を日本語で記述>

Impact:
<影響>

Resolution:
<将来の解除方法>

Blocking acceptance: No
-->

## Human Acceptance

Status: PENDING
Decision at: None
Reason: None

## Notes

None
