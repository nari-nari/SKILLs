---
name: project-update
description: Human accepted FeatureのProject-level反映、archive、ROADMAP finalization、READY復帰、またはDEFER/CANCELの確定を行うSkill。Project-level Stateの更新や整合性repairに使用する。
---

# Project Update

## 目的

Feature outcomeをProject-level Stateへ安全に反映し、ライフサイクルを確定します。

## 通常完了時のEntry condition

Human accepted Featureを完了させる場合、次をすべて満たす必要があります。

- `STATUS.md` State = `ACCEPTANCE_PENDING`
- `evidence.md` Human Acceptance = `ACCEPTED`
- Feature-Level Verification = `PASS`
- `Blocking acceptance: Yes` のKnown Limitationがない

満たさない場合はProject completionを実行せず、矛盾を報告します。

## Project impact analysis

Accepted Featureが次を変更したか判定します。

- Current Capabilities
- Project Constraints
- Roadmap
- 長期的なProject Decisions

影響のないProject artifactは変更しないでください。

## PROJECT.md

Accepted Featureによって現在のProject定義が変化した場合だけ更新します。

Human acceptanceから明白に導かれる新しいCapabilityの追加は自動反映可能です。

次の意味的変更には明示的Human approvalが必要です。

- Purpose
- Constraints
- Non-goals
- Success Criteria

Constraintを黙って削除してはいけません。

## DECISIONS.md

将来のFeatureやAgentにも意味を持つ判断だけを記録します。

実装上の細かな判断や一時的なworkaroundをProject Decisionとして残さないでください。

既存Decisionの意味を変更する場合、本文を書き換えず、新しいDecisionを追加して旧Decisionを `SUPERSEDED` にします。

## Human accepted Featureのfinalization

順序を守ってください。

1. PROJECT / DECISIONSへのsemantic propagationを必要な範囲で完了する。
2. `STATUS.md` を `ACCEPTANCE_PENDING -> COMPLETED` にする。この時点ではRoadmap Currentを維持する。
3. Project Manager所有のFeature artifactをarchiveする。外部管理のSpecification / Plan / Tasksは勝手に移動しない。
4. `ROADMAP.md` でCurrent FeatureをCompletedへ移す。
5. `STATUS.md` を最後に `COMPLETED -> READY` にする。
6. Active FeatureをNoneにし、Next ActionをRoadmap review / 次Feature選択にする。
7. postconditionを検証する。

Nextの先頭Featureを自動でCurrentへ昇格させないでください。

## DEFER / CANCEL

Active FeatureのDEFERまたはCANCELが人間によって明示的に決定された場合、次を行います。

- Roadmap Currentから外す。
- Backlogへ戻す。
- `Disposition: DEFERRED` または `Disposition: CANCELLED` を記録する。
- Reasonとarchive locationを記録する。
- Project Manager所有artifactをarchiveする。
- `STATUS.md` を `READY` に戻す。

Deferred Featureを将来再開する場合、同じFeature IDを使用し、`FEATURE_SELECTED`から再開してSpecificationの有効性を再確認します。

## Repair

複数artifactの不整合を修復するときは、強い正本を優先し、logical transactionとして修復します。

特に、非READY Stateでは `STATUS.md` Active Featureと `ROADMAP.md` Currentが一致していなければなりません。
