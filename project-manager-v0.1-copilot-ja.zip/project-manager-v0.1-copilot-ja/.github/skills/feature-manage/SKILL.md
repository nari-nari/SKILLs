---
name: feature-manage
description: Active Featureの選択、Specification承認、実装、Task verification、BLOCKED復旧、Feature-level verification、acceptance rejectionを管理するSkill。Featureを開始・継続・実装・test・解除・レビューするときに使用する。
---

# Feature Manage

## 目的

Project-level状態機械とVerification Evidenceを維持しながら、1つのActive Featureを管理します。

## このSkillが担当するState遷移

- `READY -> FEATURE_SELECTED`
- `FEATURE_SELECTED -> APPROVED`
- `APPROVED -> IMPLEMENTING`
- `IMPLEMENTING -> ACCEPTANCE_PENDING`
- Human rejection後の `ACCEPTANCE_PENDING -> IMPLEMENTING`
- 適格なActive State `-> BLOCKED`
- `BLOCKED ->` 適切な復帰State

`COMPLETED`への遷移は行いません。Human accepted Featureのfinalizationは `project-update` が担当します。

## Feature選択

`STATUS.md` が `READY` の場合のみ実行できます。

変更前に次を確認します。

- `ROADMAP.md` のCurrentが空。
- `STATUS.md` のActive FeatureがNone。
- 選択Feature IDがNext / Later / Backlogのいずれかに1回だけ存在する。
- declared dependencyがすべてCompleted。

その後、1つのlogical transactionとして次を行います。

1. 選択FeatureをRoadmap Currentへ移す。
2. Project Manager所有のfeature directoryを作成または復元する。
3. templateを使って `feature.md` を作成または更新する。
4. 最後に `STATUS.md` を `FEATURE_SELECTED` へ更新する。
5. Roadmap CurrentとStatus Active Featureが一致することを検証する。

Nextの先頭にあるという理由だけで、自動的にFeatureを選択しないでください。

## Specification approval

AgentはSpecificationを作成・確認できますが、承認はできません。

ユーザーが明示的に承認した後だけ、次を実行します。

1. 現在のSpecification artifactの安定したfingerprintを計算する。原則 `sha256:<hex>` を使用する。
2. approval timestampとfingerprintを `feature.md` に記録する。
3. `STATUS.md` を `APPROVED` へ更新する。
4. 承認された仕様が将来にも再利用されるProject-level判断を新たに確定した場合だけDecision候補として扱う。

### Specificationの意味的変更

実装開始前・実装継続前にSpecification fingerprintを再計算します。

現在のfingerprintが `Approved revision` と異なり、requirementsまたはacceptance criteriaに意味的変更がある場合は次を行います。

1. 実装を停止する。
2. 有効なapprovalをpending扱いへ戻す。過去履歴はversion controlに残す。
3. `FEATURE_SELECTED` へ戻す。
4. Pending Human Actionを `FEATURE_APPROVAL` にする。
5. 明示的な再承認を要求する。

formattingだけの変更など、requirementsとacceptance criteriaが変わっていないと信頼して判定できる場合は再承認不要です。

## 実装準備

artifact pathは `feature.md` から取得します。

実装前に必須なのは次です。

- Specificationが存在する。
- Tasks artifactからTask ID、completion state、descriptionを判定できる。
- Evidence artifactが存在する。

Planはoptionalです。

## Task実行ループ

各実行可能Taskについて次を行います。

1. 関連するSpecification / Plan / Task / source / existing evidenceだけを読む。
2. Taskを実装する。
3. Taskに要求されるverificationを実行する。
4. FAILしても安全な修正が可能なら修正し、再verificationする。
5. required verificationがPASSした後だけ次を行う。
   - `evidence.md` にPASSを記録する。
   - Taskをcompleteにする。
   - `STATUS.md` のProgressとLast Verified Stateを更新する。
6. per-task Human approvalを要求せず、次の実行可能Taskへ進む。

最初の実装Taskを開始するとき `APPROVED -> IMPLEMENTING` とします。

## Evidence conflict rule

artifactが矛盾する場合、次の優先順位を使います。

1. 現在再現可能なtest / build / compiler結果
2. `evidence.md`
3. Tasks completion state
4. `STATUS.md` summary

下位artifactを上位Evidenceに合わせてrepairしてください。

## Blocker判定

通常の失敗で、安全に調査・修正できる場合は `BLOCKED` にしません。

Active Featureについて安全かつ意味のあるNext Actionが1つもなくなった場合だけ `BLOCKED` にします。

Blockerには必ず次を含めます。

- Category: `AUTO_RESOLVABLE`, `HUMAN_DECISION`, `EXTERNAL_DEPENDENCY`, `SCOPE_OR_SPEC`
- Description
- Impact
- Resolution options
- Recommended resolution
- Unblock condition
- Blocked from
- Expected resume state
- Next action

1つのTaskだけが止まっていても独立した有用作業が残る場合、global `BLOCKED`へ移行せず、現在のActive Stateを維持します。

## Blocker解除

Unblock conditionを満たした後は、内容に応じて次へ戻します。

- 単純解消: Expected resume stateへ戻る。
- Specification再作業: `FEATURE_SELECTED` または必要に応じて `APPROVED`。
- Scope再検討: 原則 `FEATURE_SELECTED`。
- DEFER / CANCEL判断: finalizationを `project-update` に渡す。

将来Featureにも影響する判断が確定した場合は、明示的Human decisionを根拠にProject-level Decisionへ昇格させます。

## Feature-level verification

required Tasksがすべてcompleteになった後、次を行います。

1. 必要なregression / integration / compiler等のFeature-level checkを実行する。
2. Specificationのacceptance criteriaを確認する。
3. `evidence.md` のFeature-Level Verificationを更新する。
4. Known Limitationsを確認する。
5. `Blocking acceptance: Yes` が1件でもあれば先へ進まない。

すべてのrequired verificationがPASSしたら、次を行います。

1. Verification Summaryを `PASS` にする。
2. Human Acceptanceを `PENDING` にする。
3. `STATUS.md` を `ACCEPTANCE_PENDING` にする。
4. Pending Human Actionを `FEATURE_ACCEPTANCE` にする。

## Acceptance rejection

ユーザーがFeatureをrejectした場合は次を行います。

1. `evidence.md` に `REJECTED` と理由を記録する。
2. 必要なTaskをreopenまたは追加する。
3. `ACCEPTANCE_PENDING -> IMPLEMENTING` とする。
4. 再acceptance review可能になった時点でHuman Acceptanceを `PENDING` に戻す。過去のreject履歴はversion controlで保持する。
5. implementation / verification loopを続ける。
