---
name: external-ai-handoff
description: Project Stateを変更せず、外部の高性能AIへ相談するための簡潔なcontext packageを生成するSkill。architecture、roadmap、specification、implementation planning、難しい技術判断の相談に使用する。
---

# External AI Handoff

## 目的

Repositoryで管理されたProject Stateから、外部AIへ渡すための必要最小限でreview可能なcontext packageを作成します。外部AIはAdvisorでありProject Stateのauthorityではありません。

## Read strategy

必ず検討するもの:

- `docs/project/PROJECT.md`
- `docs/project/STATUS.md`

必要な場合だけ読むもの:

- `docs/project/ROADMAP.md`
- `docs/project/DECISIONS.md` の関連entry
- Active `feature.md`
- Specification
- Plan
- Tasks
- `evidence.md`

存在するという理由だけで無関係artifactを含めないでください。

## 出力構造

相談内容に必要なものだけを日本語で含めます。

1. ProjectのPurpose
2. 関連するCurrent Capabilities
3. 関連するConstraints / Non-goals
4. Current StateとNext Action
5. 関連するRoadmap context
6. Active FeatureとGoal
7. 関連するProject Decisions
8. Verified factsとEvidence summary
9. Known Limitations / unresolved questions
10. 外部AIへ求める具体的なQuestion / Decision / Deliverable

## Confidentialityとminimization

source fileやrepository全体を自動的に貼り付けないでください。

要約を優先し、必要最小限のexcerptまたはartifact内容だけを含めます。

Repositoryで定義された機密情報、export、sanitization ruleがあれば必ず適用します。

安全にexportできるか判断できない情報は、推測で含めずHuman review対象として示します。

## Write restriction

次の正本を変更しないでください。

- `PROJECT.md`
- `ROADMAP.md`
- `STATUS.md`
- `DECISIONS.md`
- `feature.md`
- `evidence.md`
- Specification
- Plan
- Tasks

書き込みはhandoff artifactだけに限定します。ユーザー指定pathがなければ、repository policy上許可される場合に `docs/project/handoffs/external-ai-handoff.md` を使用します。

## 外部AI回答の扱い

外部AI回答は助言です。

回答内容をProject Stateへ直接適用してはいけません。recommendationをproposalとして評価し、Project State、Evidence、Human authorityと照合したうえで、採用する場合も通常のFeatureまたはproject-update lifecycleへ戻します。
