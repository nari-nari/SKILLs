---
name: project-navigate
description: Projectの現在地、検証済み進捗、Blocker、人間待ち、次の推奨Actionを確認するためのread-only Skill。"次に何をするか"、"現在の状況"、作業再開時に使用する。
---

# Project Navigate

## 目的

Project Stateを変更せずに、現在どこまで進んでいるかと次に行うべきActionを判定します。

## 手順

1. `docs/project/STATUS.md` を読む。
2. `State` が許可された値か確認する。
3. `Next Action` の妥当性確認に必要なartifactだけを追加で読む。
4. 次を日本語で簡潔に報告する。
   - 現在のState
   - Active Feature
   - 検証済み進捗
   - BlockerまたはPending Human Action
   - 次の推奨Action

## State別routing

- `READY`: `ROADMAP.md` を読み、dependencyを満たす次Feature候補を示す。
- `FEATURE_SELECTED`: Specification作成中か、Specification approval待ちかを判定する。
- `APPROVED`: Plan / Tasksが実装開始可能か確認する。
- `IMPLEMENTING`: Tasksと`evidence.md`から次の未検証Taskを特定する。
- `BLOCKED`: Blocker、解除候補、推奨解除策、Unblock condition、Expected resume stateを説明する。
- `ACCEPTANCE_PENDING`: Human acceptanceに必要なEvidenceを説明する。
- `COMPLETED`: archive / finalizationを次Actionとして示す。

## 制約

このSkillはread-onlyです。

次を編集しないでください。

- `PROJECT.md`
- `ROADMAP.md`
- `STATUS.md`
- `DECISIONS.md`
- source code

Project artifact間の矛盾を検出した場合は、黙って修正せず、矛盾内容と推奨repair操作を説明してください。
