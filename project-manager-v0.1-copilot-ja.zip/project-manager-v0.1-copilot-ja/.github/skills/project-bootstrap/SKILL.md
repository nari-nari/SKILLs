---
name: project-bootstrap
description: 新規または既存repositoryへProject Manager v0.1を初期導入するSkill。既存artifactを調査し、baseline候補を作成し、Human Baseline Approval後にProject Stateを生成する。
---

# Project Bootstrap

## 目的

Project Stateが存在しないrepositoryから、検証済みのProject Manager baselineを構築します。

Bootstrapは通常の7-Stateライフサイクルの外側で行います。

## Trigger

次の場合に使用します。

- `docs/project/STATUS.md` が存在しない。
- ユーザーが明示的にProject Manager初期化を要求した。
- 不完全な初期化状態をrepairする必要がある。

通常運用中のProject State repairには原則 `project-update` を使用します。

## Phase 1: Discover

まず高レベルartifactを優先して調査します。

- README / docs
- 既存Specification
- Plan / Tasks
- build / test設定
- `.github/copilot-instructions.md`、`AGENTS.md`、README等のProject instructions
- 主要directory構造

必要がない限りsource全体を無差別に走査しないでください。

## Phase 2: Infer

情報を次の3種類に分けます。

1. 直接確認できた事実
2. Project baseline候補としての推定
3. Human confirmationが必要な事項

次は推定してはいけません。

- 過去のHuman approval
- 過去のHuman acceptance
- 文書化されていない歴史的なDecision rationale
- 再現できない過去verificationのPASS

## Phase 3: Draft

Project State正本を直接確定する前に `docs/project/BOOTSTRAP_REVIEW.md` を作成します。

最低限、次を提示します。

- Proposed Purpose
- Detected Capabilities
- Proposed Constraints
- Proposed Non-goals
- Proposed Success Criteria
- Proposed Roadmap
- Existing Feature Artifacts
- Active Work Candidate
- Proposed initial State
- Explicit historical Decisions found
- Unknown rationale
- Human confirmation items

本文は日本語で記述します。固定enumやIDは英語のままにします。

## Phase 4: Baseline approval

Human Baseline Approvalを要求します。

この承認なしに、推定したPurpose、Roadmap、Active Feature等を正式なProject Stateとして確定しないでください。

既存の開発中Featureを取り込む場合、過去に承認されたと推定するのではなく、Bootstrap時点で現在のSpecificationをbaselineとして承認するか確認します。

## Phase 5: Commit

Baseline approval後、必要に応じて次を生成します。

- `docs/project/PROJECT.md`
- `docs/project/ROADMAP.md`
- `docs/project/STATUS.md`
- `docs/project/DECISIONS.md`
- Active Featureの `feature.md`
- 再現可能な検証に基づく `evidence.md`

過去Featureを無理にF-001から再構築しないでください。Bootstrap以前に完了済みのものは、原則としてCurrent Capabilityとして取り込みます。

## Phase 6: Validate

初期化完了前に次を検証します。

- `State` が許可値。
- `READY`ならActive FeatureとRoadmap Currentが空。
- 非READYならActive FeatureとRoadmap Currentが一致。
- Feature IDの重複がない。
- Current FeatureのdependencyがCompleted。
- `feature.md` のartifact pathがrepository-root-relativeで有効。
- `BLOCKED`なら復旧情報が完全。
- `Next Action`が存在する。

すべて満たした後だけ初期化完了とします。

## 禁止事項

- 存在しない歴史を作らない。
- 過去approval timestampを捏造しない。
- 根拠のないDecision rationaleを作らない。
- 現在再現できないtestをPASSとして記録しない。
- 既存Project管理ファイルを理由なく上書きしない。
