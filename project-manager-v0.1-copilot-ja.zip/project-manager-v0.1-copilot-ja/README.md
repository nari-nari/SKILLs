# Project Manager v0.1 for GitHub Copilot — 日本語版

GitHub Copilot向けの軽量なrepository-level Project Manager v0.1です。

人間が読むProject管理Markdownは原則日本語で生成します。一方、軽量モデルでも状態機械を安定して扱いやすいよう、`READY`、`IMPLEMENTING`、`BLOCKED`、`PASS`、`F-001`などの固定enum・ID・機械的field valueは英語表記を維持します。

## 構成

```text
.github/
├── agents/
│   └── project-manager.agent.md
└── skills/
    ├── project-bootstrap/SKILL.md
    ├── project-navigate/SKILL.md
    ├── feature-manage/SKILL.md
    ├── project-update/SKILL.md
    └── external-ai-handoff/SKILL.md

templates/
├── docs/project/
│   ├── PROJECT.md
│   ├── ROADMAP.md
│   ├── STATUS.md
│   ├── DECISIONS.md
│   └── BOOTSTRAP_REVIEW.md
└── feature/
    ├── feature.md
    └── evidence.md

PROJECT_MANAGER_V0.1_SPEC_JA.md
```

## 導入方法

### 1. Agent / Skillsをrepositoryへコピー

このpackageの`.github/agents/`と`.github/skills/`を対象repositoryの`.github/`へコピーします。

既存の`.github/agents/`や`.github/skills/`がある場合はdirectoryを丸ごと上書きせず、内容をmergeしてください。

`templates/`は参照用です。特に初期化前に`templates/docs/project/STATUS.md`をそのまま`docs/project/STATUS.md`へコピーすると「初期化済み」と判定されるため、通常は`project-bootstrap`に生成させてください。

### 2. Copilotで`project-manager` Agentを選択

最初は例えば次のように依頼します。

```text
このrepositoryにProject Manager v0.1を初期化してください。
Project管理Markdownは日本語で作成してください。
```

Project Stateが存在しなければ`project-bootstrap` workflowへ進みます。

### 3. Bootstrap Review

既存repositoryでは、まず`docs/project/BOOTSTRAP_REVIEW.md`に現在確認できるPurpose、Capabilities、Constraints、Roadmap候補、Active Work候補等をまとめます。

AIが過去のapprovalやDecision rationaleを推測して正式化することは禁止しています。Human Baseline Approval後に正式なProject Stateを作成します。

## 通常利用

短い指示で利用できます。

```text
現在の状況を教えてください。
```

```text
次に進んでください。
```

```text
このFeatureの実装とtestを続けてください。
```

```text
BLOCKEDの解除方法を整理してください。
```

```text
外部AIに相談するためのhandoffを生成してください。
```

`project-manager`は`STATUS.md`を最初に読み、現在Stateに応じて必要なSkillへroutingします。

## 日本語化ルール

原則日本語:

- Markdownの見出し・本文
- Purpose / Goal / Rationale / Summary
- Next Action
- BlockerのDescription / Impact / Resolution
- Decision本文
- Verification Result
- External AI handoff

英語固定:

- Lifecycle State: `READY`, `FEATURE_SELECTED`, `APPROVED`, `IMPLEMENTING`, `BLOCKED`, `ACCEPTANCE_PENDING`, `COMPLETED`
- Verification Status: `PASS`, `FAIL`, `NOT_RUN`, `PARTIAL` 等
- Acceptance Status: `PENDING`, `ACCEPTED`, `REJECTED`
- Priority: `HIGH`, `MEDIUM`, `LOW`
- ID: `F-001`, `T-001`, `D-001`, `B-001`, `L-001`
- repository path / command / SHA-256 fingerprint
- Agent / Skillのfrontmatter key

## Human Gate

通常運用でHuman decisionを必須にするのは原則次の2点です。

1. Feature Specification Approval
2. Final Feature Acceptance

TaskごとのHuman approvalは要求しません。Taskは実装 → verification → PASSのloopを連続実行します。

Bootstrap時だけHuman Baseline Approvalが追加されます。

## Project Stateの責務

- `PROJECT.md`: Projectそのもの
- `ROADMAP.md`: どこへ進むか
- `STATUS.md`: 今どこで、次に何をするか
- `DECISIONS.md`: なぜその方針になったか
- `feature.md`: Feature artifactへのmanifest
- `evidence.md`: Feature verificationの正本

Specification / Plan / TasksはSpec Kit、Copilot Plan、通常Markdown等の既存artifactをrepository-root-relative pathで参照できます。

## v0.1で意図的に含めないもの

- Hooksによる強制
- MCP依存
- 複数Active Feature並列管理
- 高度なsubagent orchestration
- GitHub Projects自動同期
- Project State DB
- External AI API直接接続
- read-only SkillのOSレベル強制

まずMarkdown + Custom Agent + Agent Skillsだけでworkflowを検証します。

## 正式仕様

`PROJECT_MANAGER_V0.1_SPEC_JA.md`を参照してください。
