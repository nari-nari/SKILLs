# Project Manager v0.1 — 正式仕様（GitHub Copilot / 日本語版）

## 1. 目的

Project Manager v0.1は、AI支援ソフトウェア開発のための軽量なrepository-level Project管理層です。過去のChat履歴に依存せずrepository artifactから現在状態を復元し、1つのActive Featureを選択、仕様承認、実装、検証、Human Acceptance、Project-level反映、archiveまで一貫して管理します。

Spec Kit、Copilot Plan、Claude/Codex等のFeature-level planning systemを置き換えるものではなく、それらの上位でProject全体を管理するorchestration layerです。

人間向けMarkdown本文は原則日本語で記述しますが、State、Status、Priority、ID等の機械的な固定値は英語enumを維持します。

## 2. v0.1 Scope

Core capabilityは次の8個です。

1. Project / Featureの2層管理
2. PROJECT / ROADMAP / STATUS / DECISIONSによる永続Project State
3. Current Project StateとActive Feature Change artifactの分離
4. 重要境界だけのHuman Gate
5. Task単位の実装・verification loop
6. Human accepted Feature outcomeのProject State反映
7. Project navigationとNext Action提示
8. External AI handoffをread-only derived viewとして生成

Bootstrapは通常機能9個目ではなく、初期導入mechanismです。

## 3. Project-level Sources of Truth

### PROJECT.md

現在のProjectそのものを定義します。

必須section:

- 目的 (Purpose)
- 現在の能力 (Capabilities)
- 制約 (Constraints)
- 非目標 (Non-goals)
- 成功条件 (Success Criteria)

未来のFeatureをCurrent Capabilityとして書いてはいけません。一時的なprogress、Task、Blocker、test outputもここには置きません。

### ROADMAP.md

Projectが何をどの大まかな順序で実現するかを定義します。

section:

- Current: 0..1 Feature
- Next
- Later
- Backlog
- Completed

Feature IDは`F-001`, `F-002`, ... を使い、別Featureへ再利用しません。Priorityは`HIGH`, `MEDIUM`, `LOW`です。

Currentは最大1 Featureです。Current Featureの情報上のStatusは`ACTIVE`とし、詳細Lifecycle Stateは`STATUS.md`だけが正本です。

未完了dependencyを持つFeatureはCurrentへ移せません。Nextの先頭Featureを自動的にCurrentへ昇格させません。

DEFER / CANCELされたFeatureはBacklogへ戻し、Disposition、Reason、archive locationを記録します。

### STATUS.md

現在どこにいて次に何を行うかの正本です。

必須section:

- State
- Active Feature
- Progress
- Blockers
- Pending Human Action
- Next Action
- Last Verified State
- Notes

許可State:

- `READY`
- `FEATURE_SELECTED`
- `APPROVED`
- `IMPLEMENTING`
- `BLOCKED`
- `ACCEPTANCE_PENDING`
- `COMPLETED`

`Next Action`は常に必須です。

`Evidence status`:

- `NOT_APPLICABLE`
- `NOT_RUN`
- `PARTIAL`
- `PASS`
- `FAIL`

### DECISIONS.md

将来FeatureやAgentにも意味を持つProject-level Decisionと、その理由を記録します。

Decision IDは`D-001`, `D-002`, ... とし再利用しません。

Status:

- `ACTIVE`
- `SUPERSEDED`
- `RETIRED`

Decision entryは少なくともID/Title、Status、Date、Scope、Related features、Decision、Context、Rationale、Consequences、Revisit Conditionを持ちます。

既存Decisionの歴史的意味を書き換えてはいけません。方針変更時は新Decisionを追加し、旧Decisionを`SUPERSEDED`にします。

## 4. Feature-level Artifacts

Project Manager自身が所有するartifact:

- `changes/<feature>/feature.md`
- `changes/<feature>/evidence.md`

Specification / Plan / Tasksは外部systemが管理して構いません。`feature.md`からrepository-root-relative pathで参照します。

Planはoptionalです。実装開始前にはSpecification、Tasks、Evidenceが必要です。

### feature.md

保持する情報:

- Feature ID
- Feature name
- Artifact paths
- Specification approval timestamp
- Approved revision
- Notes

Lifecycle Stateは保持しません。

Specification approval fingerprintは原則`sha256:<hex>`を使用します。承認後にSpecificationのrequirements / acceptance criteriaが意味的変更された場合、旧approvalは無効となり`FEATURE_SELECTED`へ戻してHuman re-approvalを要求します。

### Tasks Contract

Tasks詳細schemaはProject Managerの所有外ですが、最低限次を機械的に判定できる必要があります。

- Task ID
- Completion state
- Task description

Taskはrequired verificationがPASSした後だけcompleteです。

### evidence.md

Feature verificationの正本です。

保持する情報:

- Feature identity / Updated
- Verification Summary
- Task Evidence
- Feature-Level Verification
- Known Limitations
- Human Acceptance
- Notes

Verification Summary Status:

- `NOT_RUN`
- `PARTIAL`
- `PASS`
- `FAIL`

Task Evidence Status:

- `NOT_RUN`
- `PASS`
- `FAIL`
- `SKIPPED`

Human Acceptance Status:

- `PENDING`
- `ACCEPTED`
- `REJECTED`

Feature-level `PASS`には、required Task verificationとFeature-Level Verificationの両方がPASSであることが必要です。`Blocking acceptance: Yes`のKnown Limitationが1つでもあれば`ACCEPTANCE_PENDING`へ進めません。

Human Acceptanceの正本は`evidence.md`だけです。

## 5. Lifecycle State Machine

通常進行:

```text
READY
  -> FEATURE_SELECTED
  -> APPROVED
  -> IMPLEMENTING
  -> ACCEPTANCE_PENDING
  -> COMPLETED
  -> READY
```

`ACCEPTANCE_PENDING`でHumanがrejectした場合は`IMPLEMENTING`へ戻ります。

`BLOCKED`はActive Featureについて安全かつ意味のあるNext Actionが1つも残っていない場合だけ入れます。

BLOCKED必須項目:

- Category
- Description
- Impact
- Resolution options
- Recommended resolution
- Unblock condition
- Blocked from
- Expected resume state
- Next action

Category:

- `AUTO_RESOLVABLE`
- `HUMAN_DECISION`
- `EXTERNAL_DEPENDENCY`
- `SCOPE_OR_SPEC`

明示的な復旧経路がない`BLOCKED`は無効です。

## 6. Human Gate

通常lifecycleでは次の2点だけを基本Human Gateとします。

1. Feature Specification Approval
2. Final Feature Acceptance

Bootstrap時は一時的にBaseline Approvalを追加します。

TaskごとのHuman approvalは要求しません。安全に進められる限りTask implementationとverificationを連続実行します。

Project Purpose / Constraints / Non-goals / Success Criteriaの意味的変更にも明示的Human approvalが必要です。

## 7. Completion Semantics

`ACCEPTANCE_PENDING`は、実装とrequired verificationが完了しているがFinal Human Acceptance待ちの状態です。

Human Acceptance後:

1. 必要なProject semantic impactを`PROJECT.md` / `DECISIONS.md`へ反映する。
2. `STATUS.md`を`ACCEPTANCE_PENDING -> COMPLETED`へ遷移させる。
3. `COMPLETED`中はRoadmap CurrentにFeatureを残す。
4. Project Manager所有Feature artifactをarchiveする。
5. Roadmap CurrentをCompletedへ移す。
6. `STATUS.md`を`COMPLETED -> READY`へ遷移しActive FeatureをNoneにする。

したがって`COMPLETED`は長期待機Stateではなく短いfinalization Stateです。

## 8. Deferred / Cancelled Feature

Active FeatureのDEFER / CANCELには明示的Human decisionが必要です。

DEFER:

- Current -> Backlog
- `Disposition: DEFERRED`
- Feature IDを維持
- Project Manager所有artifactをarchive
- STATUS -> READY

再開時は`FEATURE_SELECTED`から入り、Specificationの有効性を再確認します。

CANCEL:

- Current -> Backlog
- `Disposition: CANCELLED`
- Project Manager所有artifactをarchive
- Feature IDを別Featureへ再利用しない
- STATUS -> READY

## 9. Verification Precedence

artifact間で矛盾する場合のauthority:

1. 現在再現可能なtest / build / compiler結果
2. `evidence.md`
3. Tasks completion state
4. `STATUS.md` summary

下位artifactを強いEvidenceへ合わせてrepairします。

## 10. Multi-file Logical Transaction

複数artifactを変更するLifecycle transitionはlogical transactionとして扱います。

1. Preconditionsを検証する。
2. subordinate feature/evidence artifactを更新する。
3. transitionに必要なProject artifactを更新する。
4. `STATUS.md`を最後に更新し、transition commit markerとして扱う。
5. Postconditionsを検証する。

途中失敗した場合、Project Stateをrepairするまで通常Feature作業を継続しません。

## 11. Cross-artifact Invariants

1. `STATUS.md` Stateは常に許可7値のいずれか。
2. `READY`ではSTATUS Active Feature=NoneかつRoadmap Current=None。
3. 非READYではSTATUS Active Feature=Roadmap Current。
4. Roadmap Feature IDはsection間で一意。
5. Roadmap Currentは最大1 Feature。
6. Current Feature dependencyはCompleted。
7. STATUSには具体的なNext Actionが常にある。
8. Task completionにはrequired verification PASSが必要。
9. BLOCKEDには明示的な復旧経路が必要。
10. Human Acceptanceは`evidence.md`だけに保持する。
11. Specification approvalはApproved revision fingerprintに結び付く。
12. External AI outputはProject Stateを直接変更できない。
13. Project Manager artifact pathはrepository-root-relativeを使用する。

## 12. GitHub Copilot Custom Agent / Skills

### Custom Agent

`.github/agents/project-manager.agent.md`

State-aware orchestratorとして、最初にSTATUSを読み、適切なSkillへroutingします。v0.1では`feature-manage`に従う間、同じAgentがTask実装とtestも担当できます。

### Skills

`.github/skills/<skill-name>/SKILL.md`に配置します。

- `project-bootstrap`: baseline初期化
- `project-navigate`: read-onlyのCurrent State / Next Action navigation
- `feature-manage`: Active Feature lifecycle、実装、test、BLOCKED、Feature verification
- `project-update`: accepted/deferred/cancelled finalizationとProject State repair
- `external-ai-handoff`: External AI向けread-only derived context生成

read-only Skillの制約はv0.1ではinstruction-levelの論理制約でありOS-level security boundaryではありません。

Skill本文は日本語で記述して構いませんが、frontmatterの`name`、State enum、Status enum等の固定機械値は仕様どおり維持します。

## 13. Bootstrap

Bootstrapは7-State lifecycleの外側です。

Phase:

1. Discover
2. 事実と推定を分類
3. `BOOTSTRAP_REVIEW.md`をDraft
4. Human Baseline Approval
5. Project State生成
6. Validate

Bootstrapは現在Stateを再構築しますが、存在しない歴史を作りません。

捏造禁止:

- historical approval
- historical acceptance
- undocumented Decision rationale
- 未検証のhistorical test PASS
- Roadmapを埋めるためだけのretroactive Feature history

Bootstrap以前のcompleted workはCurrent Capabilityとして表現できます。

Initial Stateは`READY`, `FEATURE_SELECTED`, `APPROVED`, `IMPLEMENTING`, `BLOCKED`, `ACCEPTANCE_PENDING`のいずれかです。`COMPLETED`へ直接初期化しません。

## 14. External AI Handoff

External AI handoffは最小限の関連Project Stateから生成するread-only derived viewです。

必要に応じて含めるもの:

- Project Purpose
- Relevant Capabilities / Constraints
- Current State
- Relevant Roadmap
- Active Feature
- Relevant Decisions
- Verified facts
- Known Limitations
- External AIへ求める具体的Question / Decision / Deliverable

External AI recommendationはproposalです。Project ManagerとHumanが評価し、通常のState transitionとHuman authorityを経由して採用します。

## 15. v0.1 Non-goals

意図的に対象外:

- 複数Active Featureの並列管理
- 複雑なmulti-agent orchestration
- GitHub Projects自動同期
- Issue / Pull Requestの自動orchestration
- autonomousなProject direction変更
- per-task Human approval
- Spec Kit / BMAD / OpenSpecへの必須依存
- database-backed Project State
- External AI API直接連携
- Hooksによる強制
- read-only SkillのOS-level enforcement
