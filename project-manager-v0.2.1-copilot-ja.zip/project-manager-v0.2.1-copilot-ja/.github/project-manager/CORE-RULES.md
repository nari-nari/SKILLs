# Project Manager v0.2 Core Rules

通常作業で毎回読む必要はない。境界判断、復旧、finalization、Human Gateが曖昧な場合に参照する。

## 1. Source of Truth

Project-level source of truth:

- `docs/project/PROJECT.md`
- `docs/project/ROADMAP.md`
- `docs/project/STATUS.md`
- `docs/project/DECISIONS.md`

Change-level source of truthは、`PROJECT.md`で選択されたChange Backendだけが持つ。
Change-level Spec / Design / TasksをProject-levelファイルへ複製しない。

## 2. Normative vs Empirical Truth

Normative truth（どうあるべきか）は、次を優先する。

1. Human-confirmed Project / Change Contract
2. Current Specs + Active Delta Specs
3. Durable Design Decisions
4. External HIGH proposal
5. Copilot inference

Empirical truth（実際どうなっているか）は、再現可能なtest/build/compiler/runtime/code inspectionを優先する。

両者が食い違う場合はDRIFTとして扱い、code / active spec / designのどこを直すべきか判断する。実装が再現可能だからといって仕様より正しいとはみなさない。

## 3. Project State

許可State:

- `READY`
- `CHANGE_ACTIVE`
- `BLOCKED`

Invariant:

- `READY` → Active Changeなし、ROADMAP Currentなし。
- `CHANGE_ACTIVE` → Active Changeが1件、STATUSとROADMAP Currentが同一Changeを参照。
- ROADMAP Currentは最大1件。
- `BLOCKED`には必ずRecovery Pathを持たせる。

## 4. Change Contract

Logical Change Contract:

- Goal
- Scope
- Out of Scope
- Success

Change開始時はROADMAP、明示済みuser intent、PROJECT、Current Specs、Project DecisionsからDraftを作る。
AIの非実質的な補完で意味が変わらなければBaseline Contractとして扱える。
意味が変わる／不明な場合はContract Boundary Checkを行う。

Active Change内のDelta / Design / TasksはContract内ならLiving artifactsとして承認なしに更新できる。

## 5. Human Decision Gate

Human Decisionを要求するのは原則として次だけ。

- Change Contractの実質変更
- Successの実質的な緩和
- Project-level / business / irreversible high-impact decision
- Human-specific value judgment
- 最終Change Acceptance

複数Decisionは可能な限り1つのDecision Bundleへまとめる。

External AIへのprompt貼付や回答貼付は`OPERATIONAL_HANDOFF`であり、Human Decisionではない。

## 6. Reasoning Routing

Default: `LOW`

- `LOW`: routine implementation, tests, build, local update, clear repository work
- `HIGH`: complex repository-local reasoning, multi-component mapping, ambiguous local architecture
- `EXTERNAL`: project strategy, complex/high-risk initial Change design, abstract/high-impact reasoning, structural replanning where external reasoning is advantageous

HIGHとEXTERNALは上下関係ではない。Context LocalityとHandoff Costで選ぶ。

`LOW` / `HIGH` はProject Manager上の**reasoning class**であり、instructionを書くだけでVS Codeの実行modelが自動的に切り替わると仮定しない。

Copilot側の実行方法:

- Project policyが`AUTO_PREFERRED`でCopilotのAuto model selectionを使用できる場合、LOW/HIGHはtask intentとして提示し、実model選択はCopilot Autoに委ねる。
- 固定model運用でHIGHが必要な場合、現在modelが十分であると確認できなければ`OPERATIONAL_HANDOFF: COPILOT_MODEL_SWITCH`として扱う。これはHuman Decision Gateではない。
- 実際にmodel切替できていないのに「HIGHを実行した」と記録しない。
- HIGH用subagentで親sessionより高cost tierへ必ず自動昇格できると仮定しない。利用する場合は現在のVS Code/Copilot制約を確認する。

Initial Spec / Design / TasksはLOW固定ではない。

Structural Replanは「既存artifact構造を維持しなくてよい」という意味であり、必ずEXTERNALという意味ではない。
Repository-localならHIGH、abstract/high-impactならEXTERNALを優先する。

## 7. External AI Authority

External HIGHはReasoning Authorityであり、operation/storageのsource of truthではない。
回答取り込み時はRepository Fit Checkを行う。

自動補正可能:

- path
- actual symbol names
- existing utility reuse
- repository convention
- test commands/locations
- task granularity/order

LOWが勝手に変えない:

- Change Contract
- required behavior / Delta intent
- Design Intent
- Project-level decision

Repository Fit Check自体がrepository-complexならHIGHを使ってよい。

## 8. Replanning

`LOCAL_REPLAN`:
既存Design Intentが概ね妥当。影響箇所だけ更新する。

`STRUCTURAL_REPLAN`:
既存Delta / Design / Tasksは誤っている可能性がある。
次を一次情報としてゼロベース再評価できる。

- Change Contract
- Current Specs
- Project Constraints
- repository facts
- reproducible evidence

既存Planning artifactsは参考資料に格下げできる。

## 9. Tasks and Verification

TaskはLOWが自律実装＋検証できる程度の粒度にするが、micro-step化しない。
最低限:

- Task ID
- Action
- Verify / Done condition

Taskは必要verificationがPASSして初めてcomplete。
完了済みTaskは履歴として原則保持し、後の設計変更ではrepair / superseding taskを追加する。

実装中はLocal Impact Checkを使い、Full Drift CheckはChange completion candidate付近で行う。
artifact更新のたびに全分析をやり直さない。

## 10. Human-required uncertainty

External AIが`HUMAN_REQUIRED`を示した場合でも、Recommended optionを仮定したProvisional Delta / Design / Tasksまでは完成させる。
ただしHuman Decisionの結果で破棄される可能性が高い実装は原則進めない。
Decision非依存の調査、test準備、可逆な共通作業は進めてよい。

## 11. Finalization

Acceptance前:

1. Required Tasks complete
2. Full Drift Check
3. Backend `preview_finalization`
4. Current Specs Merge Preview
5. Acceptance Summary
6. Human Change Acceptance

Acceptance後:

7. Acceptance metadataを`ACCEPTED`として記録
8. Backend `commit_finalization`
   - accepted DeltaをCurrent Specsへ反映
   - resulting specsの整合確認
   - Changeをfreeze/archive
9. ROADMAP / durable DECISIONSを更新
10. Project consistency check
11. 最後にSTATUSを`READY`へ更新

Acceptance後にfinalizationが失敗しても再Acceptanceを要求しない。
`State: CHANGE_ACTIVE`, `Activity: FINALIZATION`, `Acceptance: ACCEPTED`を維持し、idempotent / resumableに復旧する。

## 12. History

Accepted Changeはhistoryとしてfreezeする。
後続Changeが同じCapabilityを変更しても、過去Accepted ChangeをCurrent Specに合わせて書き換えない。

Current SpecsはAccepted behaviorのLiving source of truth。
Active Deltaは未受理のfuture behaviorを表す。

## 13. Recovery

失敗時:

- 最後のvalid source of truthを保持
- successを捏造しない
- Stateを先に進めない
- concrete Next Actionを記録
- safe meaningful actionがある限りBLOCKEDにしない

Recovery class:

- `LOCAL_RECOVERY`: routine failure → LOW
- `REASONING_RECOVERY`: repository reasoning不足 → HIGH候補
- `STRUCTURAL_RECOVERY`: architecture/planning前提崩壊 → structural replan
- `BLOCKED_RECOVERY`: human/external/inputなしでは安全に進めない
