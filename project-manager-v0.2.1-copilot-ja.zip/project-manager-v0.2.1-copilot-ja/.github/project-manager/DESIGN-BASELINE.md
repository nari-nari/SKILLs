# Project Manager v0.2 Design Baseline

このファイルは保守・改修時の設計参照用。通常のTask実装で毎回読み込まない。

## D0 — Model Routing

- LOW default。
- HIGHはrepository-local complex reasoning。
- EXTERNALはstrategy / abstract high-impact reasoning / complex initial design / suitable structural replanning。
- HIGHとEXTERNALは単純な上下関係ではない。
- 高推論完了後はroutine workをLOWへ戻す。

## D0b — Delegation First

成熟したtool/backendの機能をProject Managerで再実装しない。

## D0c / D0d — Pluggable Change Backend

Project Manager CoreはOpenSpec availabilityに依存しない。

- OPENSPEC: OpenSpec artifacts/actionsへ委譲
- STANDALONE: 最小Markdown backend

両者はファイル互換ではなく、Current Specs / Contract / Delta / Design / Tasks / Verificationという論理interfaceで互換にする。

## D1 — Change Contract Boundary

Contract:

- Goal
- Scope
- Out of Scope
- Success

Active Delta / Design / TasksはContract内ならLiving。
Accepted Change historyは後続Changeに合わせて書き換えない。

## D2 — Human Gate

原則Human Decisionが必要なのは:

- material Contract change
- material Success weakening
- project/business/irreversible high-impact decision
- human-specific value judgment
- final Change Acceptance

Operational copy/pasteはDecision Gateではない。

## D3 — Activity-based Routing

Initial Design RoutingでSpec/Design/Tasksの生成者をLOWに固定しない。
Structural Replanでは既存planning artifactsを参考資料へ格下げできる。

## D4 — External AI Authority

External HIGHはReasoning Authority。
回答はRepository Fit Check後、Backend artifactsへ取り込む。
LOWがDesign IntentやContractを再解釈しない。

## D5 — Tasks

- Task ID + Action + Verifyを最低限とする。
- Task complete = required verification PASS。
- Task境界でhuman approvalを要求しない。
- 完了済みTaskはhistoryとして保持する。

## D6 — Impact / Drift

- meaningful living-artifact change → Local Impact Check
- completion candidate → Full Drift Check
- artifact変更で最初からworkflowをやり直さない

## D7 — Artifact Ownership

Project Manager:

- PROJECT
- ROADMAP
- STATUS
- DECISIONS
- routing / human boundary / strategy orchestration

Backend:

- Current Specs
- Change Contract
- Delta
- Design
- Tasks
- Verification / finalization mechanics

## D8 — Event-driven Strategy Review

Routine Roadmap maintenanceはLOW。
Project commitment / priorities / long-term architectureを再考する必要がある時だけPROJECT_STRATEGYを起動する。

代表trigger:

- roadmap exhausted
- major milestone completed
- new major constraint
- repeated failure / technical debt signal
- major architecture decision
- project assumption invalidated
- human request

## State Baseline

Stateは3つのみ:

- READY
- CHANGE_ACTIVE
- BLOCKED

Acceptance待ちもCHANGE_ACTIVE。
Acceptance後finalization失敗も`CHANGE_ACTIVE + Activity: FINALIZATION + Acceptance: ACCEPTED`。

## Finalization Baseline

1. tasks complete
2. Full Drift Check
3. preview_finalization / Merge Preview
4. Acceptance Summary
5. Human Acceptance
6. commit_finalization
7. Roadmap/Decision update
8. consistency check
9. STATUS READY
