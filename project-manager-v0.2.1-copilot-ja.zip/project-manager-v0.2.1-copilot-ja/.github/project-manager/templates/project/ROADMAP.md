# Roadmap

## Current

<!-- 0 or 1 Change. CHANGE_ACTIVE時はSTATUS Active Changeと一致させる -->

## Next

<!-- 実施意図が強いChange -->

## Later

<!-- 方針として実施予定だが順序/時期は柔軟 -->

## Backlog

<!-- 候補。実施コミットメントではない -->

## Completed

<!-- Accepted + finalized済みChange -->

<!-- Change entry example:
- ID: C-001
  Name: example-change
  Backend Ref: example-change
  Priority: HIGH
  Depends on: none
  Goal: ...
  Reason: ...
-->
