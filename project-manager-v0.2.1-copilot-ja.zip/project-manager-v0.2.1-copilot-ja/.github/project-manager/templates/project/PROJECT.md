# Project

## Purpose

<!-- このProjectの存在目的を短く記述 -->

## Goals

- <!-- goal -->

## Project Success

<!-- 任意。Project全体の成功条件が明確な場合のみ -->

## Capabilities

<!-- 詳細仕様は書かずCurrent Specsへの索引にする -->

- Name: <!-- Capability name -->
  Spec Ref: <!-- backend-neutral reference -->
  Summary: <!-- one-line current capability summary -->

## Constraints

- <!-- durable constraint -->

## Non-goals

- <!-- explicit non-goal -->

## Strategy Principles

- Routine implementation / verificationでは軽量Copilotを既定とする。
- 高度な推論が必要なActivityだけHIGH / EXTERNALへrouteする。
- Change-level source of truthをProject-level filesへ複製しない。

## Copilot Model Routing

Policy: AUTO_PREFERRED

<!--
AUTO_PREFERRED: Copilot Autoが利用可能なら使い、Project ManagerのLOW/HIGHをreasoning classとして扱う。
MANUAL_FIXED: 固定modelを使い、HIGHが必要ならOperational Handoffでmodel switchを促す。
-->

## Change Backend

Backend: UNCONFIGURED

<!-- bootstrapで OPENSPEC または STANDALONE に確定する -->
