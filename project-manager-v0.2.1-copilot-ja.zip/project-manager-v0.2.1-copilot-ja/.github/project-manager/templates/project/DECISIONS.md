# Project Decisions

Project-levelで将来の複数Changeが参照する価値のあるdurable decisionだけを記録する。
Change内部だけのDesign DecisionはChange Backendへ置く。

<!--
## D-001 — Decision title

Status: ACTIVE
Date: YYYY-MM-DD
Scope: WORKFLOW | ARCHITECTURE | PRODUCT | OTHER
Related Changes: -

### Decision
...

### Context
...

### Rationale
...

### Consequences
...

### Revisit Condition
...

### Supersedes
None

### Superseded by
None
-->
