# <Capability> Specification

## Purpose

<!-- このCapabilityが現在提供すべき価値 -->

## Behavior

### <Behavior / Requirement>

- <!-- current accepted behavior only -->

## Constraints

- <!-- capability-specific constraint -->

## Notes

- <!-- optional; historyは書かない -->
