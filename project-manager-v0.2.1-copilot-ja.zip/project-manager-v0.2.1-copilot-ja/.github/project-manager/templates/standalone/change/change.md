# C-XXX — <change-name>

## Contract

### Goal

...

### Scope

- ...

### Out of Scope

- ...

### Success

- ...

## Affected Capabilities

- ...

## Delta Specification

### ADDED

- ...

### MODIFIED

- ...

### REMOVED

- ...

## Design

### Intent

...

### Approach

...

### Affected Components / Interfaces

- ...

## Assumptions and Risks

### Assumptions

- ...

### Risks

- ...

## Verification Summary

Status: NOT_READY

<!-- Acceptance直前に必要な範囲で更新。詳細Evidence logにはしない。 -->
