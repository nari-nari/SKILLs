---
name: backend-openspec
description: OpenSpecをProject Manager v0.2のChange Backendとして利用するadapter。Current Specs/Change/Delta/Design/Tasks/verify/finalizationをOpenSpec artifacts/actionsへ委譲する。
---

# Backend OpenSpec

## Purpose

Project Manager CoreのChange Backend contractをOpenSpecで実装する。
OpenSpecが管理するChange-level artifactsをProject Manager側へ複製しない。

## Current OpenSpec model

現行OpenSpecでは概ね次がsource of truthとなる。

- Current Specs: `openspec/specs/<domain>/spec.md`
- Active Change: `openspec/changes/<change-name>/`
  - `proposal.md`
  - `specs/<domain>/spec.md` (delta specs)
  - `design.md`
  - `tasks.md`

OpenSpecはOPSXのfluid/iterative workflowを採用し、implementation中にplanning artifactsを更新できる。

## GitHub Copilot integration

OpenSpec自身がGitHub Copilot向けに生成したintegrationを優先する。
通常、OpenSpecは以下を管理する。

- `.github/skills/openspec-*/SKILL.md`
- `.github/prompts/opsx-*.prompt.md`

Project Managerはこれらをコピー・改変して自前OpenSpec workflowを再実装しない。

OpenSpec version/profileにより使えるactionが異なるため、生成済みskills/promptsまたは現在のOpenSpec CLIをsource of truthとして使う。

## Logical operations

Project Managerへ次の論理操作を提供する。

- `get_current_specs`
- `create_change`
- `get_change_contract`
- `update_change_contract`
- `get_delta_specs`
- `update_delta_specs`
- `get_design`
- `update_design`
- `get_tasks`
- `update_tasks`
- `get_verification_state`
- `record_verification`
- `verify_change`
- `preview_finalization`
- `commit_finalization`

これらはAPI名ではなくProject Manager上の論理interface。

## Mapping guidance

### Create / planning

OpenSpecの現行profileで利用可能な`propose` / `update`等の生成済みworkflowを活用する。
Project Managerが決めたBaseline ContractとReasoning resultを入力として与える。
OpenSpec workflow側にProject/Contract intentを勝手に再定義させない。

### Living updates

Implementation中にDelta / Design / Tasksを修正してよい。
必要に応じてOpenSpecのupdate actionまたは直接artifact編集を用い、Contract内の整合を保つ。

### Verification

Repository tests/build/compiler/runtime evidenceを必ず使う。
OpenSpec `verify`が利用可能なら補助的に利用できるが、expanded profile限定の場合があるため必須としない。

### preview_finalization

Acceptance前に、active deltaをCurrent Specsへ反映した場合の差分/結果をread-onlyで提示する。
Current Specsを書き換えない。

現行CLIで利用可能なら`openspec instructions archive --change <change-name> --json`や`openspec validate`/`openspec status --json`をread-only contextとして利用し、Current Specsとdeltaを比較してMerge Previewを作る。`sync`はpreview目的では実行しない。

### commit_finalization

Human Acceptance後、現在利用可能なOpenSpecのarchive mechanicsを用いて:

1. accepted deltaをCurrent Specsへ反映
2. resulting specsを確認
3. Changeをarchive/freeze

を完了する。

現行CLIで利用可能なら、Human Acceptance後の重複確認を避けるため、明示的なchange name付きの非対話実行 `openspec archive <change-name> --yes` を優先する。OpenSpec CLIのarchiveはspec mergeとarchiveを一つのlifecycle操作として扱い、途中失敗時の復旧も提供する。

`/opsx-archive`等の対話workflowが追加のsync/archive確認を要求する場合、それを新しいHuman Decision Gateとして扱わない。可能ならagent-compatible CLI/API surfaceへ委譲する。

OpenSpec version差があるため、実行前に`openspec archive --help`または現在生成されているOpenSpec integrationでflagsを確認する。

## Boundary

このBackendは次を決めない。

- Roadmap priority
- Reasoning route
- Human Gate
- Project Strategy
- Changeのbusiness value

## Failure

OpenSpec command/actionがversion/profile差で存在しない場合、推測で旧commandを実行し続けない。
現在生成されているOpenSpec skills/prompts/CLI helpを確認し、STATUSに具体的Recoveryを残す。
