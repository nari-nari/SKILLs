---
name: backend-standalone
description: OpenSpecなしでProject Manager v0.2のChange Backend contractを最小Markdown構成で提供する。Current Specs、change.md、tasks.mdを管理する。
---

# Backend Standalone

## Purpose

OpenSpecを導入できない環境で、Project Manager v0.2に必要な最小Change Backendを提供する。
OpenSpec全機能を再実装しない。

## Storage

Current Specs:

- `docs/specs/<capability>.md`

Active Change:

- `changes/<change-id>-<slug>/change.md`
- `changes/<change-id>-<slug>/tasks.md`

Archived Change:

- `changes/archive/YYYY-MM-DD-<change-id>-<slug>/change.md`
- `changes/archive/YYYY-MM-DD-<change-id>-<slug>/tasks.md`

必要に応じて`.github/project-manager/templates/standalone/`を参考に作成する。

## `change.md`

最低限:

- Contract
  - Goal
  - Scope
  - Out of Scope
  - Success
- Affected Capabilities
- Delta Specification
  - ADDED
  - MODIFIED
  - REMOVED
- Design（単純Changeでは`Not required`可）
- Assumptions / Risks
- Acceptance前に必要ならVerification Summary

`change.md`を完成後の全仕様にしない。
Expected future behavior = Current Specs + Active Delta。

## `tasks.md`

最低限:

- Task ID
- Action
- Verify condition
- checkbox

例:

```markdown
- [ ] T-001 比較モデルを追加する
  - Verify: 関連unit testsがPASS
```

完了Taskを後から削除してhistoryを消さない。

## Current Specs

Current SpecsはAccepted behaviorだけを書く。
過去Change ID、Task履歴、実装経緯をCurrent Specへ埋め込まない。

## Logical operations

- `get_current_specs`
- `create_change`
- `get_change_contract`
- `update_change_contract`
- `get_delta_specs`
- `update_delta_specs`
- `get_design`
- `update_design`
- `get_tasks`
- `update_tasks`
- `get_verification_state`
- `record_verification`
- `verify_change`
- `preview_finalization`
- `commit_finalization`

## Verification

Standaloneでは複雑な独自validatorを必須にしない。
最低限:

- Contract satisfied?
- Delta behavior implemented?
- critical Design Intent preserved?
- required Tasks verified?
- relevant regression PASS?

不一致時はcode / active Delta / Design / Tasksの適切な箇所を修正する。

## preview_finalization

Acceptance前にCurrent Specs + accepted candidate DeltaからMerge Previewを作る。
まだCurrent Specsを書き換えない。

## commit_finalization

Human Acceptance後:

1. DeltaをCurrent Specsへ反映
2. resulting Current Specsの整合を確認
3. `changes/archive/YYYY-MM-DD-<change-id>-<slug>/`へChange directoryを移動してhistoryとしてfreezeする

archive先が既に存在する場合は上書きせず、既存archiveが同一finalizationの結果か確認してresumableに処理する。
過去Accepted Changeを後続Current Specsへ追従させて書き換えない。

## Boundary

BackendはRoadmap priority、Model Routing、Human Gate、Project Strategyを決めない。
