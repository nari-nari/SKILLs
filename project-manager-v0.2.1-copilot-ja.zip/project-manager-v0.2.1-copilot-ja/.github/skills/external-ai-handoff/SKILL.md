---
name: external-ai-handoff
description: 外部高性能AI向けに必要Contextを1つの貼付Promptへ変換し、回答をRepository Fit Check後にProject/Change artifactsへ取り込む。Strategy/Change Design/Replan/Decision Supportで使う。
---

# External AI Handoff

## Role

External AIとの`Context Compiler + Response Importer`。
Humanが行うcopy/pasteはOperational Handoffであり、Decision approvalではない。

## Modes

- `PROJECT_STRATEGY`
- `CHANGE_DESIGN`
- `REPLANNING`
- `DECISION_SUPPORT`

## Request generation

1つのself-contained Markdown promptを生成する。
必要なContextだけを含める。

候補:

- Project Purpose / Goals / Constraints
- ROADMAP
- relevant Project Decisions
- relevant Current Specs
- Change Contract
- existing Delta / Design / Tasks
- repository facts
- reproducible evidence
- trigger / requested outcome

全repositoryや全履歴を無条件で貼り付けない。

## Common authority instruction

Prompt内で次を明示する。

- Change Contract / Project Constraintsを尊重する。
- repository facts / reproducible evidenceを事実として扱う。
- existing planning artifactsには誤りがあり得る。
- 質問だけで回答を止めない。
- 未確認事項ごとにRecommended defaultを出す。
- HUMAN_REQUIREDでもRecommended default前提のProvisional Solutionまで完成させる。

## Unknown format

重要unknownごとに要求:

- Question
- Classification: `AUTO_DEFAULT | CONFIRM_LATER | HUMAN_REQUIRED`
- Options
- Recommended
- Reason
- Can proceed with recommendation: Yes / No

## PROJECT_STRATEGY output

要求する主要section:

- Current Assessment
- Strategic Priorities
- Recommended Roadmap Changes
- Proposed Next Changes
- Risks / Technical Debt
- Project-level Decisions
- Questions + Recommended Defaults
- Immediate Next Action

Changeの詳細Tasksまでは作らせない。

## CHANGE_DESIGN output

要求する主要section:

- Understanding / Contract confirmation
- Decisions / Assumptions
- Delta Specification
- Design Intent / Approach
- Affected Components / Interfaces / Flows
- Tasks + Verify conditions
- Risks
- Reconsultation Triggers
- Questions + Recommended Defaults

初期designをLOW artifactに依存させない。

## REPLANNING

`LOCAL_REPLAN`ならvalid Design Intentを維持し、影響部分中心。

`STRUCTURAL_REPLAN`ならPromptで明示:

- Existing Delta / Design / Tasks are NOT authoritative.
- Their structure need not be preserved.
- Re-evaluate from Contract, Current Specs, Project Constraints, repository facts and reproducible evidence.

Output:

- Diagnosis
- assumptions to keep/reject
- revised Delta if needed
- revised Design
- Task changes: keep / modify / add / obsolete
- required verification
- risks
- Questions + Recommended Defaults
- Next Action

## DECISION_SUPPORT output

- Decision
- Context
- Options
- Pros / Cons / Risks / Reversibility
- Recommendation + Reason
- Impact
- Human Decision Required
- Recommended Default

## Response import

External responseをLOWで再要約・再設計しない。
Repository Fit Checkだけを行う。

自動調整可:

- actual paths
- actual symbol names
- existing utilities
- repository conventions
- test commands / locations
- task split/order

変更禁止/要escalation:

- Contract
- required behavior
- Design Intent
- Project-level recommendation/decision

Fit Checkがrepository-complexならCopilot HIGHを使ってよい。
Import後、routine implementationはLOWへde-escalateする。

## Incomplete response

欠落が局所的なら既存回答を保持し、必要部分だけ補完する。
External follow-upが必要なら短いdelta requestを生成し、最初から相談し直さない。
