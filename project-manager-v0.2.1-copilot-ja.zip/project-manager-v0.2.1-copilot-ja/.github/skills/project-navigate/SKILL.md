---
name: project-navigate
description: Project Managerの現在地、次Action、LOW/HIGH/EXTERNALの推奨Routeをread-onlyで判定する。「現在の状況」「次は何」「外部AIが必要？」等で使う。
---

# Project Navigate

## Rule: read-only

Repository filesを変更しない。

## Procedure

1. `docs/project/STATUS.md`を読む。
2. 必要な場合だけ`ROADMAP.md`を読む。
3. `CHANGE_ACTIVE`なら設定BackendからActive Changeを解決する。
4. Immediate next actionに必要なartifactだけ読む。
5. 次を判定する。
   - State / Activity
   - Active Change
   - Progress summary
   - concrete Next Action
   - Reasoning Route: LOW / HIGH / EXTERNAL
   - ExternalならMode
   - Escalate If

## Routing axes

必要な時だけ次を短く評価する。

- Reasoning Difficulty: LOW / MEDIUM / HIGH
- Context Locality: REPOSITORY_LOCAL / MIXED / ABSTRACT
- Uncertainty: LOW / MEDIUM / HIGH
- Impact: LOCAL / MULTI_COMPONENT / PROJECT_LEVEL
- Rework Risk: LOW / HIGH

### LOW default

Routine implementation、tests/build、明確なbug fix、mechanical update、単純なLocal Impact Check。

### HIGH

Repository内部の複雑な依存関係、複数module mapping、local architecture判断、Designのrepository適合が難しい場合。

### EXTERNAL

Project Strategy、複雑・高リスクInitial Change Design、抽象的architecture trade-off、高不確実性/高影響判断、Externalが有利なStructural Replan。

HIGHとEXTERNALを単純な難易度階段として扱わない。

### Copilot route execution

`PROJECT.md`のCopilot Model Routing policyを確認する。

- `AUTO_PREFERRED`: LOW/HIGHはreasoning classとして推奨し、Copilot Autoに実model選択を委ねる。
- `MANUAL_FIXED`: HIGH推奨時、現在modelが十分と確認できなければ`Pending Operational Handoff: COPILOT_MODEL_SWITCH`を推奨する。

model switchはHuman Decision Gateではない。実modelを確認できない場合は、切替済みと推測しない。

## Output

簡潔に次を返す。

- State
- Activity
- Active Change
- Progress
- Next Action
- Recommended Route
- Reason
- Escalate If
- Human Action（あれば）
