---
name: project-update
description: Project-level artifactsのdurable更新と、Human Acceptance後のChange finalizationを担当する。PROJECT/ROADMAP/DECISIONSとREADY遷移を管理する。
---

# Project Update

## Purpose

Project-levelのdurable updateと、Accepted Changeのfinalizationを担当する。ROADMAPの主write ownerだが、Change activation時に`change-manage`がCurrentを機械更新することだけは例外とする。

## A. Change Finalization

前提:

- `State: CHANGE_ACTIVE`
- Human Change Acceptance済み
- STATUS等に`Acceptance: ACCEPTED`が記録されている

手順:

1. 設定Backendの`commit_finalization`を実行する。
   - accepted Delta → Current Specs
   - resulting specs consistency check
   - Change freeze/archive
2. ROADMAPをmechanical updateする。
   - CurrentからCompletedへ
   - dependencies等を更新
3. 必要ならdurable Project Decisionを`DECISIONS.md`へ記録する。
4. Project-level consistency checkを実行する。
5. 最後にだけSTATUSを`READY`へ戻し、Active Changeを解除する。
6. Strategy Trigger Checkを行う。

途中失敗時:

- `State: CHANGE_ACTIVE`
- `Activity: FINALIZATION`
- `Acceptance: ACCEPTED`
- concrete Recovery Action

を維持し、再Acceptanceを要求しない。処理はresumable/idempotentに行う。

## B. Strategy / Project-level Update

Human-approvedまたはHuman Gate不要と分類されたProject-level changeを次へ反映する。

- `PROJECT.md`
- `ROADMAP.md`
- `DECISIONS.md`

External Strategy ProposalをLOWが勝手に意味変更しない。

### Mechanical Roadmap updates

LOWで自動可:

- Current → Completed
- dependency satisfied
- 既定priority/orderに従う移動
- wording/reason明確化
- low-commitment Backlog candidate追加

### Project Commitment changes

Human Decision候補:

- Current / Nextの実質的優先順位変更
- major Change追加/削除
- major architecture方針変更
- Project Goal / Constraints / Non-goals変更
- Active Change中止/大方向転換

複数はDecision Bundleへまとめる。

## Strategy Trigger Check

代表trigger:

- ROADMAP_EXHAUSTED
- MAJOR_MILESTONE_COMPLETED
- NEW_MAJOR_CONSTRAINT
- REPEATED_FAILURE
- TECHNICAL_DEBT_SIGNAL
- MAJOR_ARCHITECTURE_DECISION
- PROJECT_ASSUMPTION_INVALIDATED
- HUMAN_REQUEST

TriggerなしならExternal Strategy Reviewを毎回行わない。
