---
name: project-bootstrap
description: Project Manager v0.2をリポジトリへ初期導入する。STATUS/PROJECTが未作成、またはユーザーが初期化・再初期化を依頼した時に使う。
---

# Project Bootstrap

## Purpose

Project Manager v0.2を既存または新規repositoryへ導入し、以後の管理を開始できる状態にする。

## Responsibilities

1. Repositoryを高レベルで調査する。
2. 既存のProject Manager/OpenSpec/類似管理artifactを壊さず確認する。
3. OpenSpecが実際に利用可能か確認する。
4. Backendを選択する。
   - OpenSpec利用可能かつ適切 → `OPENSPEC`
   - 利用不可、禁止、またはユーザー指定 → `STANDALONE`
5. `.github/project-manager/templates/project/`を参考に、次を作成/初期化する。
   - `docs/project/PROJECT.md`
   - `docs/project/ROADMAP.md`
   - `docs/project/STATUS.md`
   - `docs/project/DECISIONS.md`
6. `PROJECT.md`のCopilot Model Routing policyを設定する。既定は`AUTO_PREFERRED`とし、ユーザーが固定model運用を明示した場合のみ`MANUAL_FIXED`とする。
7. Current Capabilities / Current Specsの索引を初期化する。
8. Standalone Backendなら必要な`docs/specs/`構造を初期化する。
9. 既存documentationを置換しない。必要なら参照を張る。

## OpenSpec detection

単なるfolder名の存在だけでOPENSPECと決めない。CLIまたは生成済みOpenSpec integrationが利用可能か、既存`openspec/` artifactsが正しく存在するかを確認する。

GitHub Copilot向けOpenSpecが導入済みなら、通常はOpenSpec自身が`.github/skills/openspec-*`および`.github/prompts/opsx-*.prompt.md`を管理する。Project Managerはそれらを複製しない。

## Do not invent history

次を推測して作らない。

- 過去ChangeのAcceptance
- 実行していないtests/buildのPASS
- 存在しないProject Decisions
- 未確認のCurrent behavior

UnknownはUnknownとして記録する。

## Completion

Bootstrap完了条件:

- Backendが`OPENSPEC`または`STANDALONE`に確定
- 4つのProject-level filesが存在しCross-file invariantを満たす
- Current Specsまたはその参照が解決可能
- `STATUS`が正確に`READY`または、必要ならRecovery付き`BLOCKED`

Bootstrap後は通常workflowへ介入しない。
