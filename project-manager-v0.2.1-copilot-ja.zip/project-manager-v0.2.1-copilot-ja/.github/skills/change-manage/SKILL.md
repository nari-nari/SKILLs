---
name: change-manage
description: 1つのActive Changeを開始からAcceptance準備までオーケストレートする。Spec/Design/Tasks、実装、検証、Local Impact、Replan、Drift Checkを管理する。
---

# Change Manage

## Purpose

1つのActive Changeのlifecycleを管理する。Storage formatはBackend、複雑推論はLOW/HIGH/EXTERNALへ委譲できる。

`change-manage`自身を「常にSpec/Design/Tasksを書くLOW planner」と扱わない。

## Change start (`READY`)

1. ROADMAPからChange候補を選択する。
2. 明示済みintent、PROJECT、ROADMAP、Current Specs、Project DecisionsからDraft Change Contractを作る。
   - Goal
   - Scope
   - Out of Scope
   - Success
3. Contract Boundary Checkを行う。
4. 設定BackendでChangeを作成する。
5. Change activationのlogical transactionとして、ROADMAP CurrentとSTATUSを同じChangeへ切り替える。ROADMAPのこの機械更新だけは`change-manage`が直接行ってよい。
6. `State: CHANGE_ACTIVE`とする。
7. Initial Design Routingを判定する。
8. LOW / HIGH / EXTERNALの適切なexecutorでDelta / Design / Tasksを作る。

初期planningをLOWに固定しない。

## During `CHANGE_ACTIVE`

次をオーケストレートする。

- Delta refinement
- Design refinement
- Task add/split/reorder/reopen
- Implementation
- Task verification
- Local Impact Check
- Local / Structural Replanning
- Full Drift Check
- Finalization preview
- Acceptance Summary

Contract内のLiving artifact更新にHuman approvalを要求しない。

## Tasks

TaskはLOWが自律実装＋verification可能な粒度にする。
Task completeは`Verify`条件PASS後のみ。
完了済みTaskを後から削除してhistoryを消さない。必要ならrepair/superseding Taskを追加する。

## Local Impact Check

意味のあるDelta / Design変更後に、影響対象だけを確認する。
Typo、path補正、単純Task splitでFull Drift Checkをしない。

## Replanning

### LOCAL_REPLAN

既存Design Intentが概ね妥当なら影響部分だけ修正する。

### STRUCTURAL_REPLAN

既存Delta / Design / Tasksをauthoritativeとみなさない。
Change Contract、Current Specs、Project Constraints、repository facts、reproducible evidenceから再評価する。
RouteはContext LocalityでHIGH / EXTERNALを選ぶ。

## Human-required uncertainty

HUMAN_REQUIREDでもRecommended defaultを仮定したProvisional Delta / Design / Tasksまでは完成させる。
人間判断に強く依存する実装はDecision前に越えない。

## Acceptance preparation

必要Task完了後:

1. Full Drift Check
2. Backend `preview_finalization`
3. Current Specs Merge Preview
4. Acceptance Summary
5. `Pending Human Decision: CHANGE_ACCEPTANCE`

ここではChangeをfinalizeしない。
Human Acceptance後は`project-update`へ渡す。

## State behavior

- test failureやReplanだけで`BLOCKED`にしない。
- safe meaningful next actionがない時だけ`BLOCKED`。
- `READY`へ戻すのは原則`project-update`のfinalization成功後。

境界判断は`.github/project-manager/CORE-RULES.md`に従う。
