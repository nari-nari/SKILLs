# Project Manager v0.2 for GitHub Copilot（日本語版）

軽量GitHub Copilotを通常の実装・検証に使い、必要なActivityだけCopilot HIGHまたは外部高性能AIへ委譲するためのrepo-local Project Managerです。

## 主な変更（v0.1 → v0.2）

- Feature中心から `Capability / Current Spec / Change / Delta Spec` へ整理
- Project Stateを `READY / CHANGE_ACTIVE / BLOCKED` の3つへ削減
- Spec/Design/Tasksの通常更新時のHuman Approvalを廃止
- 通常ChangeのHuman Gateを原則「Contract重大変更」と「最終Acceptance」へ限定
- Initial Change DesignをLOW固定にせず、LOW / HIGH / EXTERNALから選択
- Structural Replanでは既存Spec/Design/Tasks構造を捨てて再設計可能
- OpenSpec Backend / Standalone Backendを差し替え可能
- Project Strategy Reviewはevent-drivenでExternal HIGHを活用
- `次に進んで`でTask境界ごとに止まらず、安全な区切りまで自律継続

## 構成

```text
.github/
├─ agents/
│  └─ project-manager.agent.md
├─ project-manager/
│  ├─ CORE-RULES.md
│  └─ templates/
└─ skills/
   ├─ project-bootstrap/
   ├─ project-navigate/
   ├─ change-manage/
   ├─ project-update/
   ├─ external-ai-handoff/
   ├─ backend-openspec/
   └─ backend-standalone/
```

Bootstrap後にProject側へ次を作成します。

```text
docs/project/
├─ PROJECT.md
├─ ROADMAP.md
├─ STATUS.md
└─ DECISIONS.md
```

Standalone Backendでは追加で:

```text
docs/specs/<capability>.md
changes/<change-id>-<slug>/
├─ change.md
└─ tasks.md

changes/archive/YYYY-MM-DD-<change-id>-<slug>/
└─ ...  # Accepted Change history
```

OpenSpec BackendではOpenSpec自身の`openspec/specs/`と`openspec/changes/`をsource of truthとして使います。

## 導入

1. このパッケージの`.github`を対象repositoryへコピーする。
2. VS CodeのCopilot Chatで`Project Manager` custom agentを選ぶ。
3. 「Project Managerを初期化して」または「現在の状況を確認して」と指示する。
4. BootstrapがOpenSpec利用可否を確認し、`OPENSPEC`または`STANDALONE`を`PROJECT.md`へ固定する。

既存Project Manager v0.1から移行する場合は、v0.1の`feature.md/evidence.md`をそのままv0.2の正本にせず、Project Managerへ移行を依頼してCurrent Specs / Change history / Project filesへ再分類してください。

## OpenSpec mode

現行OpenSpecはOPSXのfluid/iterative workflowを採用し、GitHub Copilot向けに通常:

```text
.github/skills/openspec-*/SKILL.md
.github/prompts/opsx-*.prompt.md
```

を生成します。Project Managerはこれを上書き・再実装しません。

典型的なOpenSpec source of truth:

```text
openspec/specs/<domain>/spec.md
openspec/changes/<change-name>/proposal.md
openspec/changes/<change-name>/specs/<domain>/spec.md
openspec/changes/<change-name>/design.md
openspec/changes/<change-name>/tasks.md
```

OpenSpecのversion/profileにより利用できるactionが変わるため、`backend-openspec`は固定command列よりも現在OpenSpecが生成したskills/prompts/CLIを優先します。

### OpenSpec導入例

OpenSpec公式の現行手順を確認した上で、GitHub Copilotをtool targetとして初期化してください。OpenSpec自体の更新によって手順は変わり得ます。

## Standalone mode

OpenSpecを導入できない環境でも、Current Specs + Change Contract + Delta + Design + Tasksという同じ論理モデルを最小Markdownで使えます。

StandaloneはOpenSpecの互換実装ではありません。高度なschema/workflow engineを再実装せず、Project Managerに必要な最低限だけを提供します。


## Copilot LOW / HIGHの実行について

Project Managerの`LOW` / `HIGH`はreasoning classです。instructionだけでVS Codeのmodelが必ず自動切替されるとは仮定しません。

既定policyは`AUTO_PREFERRED`です。VS CodeのCopilot Auto model selectionを利用できる場合は、task complexityに応じた実model routingをCopilot Autoへ委ねます。固定model運用を選ぶ場合、HIGH reasoningが必要で現在modelが不十分なら、model pickerでの切替を`Operational Handoff`として扱います（承認Gateではありません）。

## 日常操作

主にProject Manager agentへ自然言語で指示します。

- `次に進んで`
- `現在の状況を教えて`
- `このChangeの残りは？`
- `次のChangeを始めて`
- `このChangeは最初から外部AIに設計させて`
- `外部AIは使わずCopilot HIGHで進めて`
- `Roadmapを見直して`
- `ここで一旦止めて`

Skill名を直接覚える必要はありません。

## 「次に進んで」の停止条件

Task境界では止まりません。原則として次まで自律継続します。

1. Human Decision Gate
2. External AI Operational Handoff
3. BLOCKED
4. Change Acceptance
5. User指定の停止点
6. 安全に意味のあるNext Actionがない

## Human Decision Gate

通常のLiving Delta / Design / Tasks更新、実装方法変更、Task追加/分割、test変更、model escalationには承認不要です。

Human Decisionを要求するのは原則:

- Change Contractの実質変更
- Successの実質的緩和
- Project-level / business / irreversible high-impact decision
- Human-specific value judgment
- 最終Change Acceptance

External AIへのcopy/pasteはDecisionではなくOperational Handoffです。

## External AI modes

- `PROJECT_STRATEGY`
- `CHANGE_DESIGN`
- `REPLANNING`
- `DECISION_SUPPORT`

External AIの回答はLOWが再設計せず、Repository Fit Check後にBackend artifactsへ取り込みます。

## OpenSpec公式情報（2026-08-19確認）

- Repository: https://github.com/Fission-AI/OpenSpec
- OPSX workflow: https://github.com/Fission-AI/OpenSpec/blob/main/docs/opsx.md
- Getting Started: https://github.com/Fission-AI/OpenSpec/blob/main/docs/getting-started.md
- Supported Tools: https://github.com/Fission-AI/OpenSpec/blob/main/docs/supported-tools.md
- Commands: https://github.com/Fission-AI/OpenSpec/blob/main/docs/commands.md

## Version

Project Manager v0.2.1 validated baseline / Japanese GitHub Copilot package.
